import { SheetData } from '../types/sheet';

export interface ViewportRange {
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;
}

export interface CellPixelRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type GridHitType =
  | 'corner'
  | 'col_header'
  | 'col_resize'
  | 'col_filter_btn'
  | 'row_header'
  | 'row_resize'
  | 'cell'
  | 'outside';

export interface GridHitResult {
  type: GridHitType;
  row: number;
  col: number;
  viewRow?: number;
  resizeIndex?: number;
  rect?: CellPixelRect;
}

export class VirtualGrid {
  private sheet: SheetData;
  public headerColWidth = 48;
  public headerRowHeight = 26;

  // View mappings: view index (0..N) -> data row index (0..N)
  public viewToDataRow: number[] = [];
  public dataToViewRow: number[] = [];

  constructor(sheet: SheetData) {
    this.sheet = sheet;
    this.rebuildViewMapping();
  }

  setSheet(sheet: SheetData) {
    this.sheet = sheet;
    this.rebuildViewMapping();
  }

  rebuildViewMapping() {
    const totalRows = this.sheet.maxRows;
    const filterCols = Object.keys(this.sheet.filters).map(Number);

    let rows: number[] = [];
    for (let r = 0; r < totalRows; r++) {
      let isVisible = true;

      // Filter evaluation
      for (const col of filterCols) {
        const filter = this.sheet.filters[col];
        if (!filter) continue;

        const cell = this.sheet.cells[`${r}_${col}`];
        const val = cell?.computed !== undefined ? cell.computed : (cell?.raw ?? '');
        const strVal = String(val);

        // Check search query / selected values
        if (filter.selectedValues && filter.selectedValues.size > 0) {
          if (!filter.selectedValues.has(strVal)) {
            isVisible = false;
            break;
          }
        }

        // Condition filter
        if (filter.condition && filter.condition.type !== 'none') {
          const cond = filter.condition;
          if (cond.type === 'empty' && strVal !== '') isVisible = false;
          if (cond.type === 'contains' && !strVal.toLowerCase().includes(String(cond.value || '').toLowerCase())) isVisible = false;
          if (cond.type === 'equals' && strVal.toLowerCase() !== String(cond.value || '').toLowerCase()) isVisible = false;
          if (cond.type === 'greater' && Number(val) <= Number(cond.value)) isVisible = false;
          if (cond.type === 'less' && Number(val) >= Number(cond.value)) isVisible = false;
          if (!isVisible) break;
        }
      }

      if (isVisible) {
        rows.push(r);
      }
    }

    // Sort evaluation (if any active column has sortOrder)
    const sortedCol = filterCols.find((c) => this.sheet.filters[c]?.sortOrder);
    if (sortedCol !== undefined) {
      const order = this.sheet.filters[sortedCol].sortOrder;
      // Keep row 0 (headers) intact if in view, or sort all rows
      rows.sort((a, b) => {
        if (a === 0) return -1;
        if (b === 0) return 1;

        const cellA = this.sheet.cells[`${a}_${sortedCol}`];
        const cellB = this.sheet.cells[`${b}_${sortedCol}`];
        const valA = cellA?.computed ?? cellA?.raw ?? '';
        const valB = cellB?.computed ?? cellB?.raw ?? '';

        const numA = Number(valA);
        const numB = Number(valB);

        let cmp = 0;
        if (!isNaN(numA) && !isNaN(numB) && valA !== '' && valB !== '') {
          cmp = numA - numB;
        } else {
          cmp = String(valA).localeCompare(String(valB), 'fr', { numeric: true, sensitivity: 'base' });
        }
        return order === 'asc' ? cmp : -cmp;
      });
    }

    this.viewToDataRow = rows;
    this.dataToViewRow = new Array(totalRows).fill(-1);
    for (let v = 0; v < rows.length; v++) {
      this.dataToViewRow[rows[v]] = v;
    }
  }

  getColWidth(col: number): number {
    return this.sheet.columnWidths[col] || this.sheet.defaultColWidth || 96;
  }

  getRowHeight(dataRow: number): number {
    return this.sheet.rowHeights[dataRow] || this.sheet.defaultRowHeight || 24;
  }

  // Total canvas content dimensions
  getTotalWidth(): number {
    let w = this.headerColWidth;
    for (let c = 0; c < this.sheet.maxCols; c++) {
      w += this.getColWidth(c);
    }
    return w;
  }

  getTotalHeight(): number {
    let h = this.headerRowHeight;
    for (let v = 0; v < this.viewToDataRow.length; v++) {
      const r = this.viewToDataRow[v];
      h += this.getRowHeight(r);
    }
    return h;
  }

  // Get X coordinate of column start (relative to grid origin, including headerColWidth)
  getColStart(col: number): number {
    let x = this.headerColWidth;
    for (let c = 0; c < col; c++) {
      x += this.getColWidth(c);
    }
    return x;
  }

  // Get Y coordinate of view row start
  getViewRowStart(viewRow: number): number {
    let y = this.headerRowHeight;
    for (let v = 0; v < viewRow; v++) {
      const r = this.viewToDataRow[v];
      y += this.getRowHeight(r);
    }
    return y;
  }

  // Compute visible range based on scroll offsets
  getVisibleRange(scrollX: number, scrollY: number, viewportW: number, viewportH: number): ViewportRange {
    // Find visible columns
    let curX = this.headerColWidth;
    let startCol = 0;
    let endCol = 0;

    for (let c = 0; c < this.sheet.maxCols; c++) {
      const w = this.getColWidth(c);
      if (curX + w >= scrollX + this.headerColWidth) {
        startCol = Math.max(0, c - 1);
        break;
      }
      curX += w;
    }

    curX = this.getColStart(startCol);
    for (let c = startCol; c < this.sheet.maxCols; c++) {
      const w = this.getColWidth(c);
      curX += w;
      endCol = c;
      if (curX > scrollX + viewportW + 200) {
        break;
      }
    }

    // Find visible rows
    let curY = this.headerRowHeight;
    let startViewRow = 0;
    let endViewRow = 0;

    for (let v = 0; v < this.viewToDataRow.length; v++) {
      const r = this.viewToDataRow[v];
      const h = this.getRowHeight(r);
      if (curY + h >= scrollY + this.headerRowHeight) {
        startViewRow = Math.max(0, v - 1);
        break;
      }
      curY += h;
    }

    curY = this.getViewRowStart(startViewRow);
    for (let v = startViewRow; v < this.viewToDataRow.length; v++) {
      const r = this.viewToDataRow[v];
      const h = this.getRowHeight(r);
      curY += h;
      endViewRow = v;
      if (curY > scrollY + viewportH + 200) {
        break;
      }
    }

    return {
      startCol,
      endCol: Math.min(this.sheet.maxCols - 1, endCol + 2),
      startRow: startViewRow,
      endRow: Math.min(this.viewToDataRow.length - 1, endViewRow + 2),
    };
  }

  // Get cell rectangle on canvas (in absolute content coordinates)
  getCellContentRect(row: number, col: number): CellPixelRect {
    const viewRow = this.dataToViewRow[row] !== undefined ? this.dataToViewRow[row] : row;
    const x = this.getColStart(col);
    const y = this.getViewRowStart(viewRow);
    const width = this.getColWidth(col);
    const height = this.getRowHeight(row);
    return { x, y, width, height };
  }

  // Hit test canvas pixel coords
  hitTest(
    pixelX: number,
    pixelY: number,
    scrollX: number,
    scrollY: number
  ): GridHitResult {
    // Corner click (Select all)
    if (pixelX <= this.headerColWidth && pixelY <= this.headerRowHeight) {
      return { type: 'corner', row: -1, col: -1 };
    }

    // Column header click or resize
    if (pixelY <= this.headerRowHeight && pixelX > this.headerColWidth) {
      const targetX = pixelX + scrollX;
      let curX = this.headerColWidth;

      for (let c = 0; c < this.sheet.maxCols; c++) {
        const w = this.getColWidth(c);
        if (targetX >= curX && targetX <= curX + w) {
          // Check right border for column resize (5px tolerance)
          if (targetX >= curX + w - 5) {
            return { type: 'col_resize', row: -1, col: c, resizeIndex: c };
          }
          // Check left border for previous column resize
          if (targetX <= curX + 4 && c > 0) {
            return { type: 'col_resize', row: -1, col: c - 1, resizeIndex: c - 1 };
          }
          // Check if clicked the filter dropdown button (rightmost 20px)
          if (this.sheet.filters[c] && targetX >= curX + w - 24) {
            return { type: 'col_filter_btn', row: -1, col: c };
          }
          return { type: 'col_header', row: -1, col: c };
        }
        curX += w;
      }
      return { type: 'outside', row: -1, col: -1 };
    }

    // Row header click or resize
    if (pixelX <= this.headerColWidth && pixelY > this.headerRowHeight) {
      const targetY = pixelY + scrollY;
      let curY = this.headerRowHeight;

      for (let v = 0; v < this.viewToDataRow.length; v++) {
        const r = this.viewToDataRow[v];
        const h = this.getRowHeight(r);
        if (targetY >= curY && targetY <= curY + h) {
          // Check bottom border for row resize (5px tolerance)
          if (targetY >= curY + h - 5) {
            return { type: 'row_resize', row: r, col: -1, viewRow: v, resizeIndex: r };
          }
          if (targetY <= curY + 4 && v > 0) {
            const prevR = this.viewToDataRow[v - 1];
            return { type: 'row_resize', row: prevR, col: -1, viewRow: v - 1, resizeIndex: prevR };
          }
          return { type: 'row_header', row: r, col: -1, viewRow: v };
        }
        curY += h;
      }
      return { type: 'outside', row: -1, col: -1 };
    }

    // Grid cell click
    const targetX = pixelX + scrollX;
    const targetY = pixelY + scrollY;

    let hitCol = -1;
    let curX = this.headerColWidth;
    for (let c = 0; c < this.sheet.maxCols; c++) {
      const w = this.getColWidth(c);
      if (targetX >= curX && targetX <= curX + w) {
        hitCol = c;
        break;
      }
      curX += w;
    }

    let hitRow = -1;
    let hitViewRow = -1;
    let curY = this.headerRowHeight;
    for (let v = 0; v < this.viewToDataRow.length; v++) {
      const r = this.viewToDataRow[v];
      const h = this.getRowHeight(r);
      if (targetY >= curY && targetY <= curY + h) {
        hitRow = r;
        hitViewRow = v;
        break;
      }
      curY += h;
    }

    if (hitCol !== -1 && hitRow !== -1) {
      const rect = this.getCellContentRect(hitRow, hitCol);
      return {
        type: 'cell',
        row: hitRow,
        col: hitCol,
        viewRow: hitViewRow,
        rect,
      };
    }

    return { type: 'outside', row: -1, col: -1 };
  }
}
