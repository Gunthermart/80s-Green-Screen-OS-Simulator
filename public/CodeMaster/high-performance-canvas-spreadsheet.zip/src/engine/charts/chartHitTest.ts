import { ChartConfig, DragHandleType, ChartHoverInfo, SheetData } from '../../types/sheet';
import { extractChartData } from './chartDataExtractor';

export interface ChartHitResult {
  chart: ChartConfig;
  handle?: DragHandleType;
  hoverInfo?: ChartHoverInfo;
}

const HANDLE_SIZE = 8;

export function getChartHandles(chart: ChartConfig): { type: DragHandleType; x: number; y: number }[] {
  const { x, y, width, height } = chart;
  const halfW = width / 2;
  const halfH = height / 2;

  return [
    { type: 'nw', x: x, y: y },
    { type: 'n', x: x + halfW, y: y },
    { type: 'ne', x: x + width, y: y },
    { type: 'e', x: x + width, y: y + halfH },
    { type: 'se', x: x + width, y: y + height },
    { type: 's', x: x + halfW, y: y + height },
    { type: 'sw', x: x, y: y + height },
    { type: 'w', x: x, y: y + halfH },
  ];
}

export function hitTestCharts(
  charts: ChartConfig[],
  sheet: SheetData,
  canvasX: number,
  canvasY: number,
  selectedChartId?: string | null
): ChartHitResult | null {
  // Check in reverse order (topmost charts first)
  for (let i = charts.length - 1; i >= 0; i--) {
    const chart = charts[i];
    const isSelected = chart.id === selectedChartId;

    // 1. If chart is selected, check its 8 resize handles first
    if (isSelected) {
      const handles = getChartHandles(chart);
      for (const h of handles) {
        if (
          canvasX >= h.x - HANDLE_SIZE &&
          canvasX <= h.x + HANDLE_SIZE &&
          canvasY >= h.y - HANDLE_SIZE &&
          canvasY <= h.y + HANDLE_SIZE
        ) {
          return { chart, handle: h.type };
        }
      }
    }

    // 2. Check if cursor is inside chart bounding box
    if (
      canvasX >= chart.x &&
      canvasX <= chart.x + chart.width &&
      canvasY >= chart.y &&
      canvasY <= chart.y + chart.height
    ) {
      // Check for chart elements (bars, lines, slices) for hover tooltip
      const hoverInfo = hitTestChartElements(chart, sheet, canvasX, canvasY);
      return {
        chart,
        handle: 'move',
        hoverInfo: hoverInfo || undefined,
      };
    }
  }

  return null;
}

export function hitTestChartElements(
  chart: ChartConfig,
  sheet: SheetData,
  canvasX: number,
  canvasY: number
): ChartHoverInfo | null {
  const data = extractChartData(chart, sheet);
  if (!data.series.length || !data.labels.length) return null;

  const { x, y, width, height } = chart;
  const padding = { top: 46, right: 20, bottom: 36, left: 52 };
  const plotX = x + padding.left;
  const plotY = y + padding.top;
  const plotW = Math.max(10, width - padding.left - padding.right);
  const plotH = Math.max(10, height - padding.top - padding.bottom);

  // PIE / DOUGHNUT HIT TESTING
  if (chart.type === 'pie' || chart.type === 'doughnut') {
    const centerX = x + width / 2;
    const centerY = y + (height + 20) / 2;
    const radius = Math.min(plotW, plotH) / 2 - 10;
    const innerRadius = chart.type === 'doughnut' ? radius * (chart.doughnutHoleSize || 0.5) : 0;

    const dx = canvasX - centerX;
    const dy = canvasY - centerY;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist >= innerRadius && dist <= radius + 15) {
      let angle = Math.atan2(dy, dx);
      if (angle < -Math.PI / 2) angle += 2 * Math.PI;

      const series0 = data.series[0];
      if (!series0) return null;
      const total = series0.data.reduce((acc, v) => acc + Math.max(0, v), 0) || 1;

      let curAngle = -Math.PI / 2;
      for (let i = 0; i < series0.data.length; i++) {
        const val = Math.max(0, series0.data[i]);
        const sliceAngle = (val / total) * 2 * Math.PI;
        const endAngle = curAngle + sliceAngle;

        let checkAngle = angle;
        if (checkAngle < -Math.PI / 2) checkAngle += 2 * Math.PI;

        if (checkAngle >= curAngle && checkAngle <= endAngle) {
          const pct = Math.round((val / total) * 1000) / 10;
          return {
            chartId: chart.id,
            seriesIndex: 0,
            seriesName: series0.name,
            pointIndex: i,
            label: data.labels[i] || `Item ${i + 1}`,
            value: val,
            percentage: pct,
            canvasX,
            canvasY,
            screenX: canvasX,
            screenY: canvasY,
          };
        }
        curAngle = endAngle;
      }
    }
    return null;
  }

  // COLUMN / BAR / LINE HIT TESTING
  if (canvasX >= plotX && canvasX <= plotX + plotW && canvasY >= plotY && canvasY <= plotY + plotH) {
    const numCategories = data.labels.length;
    const numSeries = data.series.length;
    const catWidth = plotW / numCategories;

    const catIndex = Math.floor((canvasX - plotX) / catWidth);
    if (catIndex >= 0 && catIndex < numCategories) {
      const relX = (canvasX - plotX) % catWidth;
      const seriesSlotWidth = catWidth / numSeries;
      let targetSeriesIdx = Math.floor(relX / seriesSlotWidth);
      if (targetSeriesIdx >= numSeries) targetSeriesIdx = numSeries - 1;
      if (targetSeriesIdx < 0) targetSeriesIdx = 0;

      const s = data.series[targetSeriesIdx];
      if (s) {
        const val = s.data[catIndex] ?? 0;
        return {
          chartId: chart.id,
          seriesIndex: targetSeriesIdx,
          seriesName: s.name,
          pointIndex: catIndex,
          label: data.labels[catIndex] || `Item ${catIndex + 1}`,
          value: val,
          canvasX,
          canvasY,
          screenX: canvasX,
          screenY: canvasY,
        };
      }
    }
  }

  return null;
}
