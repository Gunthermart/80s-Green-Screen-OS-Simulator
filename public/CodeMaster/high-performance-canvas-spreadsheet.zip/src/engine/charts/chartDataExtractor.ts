import { ChartConfig, SheetData } from '../../types/sheet';
import { parseRange } from '../formula/utils';

export interface ChartSeries {
  name: string;
  data: number[];
  color: string;
}

export interface ExtractedChartData {
  labels: string[];
  series: ChartSeries[];
  minValue: number;
  maxValue: number;
}

export const DEFAULT_CHART_COLORS = [
  '#3b82f6', // Blue
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Purple
  '#06b6d4', // Cyan
  '#f97316', // Orange
  '#6366f1', // Indigo
  '#14b8a6', // Teal
  '#e11d48', // Rose
];

export function extractChartData(chart: ChartConfig, sheet: SheetData): ExtractedChartData {
  const dataRange = parseRange(chart.dataRange);
  if (!dataRange) {
    return { labels: [], series: [], minValue: 0, maxValue: 100 };
  }

  // Extract labels
  let labels: string[] = [];
  if (chart.labelRange) {
    const labelRange = parseRange(chart.labelRange);
    if (labelRange) {
      for (let r = labelRange.startRow; r <= labelRange.endRow; r++) {
        for (let c = labelRange.startCol; c <= labelRange.endCol; c++) {
          const cell = sheet.cells[`${r}_${c}`];
          const val = cell?.computed !== undefined ? cell.computed : (cell?.raw ?? '');
          labels.push(String(val || `Item ${labels.length + 1}`));
        }
      }
    }
  }

  // Extract series names
  let seriesNames: string[] = [];
  if (chart.seriesNamesRange) {
    const sRange = parseRange(chart.seriesNamesRange);
    if (sRange) {
      for (let r = sRange.startRow; r <= sRange.endRow; r++) {
        for (let c = sRange.startCol; c <= sRange.endCol; c++) {
          const cell = sheet.cells[`${r}_${c}`];
          const val = cell?.computed !== undefined ? cell.computed : (cell?.raw ?? '');
          seriesNames.push(String(val || `Série ${seriesNames.length + 1}`));
        }
      }
    }
  }

  const series: ChartSeries[] = [];
  const colors = chart.colors && chart.colors.length > 0 ? chart.colors : DEFAULT_CHART_COLORS;

  const numRows = dataRange.endRow - dataRange.startRow + 1;
  const numCols = dataRange.endCol - dataRange.startCol + 1;

  if (chart.seriesDirection === 'rows') {
    // Each row is a series
    for (let r = 0; r < numRows; r++) {
      const rowIdx = dataRange.startRow + r;
      const sName = seriesNames[r] || `Série ${r + 1}`;
      const data: number[] = [];
      for (let c = 0; c < numCols; c++) {
        const colIdx = dataRange.startCol + c;
        const cell = sheet.cells[`${rowIdx}_${colIdx}`];
        const val = Number(cell?.computed !== undefined ? cell.computed : cell?.raw);
        data.push(isNaN(val) ? 0 : val);
      }
      series.push({
        name: sName,
        data,
        color: colors[r % colors.length],
      });
    }

    if (labels.length === 0) {
      for (let c = 0; c < numCols; c++) {
        labels.push(`Col ${c + 1}`);
      }
    }
  } else {
    // Default: Each column is a series
    for (let c = 0; c < numCols; c++) {
      const colIdx = dataRange.startCol + c;
      const sName = seriesNames[c] || `Série ${c + 1}`;
      const data: number[] = [];
      for (let r = 0; r < numRows; r++) {
        const rowIdx = dataRange.startRow + r;
        const cell = sheet.cells[`${rowIdx}_${colIdx}`];
        const val = Number(cell?.computed !== undefined ? cell.computed : cell?.raw);
        data.push(isNaN(val) ? 0 : val);
      }
      series.push({
        name: sName,
        data,
        color: colors[c % colors.length],
      });
    }

    if (labels.length === 0) {
      for (let r = 0; r < numRows; r++) {
        labels.push(`Ligne ${r + 1}`);
      }
    }
  }

  // Calculate min & max
  let allVals: number[] = [];
  for (const s of series) {
    allVals = allVals.concat(s.data);
  }

  let minValue = allVals.length > 0 ? Math.min(...allVals) : 0;
  let maxValue = allVals.length > 0 ? Math.max(...allVals) : 100;

  if (minValue > 0) minValue = 0; // standard bar/line baseline at 0
  if (minValue === maxValue) {
    maxValue = minValue + 10;
  }

  return {
    labels,
    series,
    minValue,
    maxValue,
  };
}
