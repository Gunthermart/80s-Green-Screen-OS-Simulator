import { ChartConfig, ChartHoverInfo, SheetData } from '../../types/sheet';
import { extractChartData } from './chartDataExtractor';
import { getChartHandles } from './chartHitTest';

export function renderChart(
  ctx: CanvasRenderingContext2D,
  chart: ChartConfig,
  sheet: SheetData,
  isSelected: boolean,
  hoverInfo?: ChartHoverInfo | null
) {
  const { x, y, width, height } = chart;
  const data = extractChartData(chart, sheet);

  ctx.save();

  // 1. Draw Card Background & Shadow
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.08)';
  ctx.shadowBlur = 12;
  ctx.shadowOffsetY = 4;
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = isSelected ? '#3b82f6' : '#e2e8f0';
  ctx.lineWidth = isSelected ? 2 : 1;

  ctx.beginPath();
  ctx.roundRect(x, y, width, height, 8);
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  // 2. Draw Header (Title & Subtitle)
  let headerHeight = 24;
  if (chart.title) {
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 13px Inter, -apple-system, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillText(chart.title, x + 14, y + 12);
    headerHeight += 12;

    if (chart.subtitle) {
      ctx.fillStyle = '#64748b';
      ctx.font = '11px Inter, -apple-system, sans-serif';
      ctx.fillText(chart.subtitle, x + 14, y + 28);
      headerHeight += 12;
    }
  }

  // 3. Draw Legend
  const showLegend = chart.showLegend !== false && data.series.length > 0;
  let legendOffsetTop = 0;
  if (showLegend) {
    ctx.font = '11px Inter, -apple-system, sans-serif';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';

    let legX = x + 14;
    const legY = y + (chart.title ? headerHeight - 4 : 14);

    if (chart.type === 'pie' || chart.type === 'doughnut') {
      // For pie charts, legend is data labels
      for (let i = 0; i < Math.min(data.labels.length, 6); i++) {
        const color = (chart.colors && chart.colors[i]) || data.series[0]?.color || '#3b82f6';
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(legX + 4, legY, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#475569';
        const labelText = data.labels[i];
        ctx.fillText(labelText, legX + 12, legY);
        legX += ctx.measureText(labelText).width + 24;
        if (legX > x + width - 40) break;
      }
      legendOffsetTop = 20;
    } else {
      // For column/bar/line, legend is series
      for (const s of data.series) {
        ctx.fillStyle = s.color;
        ctx.beginPath();
        ctx.arc(legX + 4, legY, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#475569';
        ctx.fillText(s.name, legX + 12, legY);
        legX += ctx.measureText(s.name).width + 24;
        if (legX > x + width - 40) break;
      }
      legendOffsetTop = 16;
    }
  }

  // Plot area bounding box
  const padLeft = chart.type === 'pie' || chart.type === 'doughnut' ? 14 : 50;
  const padRight = 18;
  const padBottom = chart.type === 'pie' || chart.type === 'doughnut' ? 14 : 32;
  const padTop = (chart.title ? headerHeight : 14) + legendOffsetTop + 10;

  const plotX = x + padLeft;
  const plotY = y + padTop;
  const plotW = Math.max(20, width - padLeft - padRight);
  const plotH = Math.max(20, height - padTop - padBottom);

  if (chart.type === 'pie' || chart.type === 'doughnut') {
    renderPieChart(ctx, chart, data, x, y, width, height, padTop, hoverInfo);
  } else if (chart.type === 'line' || chart.type === 'spline' || chart.type === 'area') {
    renderLineChart(ctx, chart, data, plotX, plotY, plotW, plotH, hoverInfo);
  } else {
    // Column or Bar
    renderColumnBarChart(ctx, chart, data, plotX, plotY, plotW, plotH, hoverInfo);
  }

  // 4. Draw Selection Outline & 8 Handles
  if (isSelected) {
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x, y, width, height);

    const handles = getChartHandles(chart);
    for (const h of handles) {
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 1.5;

      ctx.beginPath();
      ctx.rect(h.x - 3.5, h.y - 3.5, 7, 7);
      ctx.fill();
      ctx.stroke();
    }
  }

  // 5. Draw Interactive Canvas Tooltip
  if (hoverInfo && hoverInfo.chartId === chart.id) {
    renderChartTooltip(ctx, hoverInfo);
  }

  ctx.restore();
}

function renderColumnBarChart(
  ctx: CanvasRenderingContext2D,
  chart: ChartConfig,
  data: any,
  plotX: number,
  plotY: number,
  plotW: number,
  plotH: number,
  hoverInfo?: ChartHoverInfo | null
) {
  const { labels, series, maxValue } = data;
  if (!labels.length || !series.length) return;

  const isStacked = chart.type === 'column_stacked' || chart.type === 'bar_stacked';

  // 1. Gridlines & Y-Axis values
  const ticks = 4;
  ctx.font = '10px Inter, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  ctx.strokeStyle = '#f1f5f9';
  ctx.lineWidth = 1;

  for (let i = 0; i <= ticks; i++) {
    const val = (maxValue / ticks) * i;
    const ty = plotY + plotH - (plotH / ticks) * i;

    // Gridline
    ctx.beginPath();
    ctx.moveTo(plotX, ty);
    ctx.lineTo(plotX + plotW, ty);
    ctx.stroke();

    // Value label
    const formatted = val >= 1000 ? `${(val / 1000).toFixed(0)}k` : `${Math.round(val)}`;
    ctx.fillText(formatted, plotX - 8, ty);
  }

  // 2. Bars rendering
  const numCats = labels.length;
  const catWidth = plotW / numCats;
  const numSeries = series.length;
  const barPadding = 0.2; // 20% margin

  for (let c = 0; c < numCats; c++) {
    const catX = plotX + c * catWidth;
    const availWidth = catWidth * (1 - barPadding);
    const startX = catX + (catWidth * barPadding) / 2;

    if (isStacked) {
      const barW = availWidth;
      let cumH = 0;
      for (let s = 0; s < numSeries; s++) {
        const val = series[s].data[c] || 0;
        const barH = (val / (maxValue || 1)) * plotH;
        const barY = plotY + plotH - cumH - barH;

        ctx.fillStyle = series[s].color;
        ctx.fillRect(startX, barY, barW, barH);
        cumH += barH;
      }
    } else {
      const barW = Math.max(2, availWidth / numSeries);
      for (let s = 0; s < numSeries; s++) {
        const val = series[s].data[c] || 0;
        const barH = Math.max(0, (val / (maxValue || 1)) * plotH);
        const barX = startX + s * barW;
        const barY = plotY + plotH - barH;

        const isHovered =
          hoverInfo?.chartId === chart.id &&
          hoverInfo.seriesIndex === s &&
          hoverInfo.pointIndex === c;

        ctx.fillStyle = isHovered ? '#1d4ed8' : series[s].color;

        ctx.beginPath();
        ctx.roundRect(barX, barY, Math.max(1, barW - 2), barH, [3, 3, 0, 0]);
        ctx.fill();

        if (isHovered) {
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
      }
    }

    // X-Axis Category label
    ctx.fillStyle = '#64748b';
    ctx.font = '10px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    const label = labels[c] || '';
    const truncated = label.length > 8 ? label.substring(0, 7) + '…' : label;
    ctx.fillText(truncated, catX + catWidth / 2, plotY + plotH + 8);
  }
}

function renderLineChart(
  ctx: CanvasRenderingContext2D,
  chart: ChartConfig,
  data: any,
  plotX: number,
  plotY: number,
  plotW: number,
  plotH: number,
  hoverInfo?: ChartHoverInfo | null
) {
  const { labels, series, maxValue } = data;
  if (!labels.length || !series.length) return;

  const isArea = chart.type === 'area';
  const isSmooth = chart.smooth !== false;

  // Gridlines
  const ticks = 4;
  ctx.font = '10px Inter, sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  ctx.strokeStyle = '#f1f5f9';
  ctx.lineWidth = 1;

  for (let i = 0; i <= ticks; i++) {
    const val = (maxValue / ticks) * i;
    const ty = plotY + plotH - (plotH / ticks) * i;

    ctx.beginPath();
    ctx.moveTo(plotX, ty);
    ctx.lineTo(plotX + plotW, ty);
    ctx.stroke();

    const formatted = val >= 1000 ? `${(val / 1000).toFixed(0)}k` : `${Math.round(val)}`;
    ctx.fillText(formatted, plotX - 8, ty);
  }

  const numCats = labels.length;
  const stepX = plotW / Math.max(1, numCats - 1);

  // Draw series lines
  series.forEach((s: any, sIdx: number) => {
    const points: { x: number; y: number }[] = [];
    for (let c = 0; c < numCats; c++) {
      const val = s.data[c] || 0;
      const px = plotX + c * stepX;
      const py = plotY + plotH - (val / (maxValue || 1)) * plotH;
      points.push({ x: px, y: py });
    }

    // Draw Area Fill if enabled
    if (isArea && points.length > 1) {
      const grad = ctx.createLinearGradient(plotX, plotY, plotX, plotY + plotH);
      grad.addColorStop(0, hexToRgba(s.color, 0.35));
      grad.addColorStop(1, hexToRgba(s.color, 0.02));

      ctx.beginPath();
      ctx.moveTo(points[0].x, plotY + plotH);
      ctx.lineTo(points[0].x, points[0].y);

      if (isSmooth) {
        for (let i = 0; i < points.length - 1; i++) {
          const xc = (points[i].x + points[i + 1].x) / 2;
          const yc = (points[i].y + points[i + 1].y) / 2;
          ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
        }
        ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
      } else {
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y);
        }
      }

      ctx.lineTo(points[points.length - 1].x, plotY + plotH);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();
    }

    // Draw Stroke Line
    ctx.strokeStyle = s.color;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);

    if (isSmooth && points.length > 2) {
      for (let i = 0; i < points.length - 1; i++) {
        const xc = (points[i].x + points[i + 1].x) / 2;
        const yc = (points[i].y + points[i + 1].y) / 2;
        ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
      }
      ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
    } else {
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
    }
    ctx.stroke();

    // Draw Marker Dots
    for (let c = 0; c < points.length; c++) {
      const p = points[c];
      const isHovered =
        hoverInfo?.chartId === chart.id &&
        hoverInfo.seriesIndex === sIdx &&
        hoverInfo.pointIndex === c;

      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = s.color;
      ctx.lineWidth = isHovered ? 3 : 2;

      ctx.beginPath();
      ctx.arc(p.x, p.y, isHovered ? 5.5 : 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  });

  // X-Axis labels
  ctx.fillStyle = '#64748b';
  ctx.font = '10px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'top';
  for (let c = 0; c < numCats; c++) {
    const lx = plotX + c * stepX;
    const label = labels[c] || '';
    const truncated = label.length > 8 ? label.substring(0, 7) + '…' : label;
    ctx.fillText(truncated, lx, plotY + plotH + 8);
  }
}

function renderPieChart(
  ctx: CanvasRenderingContext2D,
  chart: ChartConfig,
  data: any,
  x: number,
  y: number,
  width: number,
  height: number,
  padTop: number,
  hoverInfo?: ChartHoverInfo | null
) {
  const { series } = data;
  if (!series.length || !series[0].data.length) return;

  const s = series[0];
  const total = s.data.reduce((acc: number, v: number) => acc + Math.max(0, v), 0) || 1;

  const centerX = x + width / 2;
  const centerY = y + padTop + (height - padTop) / 2;
  const radius = Math.min(width / 2 - 20, (height - padTop) / 2 - 20);
  const isDoughnut = chart.type === 'doughnut';
  const innerRadius = isDoughnut ? radius * (chart.doughnutHoleSize || 0.55) : 0;

  let curAngle = -Math.PI / 2;
  const colors = chart.colors && chart.colors.length > 0 ? chart.colors : [
    '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4', '#f97316'
  ];

  for (let i = 0; i < s.data.length; i++) {
    const val = Math.max(0, s.data[i]);
    const sliceAngle = (val / total) * 2 * Math.PI;
    const endAngle = curAngle + sliceAngle;
    const isHovered = hoverInfo?.chartId === chart.id && hoverInfo.pointIndex === i;

    // Offset exploded slice slightly when hovered
    let offX = 0;
    let offY = 0;
    if (isHovered) {
      const midAngle = curAngle + sliceAngle / 2;
      offX = Math.cos(midAngle) * 6;
      offY = Math.sin(midAngle) * 6;
    }

    ctx.save();
    ctx.translate(offX, offY);

    ctx.fillStyle = colors[i % colors.length];
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, curAngle, endAngle);
    if (isDoughnut) {
      ctx.arc(centerX, centerY, innerRadius, endAngle, curAngle, true);
    } else {
      ctx.lineTo(centerX, centerY);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Draw percentage text on slice if big enough
    const pct = Math.round((val / total) * 100);
    if (pct >= 8) {
      const midAngle = curAngle + sliceAngle / 2;
      const textDist = isDoughnut ? (radius + innerRadius) / 2 : radius * 0.65;
      const tx = centerX + Math.cos(midAngle) * textDist;
      const ty = centerY + Math.sin(midAngle) * textDist;

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 10px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${pct}%`, tx, ty);
    }

    ctx.restore();
    curAngle = endAngle;
  }

  // Doughnut center summary metric
  if (isDoughnut) {
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const totalFormatted = total >= 1000 ? `${(total / 1000).toFixed(1)}k` : `${Math.round(total)}`;
    ctx.fillText(totalFormatted, centerX, centerY - 4);

    ctx.fillStyle = '#64748b';
    ctx.font = '9px Inter, sans-serif';
    ctx.fillText('TOTAL', centerX, centerY + 10);
  }
}

function renderChartTooltip(ctx: CanvasRenderingContext2D, hover: ChartHoverInfo) {
  const { label, value, percentage, seriesName, canvasX, canvasY } = hover;
  const padding = 8;
  const titleText = `${label || ''}`;
  const valFormatted = value !== undefined ? (value >= 1000 ? value.toLocaleString('fr-FR') : value) : '';
  const valueText = `${seriesName ? seriesName + ': ' : ''}${valFormatted}${percentage !== undefined ? ` (${percentage}%)` : ''}`;

  ctx.save();
  ctx.font = 'bold 11px Inter, sans-serif';
  const w1 = ctx.measureText(titleText).width;
  ctx.font = '11px Inter, sans-serif';
  const w2 = ctx.measureText(valueText).width;
  const tooltipW = Math.max(w1, w2) + padding * 2 + 10;
  const tooltipH = 42;

  let tx = canvasX + 12;
  let ty = canvasY - tooltipH - 6;
  if (tx + tooltipW > ctx.canvas.width / (window.devicePixelRatio || 1) - 10) {
    tx = canvasX - tooltipW - 12;
  }
  if (ty < 10) {
    ty = canvasY + 16;
  }

  // Tooltip Background Card
  ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
  ctx.shadowBlur = 8;
  ctx.shadowOffsetY = 3;
  ctx.fillStyle = '#0f172a'; // Slate 900
  ctx.beginPath();
  ctx.roundRect(tx, ty, tooltipW, tooltipH, 6);
  ctx.fill();

  // Content
  ctx.shadowColor = 'transparent';
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 11px Inter, sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(titleText, tx + padding, ty + padding);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '10px Inter, sans-serif';
  ctx.fillText(valueText, tx + padding, ty + padding + 15);

  ctx.restore();
}

function hexToRgba(hex: string, alpha: number): string {
  let h = hex.replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  const num = parseInt(h, 16);
  return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
}
