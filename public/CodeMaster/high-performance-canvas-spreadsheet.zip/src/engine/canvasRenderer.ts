import { SheetData, CellRange, CellCoord, MarchingAntsSelection, ChartHoverInfo } from '../types/sheet';
import { VirtualGrid } from './virtualGrid';
import { colIndexToName, formatValue, normalizeRange } from './formula/utils';
import { ConditionalFormattingEngine } from './conditionalFormatting';
import { renderChart } from './charts/chartRenderer';

export interface RenderContext {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  sheet: SheetData;
  grid: VirtualGrid;
  conditionalEngine: ConditionalFormattingEngine;
  scrollX: number;
  scrollY: number;
  selection: CellRange | null;
  activeCell: CellCoord;
  isSelecting: boolean;
  autofillRange: CellRange | null;
  marchingAnts: MarchingAntsSelection | null;
  marchingAntsOffset: number;
  selectedChartId: string | null;
  chartHoverInfo: ChartHoverInfo | null;
  hoveredColHeader: number | null;
  hoveredRowHeader: number | null;
  dpr: number;
}

export function renderSpreadsheet(rc: RenderContext) {
  const {
    canvas,
    ctx,
    sheet,
    grid,
    conditionalEngine,
    scrollX,
    scrollY,
    selection,
    activeCell,
    autofillRange,
    marchingAnts,
    marchingAntsOffset,
    selectedChartId,
    chartHoverInfo,
    hoveredColHeader,
    hoveredRowHeader,
    dpr,
  } = rc;

  const width = canvas.width / dpr;
  const height = canvas.height / dpr;

  // Pass 0: Reset transforms & clear background
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  // Background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  const visible = grid.getVisibleRange(scrollX, scrollY, width, height);
  const normSel = selection ? normalizeRange(selection) : null;

  // PASS 1 & 2: Cell backgrounds, Conditional formatting, Data bars, Icons
  ctx.save();
  // Clip to grid viewport (excluding headers)
  ctx.beginPath();
  ctx.rect(grid.headerColWidth, grid.headerRowHeight, width - grid.headerColWidth, height - grid.headerRowHeight);
  ctx.clip();

  for (let v = visible.startRow; v <= visible.endRow; v++) {
    const r = grid.viewToDataRow[v];
    if (r === undefined) continue;
    const rowY = grid.getViewRowStart(v) - scrollY;
    const rowH = grid.getRowHeight(r);

    for (let c = visible.startCol; c <= visible.endCol; c++) {
      const colX = grid.getColStart(c) - scrollX;
      const colW = grid.getColWidth(c);
      const cell = sheet.cells[`${r}_${c}`];

      const condFormat = conditionalEngine.evaluateCell(r, c, sheet);

      // Cell background
      const bgColor = condFormat?.bgColor || cell?.style?.bgColor;
      if (bgColor) {
        ctx.fillStyle = bgColor;
        ctx.fillRect(colX, rowY, colW, rowH);
      }

      // PASS 2: Data bar
      if (condFormat?.dataBar) {
        const { ratio, color, zeroAxis, isNegative } = condFormat.dataBar;
        const barMargin = 3;
        const barH = Math.max(4, rowH - barMargin * 2);
        const barY = rowY + barMargin;

        ctx.fillStyle = color;
        if (zeroAxis > 0 && zeroAxis < 1) {
          const axisX = colX + colW * zeroAxis;
          if (isNegative) {
            const barW = (colW * zeroAxis) * ratio;
            ctx.fillRect(axisX - barW, barY, barW, barH);
          } else {
            const barW = (colW * (1 - zeroAxis)) * ratio;
            ctx.fillRect(axisX, barY, barW, barH);
          }
        } else {
          const barW = (colW - 6) * ratio;
          ctx.fillRect(colX + 3, barY, barW, barH);
        }
      }

      // PASS 2: Icon Set
      if (condFormat?.icon) {
        drawCellIcon(ctx, condFormat.icon.type, condFormat.icon.color, colX + 4, rowY + rowH / 2);
      }
    }
  }
  ctx.restore();

  // PASS 3: Gridlines & Frozen borders
  ctx.save();
  ctx.beginPath();
  ctx.rect(grid.headerColWidth, grid.headerRowHeight, width - grid.headerColWidth, height - grid.headerRowHeight);
  ctx.clip();

  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;

  // Vertical grid lines
  for (let c = visible.startCol; c <= visible.endCol + 1; c++) {
    const colX = Math.floor(grid.getColStart(c) - scrollX) + 0.5;
    ctx.beginPath();
    ctx.moveTo(colX, grid.headerRowHeight);
    ctx.lineTo(colX, height);
    ctx.stroke();
  }

  // Horizontal grid lines
  for (let v = visible.startRow; v <= visible.endRow + 1; v++) {
    const rowY = Math.floor(grid.getViewRowStart(v) - scrollY) + 0.5;
    ctx.beginPath();
    ctx.moveTo(grid.headerColWidth, rowY);
    ctx.lineTo(width, rowY);
    ctx.stroke();
  }
  ctx.restore();

  // PASS 4: Cell text, numeric formatting, borders
  ctx.save();
  ctx.beginPath();
  ctx.rect(grid.headerColWidth, grid.headerRowHeight, width - grid.headerColWidth, height - grid.headerRowHeight);
  ctx.clip();

  for (let v = visible.startRow; v <= visible.endRow; v++) {
    const r = grid.viewToDataRow[v];
    if (r === undefined) continue;
    const rowY = grid.getViewRowStart(v) - scrollY;
    const rowH = grid.getRowHeight(r);

    for (let c = visible.startCol; c <= visible.endCol; c++) {
      const colX = grid.getColStart(c) - scrollX;
      const colW = grid.getColWidth(c);
      const cell = sheet.cells[`${r}_${c}`];
      if (!cell) continue;

      const condFormat = conditionalEngine.evaluateCell(r, c, sheet);

      // Custom cell borders
      if (cell.style?.border) {
        drawCellBorders(ctx, colX, rowY, colW, rowH, cell.style.border);
      }

      const val = cell.computed !== undefined ? cell.computed : cell.raw;
      if (val === null || val === undefined || val === '') continue;

      const formatted = formatValue(val, cell.style);
      const isNum = typeof val === 'number' || (!isNaN(Number(val)) && typeof val !== 'boolean' && val !== '');
      const align = cell.style?.align || (isNum ? 'right' : 'left');

      // Font styling
      const isBold = condFormat?.bold || cell.style?.bold;
      const isItalic = cell.style?.italic;
      const fontSize = cell.style?.fontSize || 12;
      const fontFamily = cell.style?.fontFamily || 'Inter, sans-serif';

      ctx.font = `${isBold ? 'bold ' : ''}${isItalic ? 'italic ' : ''}${fontSize}px ${fontFamily}`;
      ctx.fillStyle = cell.error ? '#dc2626' : (condFormat?.textColor || cell.style?.textColor || '#1e293b');
      ctx.textBaseline = 'middle';

      let textX = colX + 6;
      if (condFormat?.icon) {
        textX += 16;
      }

      if (align === 'right') {
        ctx.textAlign = 'right';
        textX = colX + colW - 6;
      } else if (align === 'center') {
        ctx.textAlign = 'center';
        textX = colX + colW / 2;
      } else {
        ctx.textAlign = 'left';
      }

      // Clip individual cell text to not bleed
      ctx.save();
      ctx.beginPath();
      ctx.rect(colX + 2, rowY + 1, colW - 4, rowH - 2);
      ctx.clip();

      const textY = rowY + rowH / 2;
      ctx.fillText(formatted, textX, textY);

      // Strikethrough / Underline
      if (cell.style?.strike || cell.style?.underline) {
        const textW = ctx.measureText(formatted).width;
        let lineX = textX;
        if (align === 'right') lineX = textX - textW;
        else if (align === 'center') lineX = textX - textW / 2;

        ctx.strokeStyle = ctx.fillStyle;
        ctx.lineWidth = 1;
        ctx.beginPath();
        if (cell.style?.strike) {
          ctx.moveTo(lineX, textY);
          ctx.lineTo(lineX + textW, textY);
        }
        if (cell.style?.underline) {
          ctx.moveTo(lineX, textY + fontSize / 2);
          ctx.lineTo(lineX + textW, textY + fontSize / 2);
        }
        ctx.stroke();
      }

      ctx.restore();
    }
  }
  ctx.restore();

  // PASS 5: Selection Box & Autofill Handle & Marching Ants
  ctx.save();
  ctx.beginPath();
  ctx.rect(grid.headerColWidth, grid.headerRowHeight, width - grid.headerColWidth, height - grid.headerRowHeight);
  ctx.clip();

  // Selection Range overlay & border
  if (normSel) {
    const selStartX = grid.getColStart(normSel.startCol) - scrollX;
    const selEndX = grid.getColStart(normSel.endCol) + grid.getColWidth(normSel.endCol) - scrollX;
    const startV = grid.dataToViewRow[normSel.startRow] !== undefined ? grid.dataToViewRow[normSel.startRow] : normSel.startRow;
    const endV = grid.dataToViewRow[normSel.endRow] !== undefined ? grid.dataToViewRow[normSel.endRow] : normSel.endRow;
    const selStartY = grid.getViewRowStart(startV) - scrollY;
    const selEndY = grid.getViewRowStart(endV) + grid.getRowHeight(normSel.endRow) - scrollY;

    const selW = selEndX - selStartX;
    const selH = selEndY - selStartY;

    // Selection background
    ctx.fillStyle = 'rgba(59, 130, 246, 0.1)';
    ctx.fillRect(selStartX, selStartY, selW, selH);

    // Selection border
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 2;
    ctx.strokeRect(selStartX, selStartY, selW, selH);

    // Active cell white fill cutout
    const actV = grid.dataToViewRow[activeCell.row] !== undefined ? grid.dataToViewRow[activeCell.row] : activeCell.row;
    const actX = grid.getColStart(activeCell.col) - scrollX;
    const actY = grid.getViewRowStart(actV) - scrollY;
    const actW = grid.getColWidth(activeCell.col);
    const actH = grid.getRowHeight(activeCell.row);

    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 2;
    ctx.strokeRect(actX, actY, actW, actH);

    // Autofill Handle (bottom-right blue square)
    const handleX = selEndX - 4;
    const handleY = selEndY - 4;
    ctx.fillStyle = '#2563eb';
    ctx.fillRect(handleX, handleY, 7, 7);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.strokeRect(handleX, handleY, 7, 7);
  }

  // Autofill Dragging preview
  if (autofillRange) {
    const aNorm = normalizeRange(autofillRange);
    const aStartX = grid.getColStart(aNorm.startCol) - scrollX;
    const aEndX = grid.getColStart(aNorm.endCol) + grid.getColWidth(aNorm.endCol) - scrollX;
    const aStartV = grid.dataToViewRow[aNorm.startRow] !== undefined ? grid.dataToViewRow[aNorm.startRow] : aNorm.startRow;
    const aEndV = grid.dataToViewRow[aNorm.endRow] !== undefined ? grid.dataToViewRow[aNorm.endRow] : aNorm.endRow;
    const aStartY = grid.getViewRowStart(aStartV) - scrollY;
    const aEndY = grid.getViewRowStart(aEndV) + grid.getRowHeight(aNorm.endRow) - scrollY;

    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(aStartX, aStartY, aEndX - aStartX, aEndY - aStartY);
    ctx.setLineDash([]);
  }

  // Marching Ants for Copied/Cut Range
  if (marchingAnts && marchingAnts.sheetId === sheet.id) {
    const mNorm = normalizeRange(marchingAnts.range);
    const mStartX = grid.getColStart(mNorm.startCol) - scrollX;
    const mEndX = grid.getColStart(mNorm.endCol) + grid.getColWidth(mNorm.endCol) - scrollX;
    const mStartV = grid.dataToViewRow[mNorm.startRow] !== undefined ? grid.dataToViewRow[mNorm.startRow] : mNorm.startRow;
    const mEndV = grid.dataToViewRow[mNorm.endRow] !== undefined ? grid.dataToViewRow[mNorm.endRow] : mNorm.endRow;
    const mStartY = grid.getViewRowStart(mStartV) - scrollY;
    const mEndY = grid.getViewRowStart(mEndV) + grid.getRowHeight(mNorm.endRow) - scrollY;

    ctx.strokeStyle = marchingAnts.isCut ? '#ef4444' : '#2563eb';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -marchingAntsOffset;
    ctx.strokeRect(mStartX, mStartY, mEndX - mStartX, mEndY - mStartY);
    ctx.setLineDash([]);
  }
  ctx.restore();

  // PASS 3 (Headers): Column Headers & Row Headers & Top-Left Corner
  drawHeaders(
    ctx,
    sheet,
    grid,
    visible,
    scrollX,
    scrollY,
    normSel,
    activeCell,
    hoveredColHeader,
    hoveredRowHeader,
    width,
    height
  );

  // PASS 6 & 7: Charts Overlay Layer & Selection handles & tooltips
  ctx.save();
  // Apply scroll translation for charts
  ctx.translate(-scrollX, -scrollY);

  if (sheet.charts && sheet.charts.length > 0) {
    for (const chart of sheet.charts) {
      const isSelected = chart.id === selectedChartId;
      renderChart(ctx, chart, sheet, isSelected, chartHoverInfo);
    }
  }
  ctx.restore();

  ctx.restore();
}

function drawHeaders(
  ctx: CanvasRenderingContext2D,
  sheet: SheetData,
  grid: VirtualGrid,
  visible: any,
  scrollX: number,
  scrollY: number,
  normSel: CellRange | null,
  _activeCell: CellCoord,
  hoveredCol: number | null,
  hoveredRow: number | null,
  width: number,
  height: number
) {
  const { headerColWidth, headerRowHeight } = grid;

  // 1. Column Headers Bar (A, B, C...)
  ctx.save();
  ctx.beginPath();
  ctx.rect(headerColWidth, 0, width - headerColWidth, headerRowHeight);
  ctx.clip();

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(headerColWidth, 0, width - headerColWidth, headerRowHeight);

  for (let c = visible.startCol; c <= visible.endCol; c++) {
    const colX = grid.getColStart(c) - scrollX;
    const colW = grid.getColWidth(c);
    const isColSelected = normSel && c >= normSel.startCol && c <= normSel.endCol;
    const isHovered = hoveredCol === c;

    // Col Header background
    if (isColSelected) {
      ctx.fillStyle = '#dbeafe';
      ctx.fillRect(colX, 0, colW, headerRowHeight);
    } else if (isHovered) {
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(colX, 0, colW, headerRowHeight);
    }

    // Border
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(colX + colW + 0.5, 0);
    ctx.lineTo(colX + colW + 0.5, headerRowHeight);
    ctx.stroke();

    // Col Letter
    ctx.fillStyle = isColSelected ? '#1e40af' : '#475569';
    ctx.font = `${isColSelected ? 'bold ' : ''}11px Inter, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(colIndexToName(c), colX + colW / 2, headerRowHeight / 2);

    // Filter Dropdown Icon ▼
    if (sheet.filters[c] || isHovered) {
      const filterItem = sheet.filters[c];
      const hasActiveFilter = Boolean(filterItem && (filterItem.condition?.type !== 'none' || filterItem.sortOrder || (filterItem.selectedValues && filterItem.selectedValues.size > 0)));
      ctx.fillStyle = hasActiveFilter ? '#2563eb' : '#94a3b8';
      ctx.beginPath();
      const fx = colX + colW - 14;
      const fy = headerRowHeight / 2 - 2;
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx + 8, fy);
      ctx.lineTo(fx + 4, fy + 5);
      ctx.closePath();
      ctx.fill();
    }
  }

  // Bottom border of column headers
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(headerColWidth, headerRowHeight + 0.5);
  ctx.lineTo(width, headerRowHeight + 0.5);
  ctx.stroke();
  ctx.restore();

  // 2. Row Headers Bar (1, 2, 3...)
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, headerRowHeight, headerColWidth, height - headerRowHeight);
  ctx.clip();

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, headerRowHeight, headerColWidth, height - headerRowHeight);

  for (let v = visible.startRow; v <= visible.endRow; v++) {
    const r = grid.viewToDataRow[v];
    if (r === undefined) continue;
    const rowY = grid.getViewRowStart(v) - scrollY;
    const rowH = grid.getRowHeight(r);
    const isRowSelected = normSel && r >= normSel.startRow && r <= normSel.endRow;
    const isHovered = hoveredRow === r;

    // Row Header background
    if (isRowSelected) {
      ctx.fillStyle = '#dbeafe';
      ctx.fillRect(0, rowY, headerColWidth, rowH);
    } else if (isHovered) {
      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(0, rowY, headerColWidth, rowH);
    }

    // Border
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, rowY + rowH + 0.5);
    ctx.lineTo(headerColWidth, rowY + rowH + 0.5);
    ctx.stroke();

    // Row Number (1-indexed)
    ctx.fillStyle = isRowSelected ? '#1e40af' : '#475569';
    ctx.font = `${isRowSelected ? 'bold ' : ''}11px Inter, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`${r + 1}`, headerColWidth / 2, rowY + rowH / 2);
  }

  // Right border of row headers
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(headerColWidth + 0.5, headerRowHeight);
  ctx.lineTo(headerColWidth + 0.5, height);
  ctx.stroke();
  ctx.restore();

  // 3. Top-Left Corner Box (Select-All)
  ctx.fillStyle = '#f1f5f9';
  ctx.fillRect(0, 0, headerColWidth, headerRowHeight);
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, 0.5, headerColWidth, headerRowHeight);

  // Diagonal triangle mark in corner
  ctx.fillStyle = '#94a3b8';
  ctx.beginPath();
  ctx.moveTo(headerColWidth - 4, headerRowHeight - 12);
  ctx.lineTo(headerColWidth - 4, headerRowHeight - 4);
  ctx.lineTo(headerColWidth - 12, headerRowHeight - 4);
  ctx.closePath();
  ctx.fill();
}

function drawCellBorders(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  border: any
) {
  ctx.save();
  if (border.top) {
    ctx.strokeStyle = border.top.color || '#000000';
    ctx.lineWidth = border.top.style === 'thick' ? 2 : 1;
    ctx.beginPath();
    ctx.moveTo(x, y + 0.5);
    ctx.lineTo(x + w, y + 0.5);
    ctx.stroke();
  }
  if (border.bottom) {
    ctx.strokeStyle = border.bottom.color || '#000000';
    ctx.lineWidth = border.bottom.style === 'thick' ? 2 : (border.bottom.style === 'double' ? 3 : 1);
    ctx.beginPath();
    ctx.moveTo(x, y + h - 0.5);
    ctx.lineTo(x + w, y + h - 0.5);
    ctx.stroke();
  }
  if (border.left) {
    ctx.strokeStyle = border.left.color || '#000000';
    ctx.lineWidth = border.left.style === 'thick' ? 2 : 1;
    ctx.beginPath();
    ctx.moveTo(x + 0.5, y);
    ctx.lineTo(x + 0.5, y + h);
    ctx.stroke();
  }
  if (border.right) {
    ctx.strokeStyle = border.right.color || '#000000';
    ctx.lineWidth = border.right.style === 'thick' ? 2 : 1;
    ctx.beginPath();
    ctx.moveTo(x + w - 0.5, y);
    ctx.lineTo(x + w - 0.5, y + h);
    ctx.stroke();
  }
  ctx.restore();
}

function drawCellIcon(ctx: CanvasRenderingContext2D, type: string, color: string, cx: number, cy: number) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = color;

  if (type.startsWith('traffic')) {
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'arrow-up') {
    ctx.beginPath();
    ctx.moveTo(cx, cy - 4);
    ctx.lineTo(cx - 3.5, cy + 3);
    ctx.lineTo(cx + 3.5, cy + 3);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'arrow-down') {
    ctx.beginPath();
    ctx.moveTo(cx, cy + 4);
    ctx.lineTo(cx - 3.5, cy - 3);
    ctx.lineTo(cx + 3.5, cy - 3);
    ctx.closePath();
    ctx.fill();
  } else if (type === 'arrow-right') {
    ctx.beginPath();
    ctx.moveTo(cx + 4, cy);
    ctx.lineTo(cx - 3, cy - 3.5);
    ctx.lineTo(cx - 3, cy + 3.5);
    ctx.closePath();
    ctx.fill();
  } else if (type.startsWith('star')) {
    ctx.beginPath();
    ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
    if (type === 'star-full') ctx.fill();
    else ctx.stroke();
  }
  ctx.restore();
}
