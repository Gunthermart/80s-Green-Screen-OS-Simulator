import { CellRange, SheetData, CellData } from '../types/sheet';
import { normalizeRange, shiftFormula, cellKey } from './formula/utils';

export function executeAutofill(
  sheet: SheetData,
  sourceRange: CellRange,
  targetRange: CellRange
): { modifiedCells: Record<string, CellData>; affectedKeys: string[] } {
  const src = normalizeRange(sourceRange);
  const tgt = normalizeRange(targetRange);

  const modifiedCells: Record<string, CellData> = {};
  const affectedKeys: string[] = [];

  const isVertical = tgt.endRow > src.endRow || tgt.startRow < src.startRow;
  const isHorizontal = tgt.endCol > src.endCol || tgt.startCol < src.startCol;

  const srcHeight = src.endRow - src.startRow + 1;
  const srcWidth = src.endCol - src.startCol + 1;

  if (isVertical) {
    // Fill vertically column by column
    for (let c = tgt.startCol; c <= tgt.endCol; c++) {
      const srcCol = src.startCol + ((c - tgt.startCol) % srcWidth);
      const sourceValues: any[] = [];
      const sourceFormulas: (string | undefined)[] = [];
      const sourceStyles: any[] = [];

      for (let r = src.startRow; r <= src.endRow; r++) {
        const cell = sheet.cells[cellKey(r, srcCol)];
        sourceValues.push(cell?.raw ?? '');
        sourceFormulas.push(cell?.formula);
        sourceStyles.push(cell?.style);
      }

      // Check if source numbers form an arithmetic step
      const numericStep = detectNumericStep(sourceValues);

      for (let r = tgt.startRow; r <= tgt.endRow; r++) {
        if (r >= src.startRow && r <= src.endRow) continue; // skip source area

        const offset = r > src.endRow ? r - src.endRow : r - src.startRow;
        const patternIndex = ((r - src.startRow) % srcHeight + srcHeight) % srcHeight;

        let rawVal: any;
        let formula = sourceFormulas[patternIndex];
        const style = sourceStyles[patternIndex];

        if (formula) {
          const deltaRow = r - (src.startRow + patternIndex);
          const deltaCol = c - srcCol;
          formula = shiftFormula(formula, deltaRow, deltaCol);
          rawVal = formula;
        } else if (numericStep !== null) {
          const baseNum = Number(sourceValues[sourceValues.length - 1]);
          const stepIndex = r > src.endRow ? r - src.endRow : r - src.startRow;
          rawVal = baseNum + numericStep * stepIndex;
        } else {
          // General pattern extrapolation (e.g. "Q1" -> "Q2", "Item 1" -> "Item 2")
          rawVal = extrapolatePattern(sourceValues[patternIndex], offset);
        }

        const key = cellKey(r, c);
        const newCell: CellData = {
          raw: rawVal,
          formula,
          style: style ? { ...style } : undefined,
        };

        sheet.cells[key] = newCell;
        modifiedCells[key] = newCell;
        affectedKeys.push(`${sheet.id}!${key}`);
      }
    }
  } else if (isHorizontal) {
    // Fill horizontally row by row
    for (let r = tgt.startRow; r <= tgt.endRow; r++) {
      const srcRow = src.startRow + ((r - tgt.startRow) % srcHeight);
      const sourceValues: any[] = [];
      const sourceFormulas: (string | undefined)[] = [];
      const sourceStyles: any[] = [];

      for (let c = src.startCol; c <= src.endCol; c++) {
        const cell = sheet.cells[cellKey(srcRow, c)];
        sourceValues.push(cell?.raw ?? '');
        sourceFormulas.push(cell?.formula);
        sourceStyles.push(cell?.style);
      }

      const numericStep = detectNumericStep(sourceValues);

      for (let c = tgt.startCol; c <= tgt.endCol; c++) {
        if (c >= src.startCol && c <= src.endCol) continue;

        const offset = c > src.endCol ? c - src.endCol : c - src.startCol;
        const patternIndex = ((c - src.startCol) % srcWidth + srcWidth) % srcWidth;

        let rawVal: any;
        let formula = sourceFormulas[patternIndex];
        const style = sourceStyles[patternIndex];

        if (formula) {
          const deltaRow = r - srcRow;
          const deltaCol = c - (src.startCol + patternIndex);
          formula = shiftFormula(formula, deltaRow, deltaCol);
          rawVal = formula;
        } else if (numericStep !== null) {
          const baseNum = Number(sourceValues[sourceValues.length - 1]);
          const stepIndex = c > src.endCol ? c - src.endCol : c - src.startCol;
          rawVal = baseNum + numericStep * stepIndex;
        } else {
          rawVal = extrapolatePattern(sourceValues[patternIndex], offset);
        }

        const key = cellKey(r, c);
        const newCell: CellData = {
          raw: rawVal,
          formula,
          style: style ? { ...style } : undefined,
        };

        sheet.cells[key] = newCell;
        modifiedCells[key] = newCell;
        affectedKeys.push(`${sheet.id}!${key}`);
      }
    }
  }

  return { modifiedCells, affectedKeys };
}

function detectNumericStep(vals: any[]): number | null {
  if (vals.length < 2) return null;
  const nums = vals.map(Number);
  if (nums.some(isNaN)) return null;

  const step = nums[1] - nums[0];
  for (let i = 2; i < nums.length; i++) {
    if (Math.abs(nums[i] - nums[i - 1] - step) > 0.0001) {
      return null;
    }
  }
  return step;
}

function extrapolatePattern(val: any, offset: number): any {
  if (val === null || val === undefined) return '';
  const str = String(val);

  // Match e.g. "Item 1" or "T1" or "Q1" or "Mois 1"
  const match = str.match(/^(.*?)(\d+)$/);
  if (match) {
    const prefix = match[1];
    const num = parseInt(match[2], 10);
    return `${prefix}${num + offset}`;
  }

  // Month abbreviations in French/English
  const monthsFr = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sept', 'Oct', 'Nov', 'Déc'];
  const mIdx = monthsFr.findIndex((m) => m.toLowerCase() === str.toLowerCase());
  if (mIdx !== -1) {
    return monthsFr[((mIdx + offset) % 12 + 12) % 12];
  }

  return val;
}
