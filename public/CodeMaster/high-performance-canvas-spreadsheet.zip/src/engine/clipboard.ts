import { CellRange, CellCoord, SheetData, CellData } from '../types/sheet';
import { normalizeRange, shiftFormula, cellKey } from './formula/utils';

export interface ParsedClipboardItem {
  raw: string | number | boolean | null;
  formula?: string;
  style?: any;
}

export function copySelectionToClipboard(
  sheet: SheetData,
  range: CellRange
): { tsv: string; html: string } {
  const norm = normalizeRange(range);
  const tsvRows: string[] = [];
  const htmlRows: string[] = [];

  for (let r = norm.startRow; r <= norm.endRow; r++) {
    const tsvCols: string[] = [];
    const htmlCols: string[] = [];

    for (let c = norm.startCol; c <= norm.endCol; c++) {
      const cell = sheet.cells[cellKey(r, c)];
      const rawVal = cell?.raw ?? '';
      const computedVal = cell?.computed !== undefined ? cell.computed : rawVal;
      const displayVal = String(computedVal ?? '');

      // TSV escaping
      const escapedTsv = displayVal.includes('\t') || displayVal.includes('\n') || displayVal.includes('"')
        ? `"${displayVal.replace(/"/g, '""')}"`
        : displayVal;
      tsvCols.push(escapedTsv);

      // HTML inline style & data-formula
      let styleStr = '';
      if (cell?.style?.bgColor) styleStr += `background-color: ${cell.style.bgColor};`;
      if (cell?.style?.textColor) styleStr += `color: ${cell.style.textColor};`;
      if (cell?.style?.bold) styleStr += `font-weight: bold;`;
      if (cell?.style?.italic) styleStr += `font-style: italic;`;
      if (cell?.style?.align) styleStr += `text-align: ${cell.style.align};`;

      const formulaAttr = cell?.formula ? ` data-formula="${escapeHtml(cell.formula)}"` : '';
      htmlCols.push(`<td style="${styleStr}"${formulaAttr}>${escapeHtml(displayVal)}</td>`);
    }

    tsvRows.push(tsvCols.join('\t'));
    htmlRows.push(`<tr>${htmlCols.join('')}</tr>`);
  }

  const tsv = tsvRows.join('\n');
  const html = `<table>${htmlRows.join('')}</table>`;

  return { tsv, html };
}

export function parseClipboardData(
  tsvText: string,
  htmlText?: string
): ParsedClipboardItem[][] {
  // If rich HTML is available, parse HTML table
  if (htmlText && htmlText.includes('<table')) {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlText, 'text/html');
      const trElements = doc.querySelectorAll('tr');

      if (trElements.length > 0) {
        const matrix: ParsedClipboardItem[][] = [];

        trElements.forEach((tr) => {
          const rowItems: ParsedClipboardItem[] = [];
          const tdElements = tr.querySelectorAll('td, th');

          tdElements.forEach((node) => {
            const td = node as HTMLElement;
            const formula = td.getAttribute('data-formula') || undefined;
            const text = td.textContent || '';
            const style: any = {};

            if (td.style?.backgroundColor) style.bgColor = td.style.backgroundColor;
            if (td.style?.color) style.textColor = td.style.color;
            if (td.style?.fontWeight === 'bold' || (td.style?.fontWeight && parseInt(td.style.fontWeight) >= 600)) style.bold = true;
            if (td.style?.fontStyle === 'italic') style.italic = true;
            if (td.style?.textAlign) style.align = td.style.textAlign as any;

            const num = Number(text);
            const raw = !isNaN(num) && text.trim() !== '' ? num : text;

            rowItems.push({
              raw,
              formula,
              style: Object.keys(style).length > 0 ? style : undefined,
            });
          });

          if (rowItems.length > 0) {
            matrix.push(rowItems);
          }
        });

        if (matrix.length > 0) return matrix;
      }
    } catch {
      // Fallback to TSV
    }
  }

  // Parse TSV fallback
  const lines = tsvText.split(/\r\n|\n|\r/);
  const matrix: ParsedClipboardItem[][] = [];

  for (const line of lines) {
    if (line === '' && matrix.length > 0 && line === lines[lines.length - 1]) continue;
    const cols = line.split('\t');
    const rowItems: ParsedClipboardItem[] = [];

    for (let c = 0; c < cols.length; c++) {
      let str = cols[c];
      // strip surrounding quotes if present
      if (str.startsWith('"') && str.endsWith('"')) {
        str = str.substring(1, str.length - 1).replace(/""/g, '"');
      }

      let formula: string | undefined;
      let raw: string | number = str;

      if (str.startsWith('=')) {
        formula = str;
        raw = str;
      } else {
        const num = Number(str);
        if (!isNaN(num) && str.trim() !== '') {
          raw = num;
        }
      }

      rowItems.push({ raw, formula });
    }

    matrix.push(rowItems);
  }

  return matrix;
}

export function applyPastedData(
  sheet: SheetData,
  matrix: ParsedClipboardItem[][],
  targetCell: CellCoord,
  sourceRange?: CellRange
): { modifiedCells: Record<string, CellData>; affectedKeys: string[] } {
  const modifiedCells: Record<string, CellData> = {};
  const affectedKeys: string[] = [];

  const baseRow = targetCell.row;
  const baseCol = targetCell.col;

  const deltaRow = sourceRange ? baseRow - sourceRange.startRow : 0;
  const deltaCol = sourceRange ? baseCol - sourceRange.startCol : 0;

  for (let r = 0; r < matrix.length; r++) {
    const destRow = baseRow + r;
    if (destRow >= sheet.maxRows) break;

    for (let c = 0; c < matrix[r].length; c++) {
      const destCol = baseCol + c;
      if (destCol >= sheet.maxCols) break;

      const item = matrix[r][c];
      const key = cellKey(destRow, destCol);

      let formula = item.formula;
      if (formula) {
        formula = shiftFormula(formula, deltaRow, deltaCol);
      }

      const existingCell = sheet.cells[key];
      const newCell: CellData = {
        raw: item.raw,
        formula: formula,
        style: item.style ? { ...existingCell?.style, ...item.style } : existingCell?.style,
      };

      sheet.cells[key] = newCell;
      modifiedCells[key] = newCell;
      affectedKeys.push(`${sheet.id}!${key}`);
    }
  }

  return { modifiedCells, affectedKeys };
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
