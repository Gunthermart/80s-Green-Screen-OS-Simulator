import { ConditionalRule, SheetData } from '../types/sheet';
import { parseRange, isCellInRange } from './formula/utils';

export interface EvaluatedFormatting {
  bgColor?: string;
  textColor?: string;
  bold?: boolean;
  dataBar?: {
    ratio: number; // 0 to 1
    zeroAxis: number; // 0 to 1
    color: string;
    isNegative: boolean;
  };
  icon?: {
    type: 'arrow-up' | 'arrow-right' | 'arrow-down' | 'traffic-green' | 'traffic-yellow' | 'traffic-red' | 'star-full' | 'star-half' | 'star-empty';
    color: string;
  };
}

export class ConditionalFormattingEngine {
  // Cache range statistics (min, max, values) per rule ID
  private statsCache: Map<string, { min: number; max: number; count: number; values: number[] }> = new Map();

  clearCache() {
    this.statsCache.clear();
  }

  // Pre-calculate min/max for range-based rules (color scales, data bars, icon sets)
  private getRangeStats(rule: ConditionalRule, sheet: SheetData): { min: number; max: number; count: number; values: number[] } {
    if (this.statsCache.has(rule.id)) {
      return this.statsCache.get(rule.id)!;
    }

    const range = parseRange(rule.targetRange);
    if (!range) {
      const fallback = { min: 0, max: 100, count: 0, values: [] };
      this.statsCache.set(rule.id, fallback);
      return fallback;
    }

    const values: number[] = [];
    for (let r = range.startRow; r <= range.endRow; r++) {
      for (let c = range.startCol; c <= range.endCol; c++) {
        const cell = sheet.cells[`${r}_${c}`];
        if (cell) {
          const val = cell.computed !== undefined ? cell.computed : cell.raw;
          const num = Number(val);
          if (!isNaN(num) && typeof val !== 'boolean' && val !== null && val !== '') {
            values.push(num);
          }
        }
      }
    }

    let min = values.length > 0 ? Math.min(...values) : 0;
    let max = values.length > 0 ? Math.max(...values) : 100;
    if (min === max) {
      max = min + 1;
    }

    const stats = { min, max, count: values.length, values };
    this.statsCache.set(rule.id, stats);
    return stats;
  }

  // Interpolate color between hex codes
  private interpolateColor(color1: string, color2: string, factor: number): string {
    const f = Math.max(0, Math.min(1, factor));
    const parseHex = (hex: string) => {
      let h = hex.replace('#', '');
      if (h.length === 3) h = h.split('').map((c) => c + c).join('');
      const n = parseInt(h, 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    };

    const c1 = parseHex(color1);
    const c2 = parseHex(color2);

    const r = Math.round(c1.r + (c2.r - c1.r) * f);
    const g = Math.round(c1.g + (c2.g - c1.g) * f);
    const b = Math.round(c1.b + (c2.b - c1.b) * f);

    return `rgb(${r}, ${g}, ${b})`;
  }

  // Evaluate all rules applicable to a single cell
  evaluateCell(row: number, col: number, sheet: SheetData): EvaluatedFormatting | null {
    if (!sheet.conditionalRules || sheet.conditionalRules.length === 0) {
      return null;
    }

    const cell = sheet.cells[`${row}_${col}`];
    const val = cell?.computed !== undefined ? cell.computed : cell?.raw;
    const num = Number(val);
    const isNum = !isNaN(num) && typeof val !== 'boolean' && val !== null && val !== '';

    let result: EvaluatedFormatting | null = null;

    for (const rule of sheet.conditionalRules) {
      const range = parseRange(rule.targetRange);
      if (!range || !isCellInRange(row, col, range)) {
        continue;
      }

      if (!result) result = {};

      switch (rule.type) {
        case 'greaterThan': {
          const threshold = Number(rule.value1);
          if (isNum && num > threshold) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'lessThan': {
          const threshold = Number(rule.value1);
          if (isNum && num < threshold) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'between': {
          const min = Number(rule.value1);
          const max = Number(rule.value2);
          if (isNum && num >= min && num <= max) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'equal': {
          if (String(val).toLowerCase() === String(rule.value1).toLowerCase()) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'notEqual': {
          if (String(val).toLowerCase() !== String(rule.value1).toLowerCase()) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'textContains': {
          const query = String(rule.value1 || '').toLowerCase();
          if (String(val ?? '').toLowerCase().includes(query)) {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'isEmpty': {
          if (val === null || val === undefined || val === '') {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'notEmpty': {
          if (val !== null && val !== undefined && val !== '') {
            result.bgColor = rule.style?.bgColor || result.bgColor;
            result.textColor = rule.style?.textColor || result.textColor;
            result.bold = rule.style?.bold ?? result.bold;
          }
          break;
        }

        case 'colorScale': {
          if (isNum && rule.colorScale) {
            const stats = this.getRangeStats(rule, sheet);
            const { min, max } = stats;
            const factor = max > min ? (num - min) / (max - min) : 0.5;

            if (rule.colorScale.midColor) {
              // 3-color scale
              if (factor <= 0.5) {
                result.bgColor = this.interpolateColor(
                  rule.colorScale.minColor,
                  rule.colorScale.midColor,
                  factor * 2
                );
              } else {
                result.bgColor = this.interpolateColor(
                  rule.colorScale.midColor,
                  rule.colorScale.maxColor,
                  (factor - 0.5) * 2
                );
              }
            } else {
              // 2-color scale
              result.bgColor = this.interpolateColor(
                rule.colorScale.minColor,
                rule.colorScale.maxColor,
                factor
              );
            }
          }
          break;
        }

        case 'dataBar': {
          if (isNum && rule.dataBar) {
            const stats = this.getRangeStats(rule, sheet);
            const { min, max } = stats;

            let zeroAxis = 0;
            let ratio = 0;
            const isNegative = num < 0;

            if (min < 0 && max > 0) {
              const span = max - min;
              zeroAxis = Math.abs(min) / span;
              if (num >= 0) {
                ratio = num / max;
              } else {
                ratio = Math.abs(num) / Math.abs(min);
              }
            } else if (min >= 0) {
              zeroAxis = 0;
              ratio = (num - min) / (max - min || 1);
            } else {
              zeroAxis = 1;
              ratio = (max - num) / (max - min || 1);
            }

            result.dataBar = {
              ratio: Math.max(0, Math.min(1, ratio)),
              zeroAxis,
              color: isNegative ? rule.dataBar.negativeColor : rule.dataBar.positiveColor,
              isNegative,
            };
          }
          break;
        }

        case 'iconSet': {
          if (isNum && rule.iconSet) {
            const stats = this.getRangeStats(rule, sheet);
            const { min, max } = stats;
            const factor = (num - min) / (max - min || 1);

            if (rule.iconSet.iconType === 'traffic') {
              if (factor >= 0.66) {
                result.icon = { type: 'traffic-green', color: '#10b981' };
              } else if (factor >= 0.33) {
                result.icon = { type: 'traffic-yellow', color: '#f59e0b' };
              } else {
                result.icon = { type: 'traffic-red', color: '#ef4444' };
              }
            } else if (rule.iconSet.iconType === 'stars') {
              if (factor >= 0.66) {
                result.icon = { type: 'star-full', color: '#f59e0b' };
              } else if (factor >= 0.33) {
                result.icon = { type: 'star-half', color: '#f59e0b' };
              } else {
                result.icon = { type: 'star-empty', color: '#94a3b8' };
              }
            } else {
              // Default arrows
              if (factor >= 0.66) {
                result.icon = { type: 'arrow-up', color: '#10b981' };
              } else if (factor >= 0.33) {
                result.icon = { type: 'arrow-right', color: '#f59e0b' };
              } else {
                result.icon = { type: 'arrow-down', color: '#ef4444' };
              }
            }
          }
          break;
        }
      }
    }

    return result;
  }
}
