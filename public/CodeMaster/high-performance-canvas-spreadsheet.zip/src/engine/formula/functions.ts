export type FunctionHandler = (args: any[], context: FormulaContext) => any;

export interface FormulaContext {
  resolveCell: (row: number, col: number, sheetName?: string) => any;
  resolveRange: (startRow: number, startCol: number, endRow: number, endCol: number, sheetName?: string) => any[][];
  currentSheet: string;
}

// Flatten nested arrays and extract numeric values
function flattenNumbers(args: any[]): number[] {
  const result: number[] = [];
  function rec(item: any) {
    if (Array.isArray(item)) {
      for (const el of item) rec(el);
    } else if (item !== null && item !== undefined && item !== '') {
      const num = Number(item);
      if (!isNaN(num) && typeof item !== 'boolean') {
        result.push(num);
      }
    }
  }
  rec(args);
  return result;
}

function flattenAll(args: any[]): any[] {
  const result: any[] = [];
  function rec(item: any) {
    if (Array.isArray(item)) {
      for (const el of item) rec(el);
    } else {
      result.push(item);
    }
  }
  rec(args);
  return result;
}

export const builtInFunctions: Record<string, FunctionHandler> = {
  // MATH & STATS
  SUM: (args) => {
    const nums = flattenNumbers(args);
    return nums.reduce((acc, n) => acc + n, 0);
  },

  AVERAGE: (args) => {
    const nums = flattenNumbers(args);
    if (nums.length === 0) return '#DIV/0!';
    return nums.reduce((acc, n) => acc + n, 0) / nums.length;
  },

  MIN: (args) => {
    const nums = flattenNumbers(args);
    if (nums.length === 0) return 0;
    return Math.min(...nums);
  },

  MAX: (args) => {
    const nums = flattenNumbers(args);
    if (nums.length === 0) return 0;
    return Math.max(...nums);
  },

  COUNT: (args) => {
    const nums = flattenNumbers(args);
    return nums.length;
  },

  COUNTA: (args) => {
    const items = flattenAll(args);
    return items.filter((x) => x !== null && x !== undefined && x !== '').length;
  },

  PRODUCT: (args) => {
    const nums = flattenNumbers(args);
    if (nums.length === 0) return 0;
    return nums.reduce((acc, n) => acc * n, 1);
  },

  MEDIAN: (args) => {
    const nums = flattenNumbers(args).sort((a, b) => a - b);
    if (nums.length === 0) return '#VALUE!';
    const mid = Math.floor(nums.length / 2);
    return nums.length % 2 !== 0 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
  },

  STDEV: (args) => {
    const nums = flattenNumbers(args);
    if (nums.length < 2) return '#DIV/0!';
    const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
    const variance = nums.reduce((sum, n) => sum + Math.pow(n - mean, 2), 0) / (nums.length - 1);
    return Math.sqrt(variance);
  },

  ROUND: (args) => {
    const val = Number(args[0]);
    const dec = args[1] !== undefined ? Number(args[1]) : 0;
    if (isNaN(val) || isNaN(dec)) return '#VALUE!';
    const factor = Math.pow(10, dec);
    return Math.round(val * factor) / factor;
  },

  ROUNDUP: (args) => {
    const val = Number(args[0]);
    const dec = args[1] !== undefined ? Number(args[1]) : 0;
    const factor = Math.pow(10, dec);
    return Math.ceil(val * factor) / factor;
  },

  ROUNDDOWN: (args) => {
    const val = Number(args[0]);
    const dec = args[1] !== undefined ? Number(args[1]) : 0;
    const factor = Math.pow(10, dec);
    return Math.floor(val * factor) / factor;
  },

  ABS: (args) => {
    const val = Number(args[0]);
    return isNaN(val) ? '#VALUE!' : Math.abs(val);
  },

  SQRT: (args) => {
    const val = Number(args[0]);
    if (val < 0) return '#NUM!';
    return isNaN(val) ? '#VALUE!' : Math.sqrt(val);
  },

  POWER: (args) => {
    const base = Number(args[0]);
    const exp = Number(args[1]);
    return Math.pow(base, exp);
  },

  MOD: (args) => {
    const n = Number(args[0]);
    const d = Number(args[1]);
    if (d === 0) return '#DIV/0!';
    return n % d;
  },

  // LOGICAL
  IF: (args) => {
    const condition = Boolean(args[0]);
    return condition ? args[1] : (args[2] !== undefined ? args[2] : false);
  },

  IFS: (args) => {
    for (let i = 0; i < args.length; i += 2) {
      if (Boolean(args[i])) {
        return args[i + 1];
      }
    }
    return '#N/A';
  },

  AND: (args) => {
    const items = flattenAll(args);
    return items.every((x) => Boolean(x));
  },

  OR: (args) => {
    const items = flattenAll(args);
    return items.some((x) => Boolean(x));
  },

  NOT: (args) => {
    return !Boolean(args[0]);
  },

  IFERROR: (args) => {
    const val = args[0];
    if (typeof val === 'string' && val.startsWith('#')) {
      return args[1] !== undefined ? args[1] : '';
    }
    return val;
  },

  ISBLANK: (args) => {
    return args[0] === null || args[0] === undefined || args[0] === '';
  },

  ISNUMBER: (args) => {
    return typeof args[0] === 'number' && !isNaN(args[0]);
  },

  ISTEXT: (args) => {
    return typeof args[0] === 'string' && !args[0].startsWith('#');
  },

  // TEXT
  CONCATENATE: (args) => {
    const items = flattenAll(args);
    return items.map((x) => (x !== null && x !== undefined ? String(x) : '')).join('');
  },

  CONCAT: (args) => {
    const items = flattenAll(args);
    return items.map((x) => (x !== null && x !== undefined ? String(x) : '')).join('');
  },

  TEXT: (args) => {
    const val = args[0];
    return val !== null && val !== undefined ? String(val) : '';
  },

  LEFT: (args) => {
    const str = String(args[0] ?? '');
    const count = args[1] !== undefined ? Number(args[1]) : 1;
    return str.substring(0, count);
  },

  RIGHT: (args) => {
    const str = String(args[0] ?? '');
    const count = args[1] !== undefined ? Number(args[1]) : 1;
    return str.substring(Math.max(0, str.length - count));
  },

  MID: (args) => {
    const str = String(args[0] ?? '');
    const start = Number(args[1]) - 1; // 1-indexed to 0-indexed
    const len = Number(args[2]);
    return str.substring(start, start + len);
  },

  LEN: (args) => {
    const str = String(args[0] ?? '');
    return str.length;
  },

  UPPER: (args) => {
    return String(args[0] ?? '').toUpperCase();
  },

  LOWER: (args) => {
    return String(args[0] ?? '').toLowerCase();
  },

  TRIM: (args) => {
    return String(args[0] ?? '').trim();
  },

  SUBSTITUTE: (args) => {
    const str = String(args[0] ?? '');
    const oldText = String(args[1] ?? '');
    const newText = String(args[2] ?? '');
    return str.split(oldText).join(newText);
  },

  // LOOKUP & REFERENCE
  VLOOKUP: (args) => {
    const lookupVal = args[0];
    const tableRange = args[1]; // matrix 2D
    const colIndex = Number(args[2]); // 1-indexed
    const exactMatch = args[3] !== undefined ? !Boolean(args[3]) : false; // default exact in spreadsheets if false

    if (!Array.isArray(tableRange) || tableRange.length === 0) return '#REF!';
    if (colIndex < 1 || colIndex > tableRange[0].length) return '#REF!';

    const searchStr = String(lookupVal).toLowerCase();

    for (let r = 0; r < tableRange.length; r++) {
      const firstColVal = tableRange[r][0];
      if (firstColVal === lookupVal || (exactMatch && String(firstColVal).toLowerCase() === searchStr)) {
        return tableRange[r][colIndex - 1];
      }
      if (String(firstColVal).toLowerCase() === searchStr) {
        return tableRange[r][colIndex - 1];
      }
    }
    return '#N/A';
  },

  XLOOKUP: (args) => {
    const lookupVal = args[0];
    const lookupArray = flattenAll([args[1]]);
    const returnArray = flattenAll([args[2]]);
    const ifNotFound = args[3] !== undefined ? args[3] : '#N/A';

    const searchStr = String(lookupVal).toLowerCase();
    for (let i = 0; i < lookupArray.length; i++) {
      if (lookupArray[i] === lookupVal || String(lookupArray[i]).toLowerCase() === searchStr) {
        return returnArray[i] !== undefined ? returnArray[i] : null;
      }
    }
    return ifNotFound;
  },

  INDEX: (args) => {
    const matrix = args[0];
    const rowNum = Number(args[1]); // 1-indexed
    const colNum = args[2] !== undefined ? Number(args[2]) : 1; // 1-indexed

    if (!Array.isArray(matrix) || matrix.length === 0) return '#REF!';
    const r = rowNum - 1;
    const c = colNum - 1;

    if (r < 0 || r >= matrix.length) return '#REF!';
    const row = matrix[r];
    if (Array.isArray(row)) {
      if (c < 0 || c >= row.length) return '#REF!';
      return row[c];
    }
    return row;
  },

  MATCH: (args) => {
    const lookupVal = args[0];
    const lookupArray = flattenAll([args[1]]);
    const searchStr = String(lookupVal).toLowerCase();

    for (let i = 0; i < lookupArray.length; i++) {
      if (lookupArray[i] === lookupVal || String(lookupArray[i]).toLowerCase() === searchStr) {
        return i + 1; // 1-indexed position
      }
    }
    return '#N/A';
  },

  // DATE
  TODAY: () => {
    const now = new Date();
    // Days since 1900-01-01
    return Math.floor((now.getTime() - new Date(1900, 0, 1).getTime()) / (86400 * 1000)) + 2;
  },

  NOW: () => {
    const now = new Date();
    return Math.floor((now.getTime() - new Date(1900, 0, 1).getTime()) / (86400 * 1000)) + 2;
  },

  YEAR: (args) => {
    const val = Number(args[0]);
    if (isNaN(val)) return '#VALUE!';
    const d = new Date((val - 25569) * 86400 * 1000);
    return d.getFullYear();
  },

  MONTH: (args) => {
    const val = Number(args[0]);
    if (isNaN(val)) return '#VALUE!';
    const d = new Date((val - 25569) * 86400 * 1000);
    return d.getMonth() + 1;
  },

  DAY: (args) => {
    const val = Number(args[0]);
    if (isNaN(val)) return '#VALUE!';
    const d = new Date((val - 25569) * 86400 * 1000);
    return d.getDate();
  },
};
