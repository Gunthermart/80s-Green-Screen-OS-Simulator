export type ASTNode =
  | { type: 'number'; value: number }
  | { type: 'string'; value: string }
  | { type: 'boolean'; value: boolean }
  | { type: 'cell'; ref: string; col: number; row: number; sheetName?: string }
  | { type: 'range'; ref: string; startRow: number; startCol: number; endRow: number; endCol: number; sheetName?: string }
  | { type: 'unary'; operator: '+' | '-'; right: ASTNode }
  | { type: 'binary'; operator: '+' | '-' | '*' | '/' | '^' | '&' | '=' | '<>' | '!=' | '<' | '<=' | '>' | '>='; left: ASTNode; right: ASTNode }
  | { type: 'function'; name: string; args: ASTNode[] };

import { parseCellRef, parseRange } from './utils';

export function parseFormula(input: string): ASTNode {
  let text = input.trim();
  if (text.startsWith('=')) {
    text = text.substring(1).trim();
  }
  if (!text) {
    return { type: 'string', value: '' };
  }

  let pos = 0;

  function peek(): string {
    return text[pos] || '';
  }

  function skipWhitespace() {
    while (pos < text.length && /\s/.test(text[pos])) {
      pos++;
    }
  }

  function parseExpression(): ASTNode {
    return parseComparison();
  }

  function parseComparison(): ASTNode {
    let left = parseConcatenation();
    skipWhitespace();

    while (pos < text.length) {
      skipWhitespace();
      const next2 = text.substring(pos, pos + 2);
      if (next2 === '<=' || next2 === '>=' || next2 === '<>' || next2 === '!=') {
        pos += 2;
        const right = parseConcatenation();
        left = { type: 'binary', operator: next2 as any, left, right };
      } else if (peek() === '=' || peek() === '<' || peek() === '>') {
        const op = peek();
        pos++;
        const right = parseConcatenation();
        left = { type: 'binary', operator: op as any, left, right };
      } else {
        break;
      }
    }
    return left;
  }

  function parseConcatenation(): ASTNode {
    let left = parseAdditive();
    skipWhitespace();

    while (peek() === '&') {
      pos++;
      const right = parseAdditive();
      left = { type: 'binary', operator: '&', left, right };
      skipWhitespace();
    }
    return left;
  }

  function parseAdditive(): ASTNode {
    let left = parseMultiplicative();
    skipWhitespace();

    while (peek() === '+' || peek() === '-') {
      const op = peek() as '+' | '-';
      pos++;
      const right = parseMultiplicative();
      left = { type: 'binary', operator: op, left, right };
      skipWhitespace();
    }
    return left;
  }

  function parseMultiplicative(): ASTNode {
    let left = parseExponentiation();
    skipWhitespace();

    while (peek() === '*' || peek() === '/') {
      const op = peek() as '*' | '/';
      pos++;
      const right = parseExponentiation();
      left = { type: 'binary', operator: op, left, right };
      skipWhitespace();
    }
    return left;
  }

  function parseExponentiation(): ASTNode {
    let left = parseUnary();
    skipWhitespace();

    if (peek() === '^') {
      pos++;
      const right = parseExponentiation(); // right-associative
      return { type: 'binary', operator: '^', left, right };
    }
    return left;
  }

  function parseUnary(): ASTNode {
    skipWhitespace();
    if (peek() === '+' || peek() === '-') {
      const op = peek() as '+' | '-';
      pos++;
      const right = parseUnary();
      return { type: 'unary', operator: op, right };
    }
    return parsePrimary();
  }

  function parsePrimary(): ASTNode {
    skipWhitespace();
    const ch = peek();

    // Grouping: ( ... )
    if (ch === '(') {
      pos++;
      const expr = parseExpression();
      skipWhitespace();
      if (peek() === ')') {
        pos++;
      }
      return expr;
    }

    // String literal: "..."
    if (ch === '"') {
      pos++;
      let str = '';
      while (pos < text.length) {
        if (text[pos] === '"') {
          if (text[pos + 1] === '"') {
            str += '"';
            pos += 2;
          } else {
            pos++;
            break;
          }
        } else {
          str += text[pos];
          pos++;
        }
      }
      return { type: 'string', value: str };
    }

    // Number literal: 123 or 123.45
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(text[pos + 1] || ''))) {
      let numStr = '';
      while (pos < text.length && /[0-9.]/.test(text[pos])) {
        numStr += text[pos];
        pos++;
      }
      return { type: 'number', value: parseFloat(numStr) };
    }

    // Identifiers: cell references, ranges, functions, booleans (TRUE/FALSE)
    let ident = '';
    while (pos < text.length && /[A-Za-z0-9_$'!]/.test(text[pos])) {
      ident += text[pos];
      pos++;
    }

    if (ident) {
      skipWhitespace();

      // Check if this is a function call: IDENT(...)
      if (peek() === '(') {
        pos++; // consume '('
        const args: ASTNode[] = [];
        skipWhitespace();
        if (peek() !== ')') {
          while (pos < text.length) {
            args.push(parseExpression());
            skipWhitespace();
            // Accept both ',' and ';' as function parameter separators
            if (peek() === ',' || peek() === ';') {
              pos++;
            } else {
              break;
            }
          }
        }
        if (peek() === ')') {
          pos++;
        }
        return { type: 'function', name: ident.toUpperCase(), args };
      }

      // Check boolean constants
      const upper = ident.toUpperCase();
      if (upper === 'TRUE') return { type: 'boolean', value: true };
      if (upper === 'FALSE') return { type: 'boolean', value: false };

      // Check if it's a range like A1:B10
      skipWhitespace();
      if (peek() === ':') {
        pos++; // consume ':'
        skipWhitespace();
        let endIdent = '';
        while (pos < text.length && /[A-Za-z0-9_$'!]/.test(text[pos])) {
          endIdent += text[pos];
          pos++;
        }
        const fullRange = `${ident}:${endIdent}`;
        const rangeObj = parseRange(fullRange);
        if (rangeObj) {
          return {
            type: 'range',
            ref: fullRange,
            startRow: rangeObj.startRow,
            startCol: rangeObj.startCol,
            endRow: rangeObj.endRow,
            endCol: rangeObj.endCol,
            sheetName: rangeObj.sheetName,
          };
        }
      }

      // Single cell reference or standalone range
      const rangeObj = parseRange(ident);
      if (rangeObj) {
        if (rangeObj.startRow === rangeObj.endRow && rangeObj.startCol === rangeObj.endCol) {
          return {
            type: 'cell',
            ref: ident,
            row: rangeObj.startRow,
            col: rangeObj.startCol,
            sheetName: rangeObj.sheetName,
          };
        }
        return {
          type: 'range',
          ref: ident,
          startRow: rangeObj.startRow,
          startCol: rangeObj.startCol,
          endRow: rangeObj.endRow,
          endCol: rangeObj.endCol,
          sheetName: rangeObj.sheetName,
        };
      }

      const cellRef = parseCellRef(ident);
      if (cellRef) {
        return {
          type: 'cell',
          ref: ident,
          row: cellRef.row,
          col: cellRef.col,
          sheetName: cellRef.sheetName,
        };
      }

      return { type: 'string', value: ident };
    }

    // Default fallback
    if (pos < text.length) {
      pos++;
    }
    return { type: 'string', value: '' };
  }

  return parseExpression();
}
