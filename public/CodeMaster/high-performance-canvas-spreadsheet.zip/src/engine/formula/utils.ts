import { CellCoord, CellRange, CellStyle, NumberFormatType } from '../../types/sheet';

export function cellKey(row: number, col: number): string {
  return `${row}_${col}`;
}

export function parseKey(key: string): CellCoord {
  const [r, c] = key.split('_').map(Number);
  return { row: r, col: c };
}

export function colIndexToName(col: number): string {
  let name = '';
  let c = col;
  while (c >= 0) {
    name = String.fromCharCode((c % 26) + 65) + name;
    c = Math.floor(c / 26) - 1;
  }
  return name;
}

export function nameToColIndex(name: string): number {
  let col = 0;
  const upper = name.toUpperCase();
  for (let i = 0; i < upper.length; i++) {
    col = col * 26 + (upper.charCodeAt(i) - 64);
  }
  return col - 1;
}

export interface ParsedRef {
  sheetName?: string;
  col: number;
  row: number;
  absCol: boolean;
  absRow: boolean;
  raw: string;
}

export function parseCellRef(ref: string): ParsedRef | null {
  const match = ref.trim().match(/^(?:'([^']+)'!|([A-Za-z0-9_]+)!)?(\$?)([A-Za-z]+)(\$?)([0-9]+)$/);
  if (!match) return null;

  const sheetName = match[1] || match[2];
  const absCol = match[3] === '$';
  const colStr = match[4];
  const absRow = match[5] === '$';
  const rowStr = match[6];

  const col = nameToColIndex(colStr);
  const row = parseInt(rowStr, 10) - 1;

  return {
    sheetName,
    col,
    row,
    absCol,
    absRow,
    raw: ref,
  };
}

export function parseRange(rangeStr: string): (CellRange & { sheetName?: string }) | null {
  if (!rangeStr) return null;
  const trimmed = rangeStr.trim();
  
  // Sheet prefix check
  let sheetName: string | undefined;
  let cleanRange = trimmed;
  const sheetMatch = trimmed.match(/^(?:'([^']+)'!|([A-Za-z0-9_]+)!)(.*)$/);
  if (sheetMatch) {
    sheetName = sheetMatch[1] || sheetMatch[2];
    cleanRange = sheetMatch[3];
  }

  const parts = cleanRange.split(':');
  if (parts.length === 1) {
    const p = parseCellRef(parts[0]);
    if (!p) return null;
    return {
      sheetName: p.sheetName || sheetName,
      startRow: p.row,
      startCol: p.col,
      endRow: p.row,
      endCol: p.col,
    };
  } else if (parts.length === 2) {
    const p1 = parseCellRef(parts[0]);
    const p2 = parseCellRef(parts[1]);
    if (!p1 || !p2) return null;

    return {
      sheetName: p1.sheetName || sheetName,
      startRow: Math.min(p1.row, p2.row),
      startCol: Math.min(p1.col, p2.col),
      endRow: Math.max(p1.row, p2.row),
      endCol: Math.max(p1.col, p2.col),
    };
  }
  return null;
}

export function formatRange(range: CellRange): string {
  const start = `${colIndexToName(range.startCol)}${range.startRow + 1}`;
  const end = `${colIndexToName(range.endCol)}${range.endRow + 1}`;
  if (range.startCol === range.endCol && range.startRow === range.endRow) {
    return start;
  }
  return `${start}:${end}`;
}

export function normalizeRange(range: CellRange): CellRange {
  return {
    startRow: Math.min(range.startRow, range.endRow),
    startCol: Math.min(range.startCol, range.endCol),
    endRow: Math.max(range.startRow, range.endRow),
    endCol: Math.max(range.startCol, range.endCol),
  };
}

export function isCellInRange(row: number, col: number, range: CellRange): boolean {
  const norm = normalizeRange(range);
  return row >= norm.startRow && row <= norm.endRow && col >= norm.startCol && col <= norm.endCol;
}

export function shiftFormula(formula: string, deltaRow: number, deltaCol: number): string {
  if (!formula.startsWith('=')) return formula;

  // Regex matches cell references like $A$1, A1, Sheet1!A1, A1:B10
  const refRegex = /(?:('?[A-Za-z0-9_ ]+'?!)?)(\$?)([A-Za-z]+)(\$?)([0-9]+)/g;

  return formula.replace(refRegex, (_match, sheet, absColMark, colStr, absRowMark, rowStr) => {
    const absCol = absColMark === '$';
    const absRow = absRowMark === '$';

    let col = nameToColIndex(colStr);
    let row = parseInt(rowStr, 10) - 1;

    if (!absCol) {
      col = Math.max(0, col + deltaCol);
    }
    if (!absRow) {
      row = Math.max(0, row + deltaRow);
    }

    const newColStr = colIndexToName(col);
    const newRowStr = (row + 1).toString();
    const prefix = sheet || '';

    return `${prefix}${absCol ? '$' : ''}${newColStr}${absRow ? '$' : ''}${newRowStr}`;
  });
}

export function formatValue(val: any, style?: CellStyle): string {
  if (val === null || val === undefined || val === '') return '';
  if (typeof val === 'string' && val.startsWith('#')) return val; // Errors like #DIV/0!

  const format: NumberFormatType = style?.format || 'general';
  const precision = style?.precision !== undefined ? style.precision : 2;

  const num = typeof val === 'number' ? val : Number(val);
  const isNum = !isNaN(num) && typeof val !== 'boolean' && val !== '';

  if (!isNum) {
    return String(val);
  }

  switch (format) {
    case 'currency_eur':
      return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'EUR',
        minimumFractionDigits: precision,
        maximumFractionDigits: precision,
      }).format(num);

    case 'currency_usd':
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: precision,
        maximumFractionDigits: precision,
      }).format(num);

    case 'percent':
      return (
        new Intl.NumberFormat('fr-FR', {
          minimumFractionDigits: precision,
          maximumFractionDigits: precision,
        }).format(num * 100) + ' %'
      );

    case 'number':
      return new Intl.NumberFormat('fr-FR', {
        minimumFractionDigits: precision,
        maximumFractionDigits: precision,
      }).format(num);

    case 'scientific':
      return num.toExponential(precision);

    case 'date':
      if (typeof val === 'number') {
        // Excel serial date starting 1900
        const date = new Date((val - 25569) * 86400 * 1000);
        return date.toLocaleDateString('fr-FR');
      }
      return String(val);

    case 'text':
    case 'general':
    default:
      if (Number.isInteger(num)) {
        return num.toString();
      }
      // Compact decimal notation without trailing zeros
      return Math.round(num * 100000) / 100000 + '';
  }
}
