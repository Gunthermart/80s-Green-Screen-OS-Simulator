import { ASTNode } from './parser';
import { builtInFunctions, FormulaContext } from './functions';

export function evaluateAST(
  node: ASTNode,
  context: FormulaContext,
  visitedKeys: Set<string> = new Set()
): any {
  if (!node) return null;

  switch (node.type) {
    case 'number':
    case 'string':
    case 'boolean':
      return node.value;

    case 'cell': {
      const sheet = node.sheetName || context.currentSheet;
      const key = `${sheet}!${node.row}_${node.col}`;
      if (visitedKeys.has(key)) {
        return '#CIRCULAR!';
      }
      visitedKeys.add(key);
      const val = context.resolveCell(node.row, node.col, node.sheetName);
      visitedKeys.delete(key);
      return val;
    }

    case 'range': {
      return context.resolveRange(
        node.startRow,
        node.startCol,
        node.endRow,
        node.endCol,
        node.sheetName
      );
    }

    case 'unary': {
      const val = evaluateAST(node.right, context, visitedKeys);
      if (typeof val === 'string' && val.startsWith('#')) return val;
      const num = Number(val);
      if (isNaN(num)) return '#VALUE!';
      return node.operator === '-' ? -num : num;
    }

    case 'binary': {
      const leftVal = evaluateAST(node.left, context, visitedKeys);
      if (typeof leftVal === 'string' && leftVal.startsWith('#')) return leftVal;

      const rightVal = evaluateAST(node.right, context, visitedKeys);
      if (typeof rightVal === 'string' && rightVal.startsWith('#')) return rightVal;

      switch (node.operator) {
        case '&':
          return `${leftVal ?? ''}${rightVal ?? ''}`;

        case '+': {
          const l = leftVal === '' || leftVal === null ? 0 : Number(leftVal);
          const r = rightVal === '' || rightVal === null ? 0 : Number(rightVal);
          if (isNaN(l) || isNaN(r)) return '#VALUE!';
          return l + r;
        }

        case '-': {
          const l = leftVal === '' || leftVal === null ? 0 : Number(leftVal);
          const r = rightVal === '' || rightVal === null ? 0 : Number(rightVal);
          if (isNaN(l) || isNaN(r)) return '#VALUE!';
          return l - r;
        }

        case '*': {
          const l = leftVal === '' || leftVal === null ? 0 : Number(leftVal);
          const r = rightVal === '' || rightVal === null ? 0 : Number(rightVal);
          if (isNaN(l) || isNaN(r)) return '#VALUE!';
          return l * r;
        }

        case '/': {
          const l = leftVal === '' || leftVal === null ? 0 : Number(leftVal);
          const r = rightVal === '' || rightVal === null ? 0 : Number(rightVal);
          if (isNaN(l) || isNaN(r)) return '#VALUE!';
          if (r === 0) return '#DIV/0!';
          return l / r;
        }

        case '^': {
          const l = Number(leftVal);
          const r = Number(rightVal);
          if (isNaN(l) || isNaN(r)) return '#VALUE!';
          return Math.pow(l, r);
        }

        case '=':
          return leftVal == rightVal;

        case '<>':
        case '!=':
          return leftVal != rightVal;

        case '<':
          return Number(leftVal) < Number(rightVal);

        case '<=':
          return Number(leftVal) <= Number(rightVal);

        case '>':
          return Number(leftVal) > Number(rightVal);

        case '>=':
          return Number(leftVal) >= Number(rightVal);

        default:
          return '#VALUE!';
      }
    }

    case 'function': {
      const fn = builtInFunctions[node.name.toUpperCase()];
      if (!fn) {
        return '#NAME?';
      }

      // Evaluate args
      const evaluatedArgs = node.args.map((arg) => {
        return evaluateAST(arg, context, visitedKeys);
      });

      try {
        return fn(evaluatedArgs, context);
      } catch (err: any) {
        return '#ERROR!';
      }
    }

    default:
      return '#VALUE!';
  }
}
