import { SheetData, CellData } from '../../types/sheet';
import { cellKey, parseKey } from './utils';
import { ASTNode, parseFormula } from './parser';
import { evaluateAST } from './evaluator';
import { FormulaContext } from './functions';

export class DependencyGraph {
  // node -> Set of nodes that THIS node depends on (incoming edges)
  private dependencies: Map<string, Set<string>> = new Map();
  // node -> Set of nodes that DEPEND ON this node (outgoing edges)
  private dependents: Map<string, Set<string>> = new Map();
  // Cached ASTs for formula cells
  private astCache: Map<string, ASTNode> = new Map();

  clear() {
    this.dependencies.clear();
    this.dependents.clear();
    this.astCache.clear();
  }

  // Extract all referenced cell keys from an AST
  private extractReferences(node: ASTNode, currentSheet: string): string[] {
    const refs: string[] = [];

    function traverse(n: ASTNode) {
      if (!n) return;
      if (n.type === 'cell') {
        const sheet = n.sheetName || currentSheet;
        refs.push(`${sheet}!${cellKey(n.row, n.col)}`);
      } else if (n.type === 'range') {
        const sheet = n.sheetName || currentSheet;
        for (let r = n.startRow; r <= n.endRow; r++) {
          for (let c = n.startCol; c <= n.endCol; c++) {
            refs.push(`${sheet}!${cellKey(r, c)}`);
          }
        }
      } else if (n.type === 'unary') {
        traverse(n.right);
      } else if (n.type === 'binary') {
        traverse(n.left);
        traverse(n.right);
      } else if (n.type === 'function') {
        for (const arg of n.args) {
          traverse(arg);
        }
      }
    }

    traverse(node);
    return refs;
  }

  // Register or update a cell formula
  updateCellFormula(sheetId: string, row: number, col: number, formula: string | undefined) {
    const key = `${sheetId}!${cellKey(row, col)}`;

    // Remove existing dependencies for this node
    const oldDeps = this.dependencies.get(key);
    if (oldDeps) {
      for (const dep of oldDeps) {
        this.dependents.get(dep)?.delete(key);
      }
      this.dependencies.delete(key);
    }
    this.astCache.delete(key);

    if (!formula || !formula.startsWith('=')) {
      return;
    }

    try {
      const ast = parseFormula(formula);
      this.astCache.set(key, ast);

      const refs = this.extractReferences(ast, sheetId);
      const depSet = new Set<string>(refs);
      this.dependencies.set(key, depSet);

      for (const ref of depSet) {
        if (!this.dependents.has(ref)) {
          this.dependents.set(ref, new Set());
        }
        this.dependents.get(ref)!.add(key);
      }
    } catch {
      // Syntax error in formula
    }
  }

  // Check if adding an edge from source to target creates a cycle
  private hasCycle(startNode: string): boolean {
    const visited = new Set<string>();
    const recursionStack = new Set<string>();

    const dfs = (node: string): boolean => {
      visited.add(node);
      recursionStack.add(node);

      const deps = this.dependencies.get(node);
      if (deps) {
        for (const dep of deps) {
          if (!visited.has(dep)) {
            if (dfs(dep)) return true;
          } else if (recursionStack.has(dep)) {
            return true;
          }
        }
      }

      recursionStack.delete(node);
      return false;
    };

    return dfs(startNode);
  }

  // Get recalculation order (topological sort of all dependents of changed cells)
  getRecalcOrder(changedKeys: string[]): string[] {
    const affected = new Set<string>();
    const queue = [...changedKeys];

    // BFS to find all downstream dependent cells
    while (queue.length > 0) {
      const current = queue.shift()!;
      const downstream = this.dependents.get(current);
      if (downstream) {
        for (const dep of downstream) {
          if (!affected.has(dep)) {
            affected.add(dep);
            queue.push(dep);
          }
        }
      }
    }

    // Topological sort of affected nodes
    const inDegree = new Map<string, number>();
    for (const node of affected) {
      inDegree.set(node, 0);
    }

    for (const node of affected) {
      const deps = this.dependencies.get(node);
      if (deps) {
        for (const dep of deps) {
          if (affected.has(dep)) {
            inDegree.set(node, (inDegree.get(node) || 0) + 1);
          }
        }
      }
    }

    const topoOrder: string[] = [];
    const zeroInDegree: string[] = [];

    for (const [node, degree] of inDegree.entries()) {
      if (degree === 0) {
        zeroInDegree.push(node);
      }
    }

    while (zeroInDegree.length > 0) {
      const current = zeroInDegree.shift()!;
      topoOrder.push(current);

      const downstream = this.dependents.get(current);
      if (downstream) {
        for (const next of downstream) {
          if (affected.has(next)) {
            const newDeg = (inDegree.get(next) || 1) - 1;
            inDegree.set(next, newDeg);
            if (newDeg === 0) {
              zeroInDegree.push(next);
            }
          }
        }
      }
    }

    // If topological sort missed nodes, there is a circular reference among them
    if (topoOrder.length < affected.size) {
      for (const node of affected) {
        if (!topoOrder.includes(node)) {
          topoOrder.push(node);
        }
      }
    }

    return topoOrder;
  }

  // Recalculate sheets in reaction to changes
  recalculate(
    sheets: Record<string, SheetData>,
    changedKeys: string[]
  ) {
    // If no specific keys provided, rebuild full graph and evaluate all
    if (changedKeys.length === 0) {
      this.clear();
      for (const [sheetId, sheet] of Object.entries(sheets)) {
        for (const [ckey, cell] of Object.entries(sheet.cells)) {
          const { row, col } = parseKey(ckey);
          if (cell.formula) {
            this.updateCellFormula(sheetId, row, col, cell.formula);
          }
        }
      }
      // Recompute all cells with formulas
      for (const [sheetId, sheet] of Object.entries(sheets)) {
        for (const [ckey, cell] of Object.entries(sheet.cells)) {
          if (cell.formula) {
            changedKeys.push(`${sheetId}!${ckey}`);
          }
        }
      }
    }

    const recalcOrder = this.getRecalcOrder(changedKeys);

    const createContext = (currentSheetId: string): FormulaContext => ({
      currentSheet: currentSheetId,
      resolveCell: (row, col, sheetName) => {
        const targetSheetId = sheetName || currentSheetId;
        const targetSheet = sheets[targetSheetId] || Object.values(sheets).find((s) => s.name === targetSheetId);
        if (!targetSheet) return 0;
        const c = targetSheet.cells[cellKey(row, col)];
        if (!c) return 0;
        if (c.error) return c.error;
        if (c.computed !== undefined && c.computed !== null) return c.computed;
        return c.raw ?? 0;
      },
      resolveRange: (startRow, startCol, endRow, endCol, sheetName) => {
        const targetSheetId = sheetName || currentSheetId;
        const targetSheet = sheets[targetSheetId] || Object.values(sheets).find((s) => s.name === targetSheetId);
        const matrix: any[][] = [];
        for (let r = startRow; r <= endRow; r++) {
          const rowVals: any[] = [];
          for (let c = startCol; c <= endCol; c++) {
            if (!targetSheet) {
              rowVals.push(0);
            } else {
              const cell = targetSheet.cells[cellKey(r, c)];
              if (!cell) {
                rowVals.push(0);
              } else if (cell.error) {
                rowVals.push(cell.error);
              } else if (cell.computed !== undefined && cell.computed !== null) {
                rowVals.push(cell.computed);
              } else {
                rowVals.push(cell.raw ?? 0);
              }
            }
          }
          matrix.push(rowVals);
        }
        return matrix;
      },
    });

    for (const key of recalcOrder) {
      const [sheetId, ckey] = key.split('!');
      const targetSheet = sheets[sheetId];
      if (!targetSheet) continue;

      const cell: CellData = targetSheet.cells[ckey];
      if (!cell || !cell.formula) continue;

      if (this.hasCycle(key)) {
        cell.error = '#CIRCULAR!';
        cell.computed = '#CIRCULAR!';
        continue;
      }

      let ast = this.astCache.get(key);
      if (!ast) {
        try {
          ast = parseFormula(cell.formula);
          this.astCache.set(key, ast);
        } catch {
          cell.error = '#ERROR!';
          cell.computed = '#ERROR!';
          continue;
        }
      }

      try {
        const ctx = createContext(sheetId);
        const res = evaluateAST(ast, ctx);
        if (typeof res === 'string' && res.startsWith('#')) {
          cell.error = res;
          cell.computed = res;
        } else {
          cell.error = null;
          cell.computed = res;
        }
      } catch (e: any) {
        cell.error = '#ERROR!';
        cell.computed = '#ERROR!';
      }
    }
  }
}
