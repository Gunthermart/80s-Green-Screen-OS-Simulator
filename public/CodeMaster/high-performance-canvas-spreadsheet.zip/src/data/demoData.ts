import { SheetData, CellData, ChartConfig, ConditionalRule } from '../types/sheet';

export function createInitialSheets(): Record<string, SheetData> {
  // SHEET 1: Dashboard Commercial
  const sheet1Cells: Record<string, CellData> = {};

  // Title Banner
  sheet1Cells['0_0'] = {
    raw: 'TABLEAU DE BORD COMMERCIAL & FINANCIER 2024',
    style: { bold: true, fontSize: 15, textColor: '#1e3a8a' },
  };

  // Table Headers (Row 2)
  const headers1 = [
    'Région',
    'Responsable',
    'T1 (k€)',
    'T2 (k€)',
    'T3 (k€)',
    'T4 (k€)',
    'Total 2024',
    'Objectif',
    '% Réalisé',
    'Marge %',
    'Statut',
  ];

  headers1.forEach((h, col) => {
    sheet1Cells[`2_${col}`] = {
      raw: h,
      style: {
        bold: true,
        bgColor: '#1e293b',
        textColor: '#ffffff',
        align: col >= 2 && col <= 9 ? 'right' : 'left',
        fontSize: 12,
      },
    };
  });

  // Data rows (Rows 3 to 7)
  const rows1 = [
    ['Île-de-France', 'Alexandre D.', 145, 168, 190, 210, 680, 0.18],
    ['Auvergne-Rhône-Alpes', 'Sophie M.', 120, 135, 142, 160, 580, 0.22],
    ['Nouvelle-Aquitaine', 'Thomas B.', 95, 110, 115, 130, 460, 0.15],
    ['Occitanie', 'Camille L.', 85, 92, 105, 118, 410, 0.19],
    ['PACA', 'Julien R.', 110, 125, 130, 145, 520, 0.16],
  ];

  rows1.forEach((row, idx) => {
    const r = 3 + idx; // row index 3..7
    sheet1Cells[`${r}_0`] = { raw: row[0], style: { bold: true } };
    sheet1Cells[`${r}_1`] = { raw: row[1] };
    sheet1Cells[`${r}_2`] = { raw: row[2], style: { format: 'currency_eur', precision: 0 } };
    sheet1Cells[`${r}_3`] = { raw: row[3], style: { format: 'currency_eur', precision: 0 } };
    sheet1Cells[`${r}_4`] = { raw: row[4], style: { format: 'currency_eur', precision: 0 } };
    sheet1Cells[`${r}_5`] = { raw: row[5], style: { format: 'currency_eur', precision: 0 } };

    // Total 2024 = SUM(C{r+1}:F{r+1})
    sheet1Cells[`${r}_6`] = {
      raw: '=SUM(C' + (r + 1) + ':F' + (r + 1) + ')',
      formula: '=SUM(C' + (r + 1) + ':F' + (r + 1) + ')',
      style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f8fafc' },
    };

    // Objectif
    sheet1Cells[`${r}_7`] = {
      raw: row[6],
      style: { format: 'currency_eur', precision: 0 },
    };

    // % Réalisé = G{r+1} / H{r+1}
    sheet1Cells[`${r}_8`] = {
      raw: '=G' + (r + 1) + '/H' + (r + 1),
      formula: '=G' + (r + 1) + '/H' + (r + 1),
      style: { bold: true, format: 'percent', precision: 1 },
    };

    // Marge %
    sheet1Cells[`${r}_9`] = {
      raw: row[7],
      style: { format: 'percent', precision: 1 },
    };

    // Statut = IF(I{r+1}>=1, "Objectif Atteint", "En cours")
    sheet1Cells[`${r}_10`] = {
      raw: '=IF(I' + (r + 1) + '>=1,"Objectif Atteint","En cours")',
      formula: '=IF(I' + (r + 1) + '>=1,"Objectif Atteint","En cours")',
      style: { align: 'center' },
    };
  });

  // Total Row (Row 8)
  const totalRow = 8;
  sheet1Cells[`${totalRow}_0`] = {
    raw: 'TOTAL GÉNÉRAL',
    style: { bold: true, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_1`] = { raw: '', style: { bgColor: '#f1f5f9' } };
  sheet1Cells[`${totalRow}_2`] = {
    raw: '=SUM(C4:C8)',
    formula: '=SUM(C4:C8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_3`] = {
    raw: '=SUM(D4:D8)',
    formula: '=SUM(D4:D8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_4`] = {
    raw: '=SUM(E4:E8)',
    formula: '=SUM(E4:E8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_5`] = {
    raw: '=SUM(F4:F8)',
    formula: '=SUM(F4:F8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_6`] = {
    raw: '=SUM(G4:G8)',
    formula: '=SUM(G4:G8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#e0e7ff', textColor: '#1e3a8a' },
  };
  sheet1Cells[`${totalRow}_7`] = {
    raw: '=SUM(H4:H8)',
    formula: '=SUM(H4:H8)',
    style: { bold: true, format: 'currency_eur', precision: 0, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_8`] = {
    raw: '=G9/H9',
    formula: '=G9/H9',
    style: { bold: true, format: 'percent', precision: 1, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_9`] = {
    raw: '=AVERAGE(J4:J8)',
    formula: '=AVERAGE(J4:J8)',
    style: { bold: true, format: 'percent', precision: 1, bgColor: '#f1f5f9' },
  };
  sheet1Cells[`${totalRow}_10`] = {
    raw: 'SYNTHÈSE',
    style: { bold: true, align: 'center', bgColor: '#f1f5f9' },
  };

  // KPI summary section (Row 10 to 13)
  sheet1Cells['10_0'] = { raw: 'Moyenne Trimestrielle', style: { bold: true, textColor: '#475569' } };
  sheet1Cells['10_1'] = { raw: '=AVERAGE(G4:G8)/4', formula: '=AVERAGE(G4:G8)/4', style: { format: 'currency_eur', precision: 0, bold: true } };

  sheet1Cells['11_0'] = { raw: 'Meilleure Région', style: { bold: true, textColor: '#475569' } };
  sheet1Cells['11_1'] = { raw: '=MAX(G4:G8)', formula: '=MAX(G4:G8)', style: { format: 'currency_eur', precision: 0, bold: true } };

  sheet1Cells['12_0'] = { raw: 'Écart-Type Ventes', style: { bold: true, textColor: '#475569' } };
  sheet1Cells['12_1'] = { raw: '=STDEV(G4:G8)', formula: '=STDEV(G4:G8)', style: { format: 'number', precision: 1, bold: true } };

  // Conditional formatting rules for Sheet 1
  const sheet1Rules: ConditionalRule[] = [
    {
      id: 'rule-scale-achieve',
      type: 'colorScale',
      targetRange: 'I4:I8',
      colorScale: {
        minColor: '#fecaca', // light red
        midColor: '#fef08a', // light yellow
        maxColor: '#bbf7d0', // light green
      },
    },
    {
      id: 'rule-databar-margin',
      type: 'dataBar',
      targetRange: 'J4:J8',
      dataBar: {
        positiveColor: '#38bdf8', // sky blue
        negativeColor: '#f87171',
        showAxis: true,
      },
    },
    {
      id: 'rule-iconset-status',
      type: 'iconSet',
      targetRange: 'I4:I8',
      iconSet: {
        iconType: 'traffic',
      },
    },
    {
      id: 'rule-status-ok',
      type: 'equal',
      targetRange: 'K4:K8',
      value1: 'Objectif Atteint',
      style: {
        bgColor: '#dcfce7',
        textColor: '#15803d',
        bold: true,
      },
    },
  ];

  // Pre-configured Vector Charts for Sheet 1
  const sheet1Charts: ChartConfig[] = [
    {
      id: 'chart-col-sales',
      type: 'column',
      title: 'Ventes par Région (T1 - T4)',
      subtitle: 'Montants en k€ par trimestre',
      dataRange: 'C4:F8',
      labelRange: 'A4:A8',
      seriesNamesRange: 'C3:F3',
      x: 720,
      y: 35,
      width: 440,
      height: 250,
      colors: ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'],
      showLegend: true,
    },
    {
      id: 'chart-pie-share',
      type: 'doughnut',
      title: 'Part de Marché par Région',
      subtitle: 'Répartition du Chiffre d’Affaires Total',
      dataRange: 'G4:G8',
      labelRange: 'A4:A8',
      x: 1180,
      y: 35,
      width: 320,
      height: 250,
      colors: ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'],
      doughnutHoleSize: 0.55,
      showLegend: true,
    },
    {
      id: 'chart-area-trend',
      type: 'area',
      title: 'Évolution Globale Trimestrielle',
      subtitle: 'Tendance des ventes consolidées',
      dataRange: 'C9:F9',
      labelRange: 'C3:F3',
      seriesDirection: 'rows',
      x: 720,
      y: 305,
      width: 440,
      height: 230,
      colors: ['#6366f1'],
      smooth: true,
      showLegend: false,
    },
  ];

  // Column widths
  const sheet1ColWidths: Record<number, number> = {
    0: 170, // Région
    1: 130, // Responsable
    2: 90,  // T1
    3: 90,  // T2
    4: 90,  // T3
    5: 90,  // T4
    6: 105, // Total 2024
    7: 100, // Objectif
    8: 95,  // % Réalisé
    9: 95,  // Marge %
    10: 140, // Statut
  };

  // SHEET 2: Budget & Prévisions 2025
  const sheet2Cells: Record<string, CellData> = {};
  sheet2Cells['0_0'] = { raw: 'BUDGET DÉPARTEMENTAL & PRÉVISIONS 2025', style: { bold: true, fontSize: 14, textColor: '#047857' } };

  const headers2 = ['Département', 'OPEX (k€)', 'CAPEX (k€)', 'Budget Alloué', 'Dépensé YTD', 'Solde Restant', '% Consommé'];
  headers2.forEach((h, col) => {
    sheet2Cells[`2_${col}`] = {
      raw: h,
      style: { bold: true, bgColor: '#065f46', textColor: '#ffffff', align: col > 0 ? 'right' : 'left' },
    };
  });

  const depts = [
    ['Recherche & Dév.', 450, 280, 520],
    ['Marketing & Com', 320, 90, 310],
    ['Infrastructure Cloud', 210, 150, 290],
    ['Opérations & RH', 180, 40, 165],
    ['Force de Vente', 290, 75, 275],
  ];

  depts.forEach((row, idx) => {
    const r = 3 + idx;
    sheet2Cells[`${r}_0`] = { raw: row[0], style: { bold: true } };
    sheet2Cells[`${r}_1`] = { raw: row[1], style: { format: 'currency_eur', precision: 0 } };
    sheet2Cells[`${r}_2`] = { raw: row[2], style: { format: 'currency_eur', precision: 0 } };
    sheet2Cells[`${r}_3`] = { raw: '=B' + (r + 1) + '+C' + (r + 1), formula: '=B' + (r + 1) + '+C' + (r + 1), style: { bold: true, format: 'currency_eur', precision: 0 } };
    sheet2Cells[`${r}_4`] = { raw: row[3], style: { format: 'currency_eur', precision: 0 } };
    sheet2Cells[`${r}_5`] = { raw: '=D' + (r + 1) + '-E' + (r + 1), formula: '=D' + (r + 1) + '-E' + (r + 1), style: { bold: true, format: 'currency_eur', precision: 0 } };
    sheet2Cells[`${r}_6`] = { raw: '=E' + (r + 1) + '/D' + (r + 1), formula: '=E' + (r + 1) + '/D' + (r + 1), style: { bold: true, format: 'percent', precision: 1 } };
  });

  const sheet2Charts: ChartConfig[] = [
    {
      id: 'chart-budget-stacked',
      type: 'column_stacked',
      title: 'Répartition OPEX / CAPEX par Département',
      dataRange: 'B4:C8',
      labelRange: 'A4:A8',
      seriesNamesRange: 'B3:C3',
      x: 740,
      y: 40,
      width: 480,
      height: 280,
      colors: ['#059669', '#10b981'],
      showLegend: true,
    },
  ];

  // SHEET 3: Fonctions Avancées (XLOOKUP, INDEX, MATCH)
  const sheet3Cells: Record<string, CellData> = {};
  sheet3Cells['0_0'] = { raw: 'DÉMONSTRATION DES FONCTIONS AVANCÉES (VLOOKUP, XLOOKUP, INDEX, MATCH)', style: { bold: true, fontSize: 13 } };

  // Reference Table
  sheet3Cells['2_0'] = { raw: 'Code Produit', style: { bold: true, bgColor: '#475569', textColor: '#ffffff' } };
  sheet3Cells['2_1'] = { raw: 'Désignation', style: { bold: true, bgColor: '#475569', textColor: '#ffffff' } };
  sheet3Cells['2_2'] = { raw: 'Prix Unitaire (€)', style: { bold: true, bgColor: '#475569', textColor: '#ffffff' } };
  sheet3Cells['2_3'] = { raw: 'Stock', style: { bold: true, bgColor: '#475569', textColor: '#ffffff' } };

  const products = [
    ['PRD-001', 'Serveur Haute Densité X9', 4200, 14],
    ['PRD-002', 'Switch 100Gbps Fibre', 1850, 28],
    ['PRD-003', 'Routeur Entreprise Core', 2900, 9],
    ['PRD-004', 'Baie de Stockage NVMe 50TB', 8400, 5],
  ];

  products.forEach((p, idx) => {
    const r = 3 + idx;
    sheet3Cells[`${r}_0`] = { raw: p[0], style: { bold: true } };
    sheet3Cells[`${r}_1`] = { raw: p[1] };
    sheet3Cells[`${r}_2`] = { raw: p[2], style: { format: 'currency_eur', precision: 0 } };
    sheet3Cells[`${r}_3`] = { raw: p[3], style: { format: 'number', precision: 0 } };
  });

  // Lookup demo area
  sheet3Cells['9_0'] = { raw: 'Recherche VLOOKUP ("PRD-002"):', style: { bold: true } };
  sheet3Cells['9_1'] = { raw: '=VLOOKUP("PRD-002", A4:D7, 2, FALSE)', formula: '=VLOOKUP("PRD-002", A4:D7, 2, FALSE)', style: { bold: true, textColor: '#2563eb' } };

  sheet3Cells['10_0'] = { raw: 'Recherche XLOOKUP ("PRD-004", Prix):', style: { bold: true } };
  sheet3Cells['10_1'] = { raw: '=XLOOKUP("PRD-004", A4:A7, C4:C7)', formula: '=XLOOKUP("PRD-004", A4:A7, C4:C7)', style: { bold: true, format: 'currency_eur', textColor: '#059669' } };

  sheet3Cells['11_0'] = { raw: 'INDEX & MATCH (Ligne 1, Col 2):', style: { bold: true } };
  sheet3Cells['11_1'] = { raw: '=INDEX(A4:D7, 1, 2)', formula: '=INDEX(A4:D7, 1, 2)', style: { bold: true } };

  return {
    'sheet-1': {
      id: 'sheet-1',
      name: 'Performance Commerciale',
      cells: sheet1Cells,
      columnWidths: sheet1ColWidths,
      rowHeights: { 0: 32, 2: 28, 8: 26 },
      charts: sheet1Charts,
      conditionalRules: sheet1Rules,
      mergedCells: [],
      frozenRows: 1,
      frozenCols: 0,
      defaultColWidth: 96,
      defaultRowHeight: 24,
      maxRows: 100,
      maxCols: 26,
      filters: {},
    },
    'sheet-2': {
      id: 'sheet-2',
      name: 'Budget & Prévisions 2025',
      cells: sheet2Cells,
      columnWidths: { 0: 170, 1: 110, 2: 110, 3: 120, 4: 120, 5: 120, 6: 110 },
      rowHeights: { 0: 30, 2: 28 },
      charts: sheet2Charts,
      conditionalRules: [
        {
          id: 'rule-budget-pct',
          type: 'colorScale',
          targetRange: 'G4:G8',
          colorScale: {
            minColor: '#dcfce7',
            maxColor: '#fee2e2',
          },
        },
      ],
      mergedCells: [],
      frozenRows: 1,
      frozenCols: 0,
      defaultColWidth: 100,
      defaultRowHeight: 24,
      maxRows: 100,
      maxCols: 26,
      filters: {},
    },
    'sheet-3': {
      id: 'sheet-3',
      name: 'Recherche & Fonctions',
      cells: sheet3Cells,
      columnWidths: { 0: 220, 1: 220, 2: 130, 3: 90 },
      rowHeights: {},
      charts: [],
      conditionalRules: [],
      mergedCells: [],
      frozenRows: 0,
      frozenCols: 0,
      defaultColWidth: 110,
      defaultRowHeight: 24,
      maxRows: 100,
      maxCols: 26,
      filters: {},
    },
  };
}
