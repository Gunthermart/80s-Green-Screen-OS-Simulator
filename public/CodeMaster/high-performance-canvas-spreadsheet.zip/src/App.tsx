import React, { useState, useEffect, useRef, useCallback } from 'react';
import { SheetData, CellCoord, CellRange, ChartConfig, CellStyle, ColumnFilter, ConditionalRule } from './types/sheet';
import { createInitialSheets } from './data/demoData';
import { DependencyGraph } from './engine/formula/dag';
import { cellKey, formatRange, normalizeRange } from './engine/formula/utils';
import { TopNav } from './components/TopNav';
import { Toolbar } from './components/Toolbar';
import { FormulaBar } from './components/FormulaBar';
import { CanvasSpreadsheet } from './components/CanvasSpreadsheet';
import { SheetTabs } from './components/SheetTabs';
import { ChartEditorModal } from './components/ChartEditorModal';
import { ConditionalFormatModal } from './components/ConditionalFormatModal';
import { FormulaAssistantModal } from './components/FormulaAssistantModal';
import confetti from 'canvas-confetti';

export function App() {
  // Master Workbook State
  const [fileName, setFileName] = useState<string>('Performance Commerciale & Prévisions 2024');
  const [sheets, setSheets] = useState<Record<string, SheetData>>(() => createInitialSheets());
  const [sheetOrder, setSheetOrder] = useState<string[]>(['sheet-1', 'sheet-2', 'sheet-3']);
  const [activeSheetId, setActiveSheetId] = useState<string>('sheet-1');

  // Navigation & Selection
  const [activeCell, setActiveCell] = useState<CellCoord>({ row: 3, col: 2 });
  const [selection, setSelection] = useState<CellRange | null>({
    startRow: 3,
    startCol: 2,
    endRow: 7,
    endCol: 5,
  });
  const [selectedChartId, setSelectedChartId] = useState<string | null>(null);

  // Undo / Redo History
  const undoStackRef = useRef<string[]>([]);
  const redoStackRef = useRef<string[]>([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Formula DAG Engine
  const dagRef = useRef<DependencyGraph>(new DependencyGraph());

  // Modals state
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);
  const [chartToEdit, setChartToEdit] = useState<ChartConfig | null>(null);
  const [isCondModalOpen, setIsCondModalOpen] = useState(false);
  const [isFormulaHelperOpen, setIsFormulaHelperOpen] = useState(false);

  // Formula Bar value
  const activeSheet = sheets[activeSheetId] || Object.values(sheets)[0];
  const activeCellData = activeSheet?.cells[cellKey(activeCell.row, activeCell.col)];
  const [formulaBarText, setFormulaBarText] = useState<string>('');

  // Sync Formula bar with active cell
  useEffect(() => {
    if (activeCellData) {
      setFormulaBarText(activeCellData.formula || String(activeCellData.raw ?? ''));
    } else {
      setFormulaBarText('');
    }
  }, [activeCell, activeCellData, activeSheetId]);

  // Push snapshot to undo stack
  const saveSnapshot = useCallback(() => {
    undoStackRef.current.push(JSON.stringify(sheets));
    if (undoStackRef.current.length > 30) undoStackRef.current.shift();
    redoStackRef.current = [];
    setCanUndo(true);
    setCanRedo(false);
  }, [sheets]);

  // Initial Calculation of all formulas via DAG
  useEffect(() => {
    dagRef.current.recalculate(sheets, []);
    setSheets({ ...sheets });
  }, []);

  // Update formula DAG when cell changes
  const handleCellChange = useCallback(
    (row: number, col: number, textValue: string) => {
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      const key = cellKey(row, col);
      const existing = currentSheet.cells[key] || { raw: '' };

      let formula: string | undefined;
      let raw: string | number = textValue;

      if (textValue.startsWith('=')) {
        formula = textValue;
        raw = textValue;
      } else {
        const num = Number(textValue);
        if (!isNaN(num) && textValue.trim() !== '') {
          raw = num;
        }
      }

      currentSheet.cells[key] = {
        ...existing,
        raw,
        formula,
      };

      dagRef.current.updateCellFormula(activeSheetId, row, col, formula);
      dagRef.current.recalculate(updatedSheets, [`${activeSheetId}!${key}`]);

      setSheets(updatedSheets);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  // Bulk cells update (from Paste, Autofill, Clear)
  const handleBulkCellsChange = useCallback(
    (modifiedCells: Record<string, any>) => {
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      const changedKeys: string[] = [];

      for (const [key, cell] of Object.entries(modifiedCells)) {
        currentSheet.cells[key] = cell;
        const [r, c] = key.split('_').map(Number);
        dagRef.current.updateCellFormula(activeSheetId, r, c, cell.formula);
        changedKeys.push(`${activeSheetId}!${key}`);
      }

      dagRef.current.recalculate(updatedSheets, changedKeys);
      setSheets(updatedSheets);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  // Apply style to selected cells
  const handleApplyStyle = useCallback(
    (stylePatch: Partial<CellStyle>) => {
      if (!selection) return;
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      const norm = normalizeRange(selection);
      for (let r = norm.startRow; r <= norm.endRow; r++) {
        for (let c = norm.startCol; c <= norm.endCol; c++) {
          const key = cellKey(r, c);
          const cell = currentSheet.cells[key] || { raw: '' };
          currentSheet.cells[key] = {
            ...cell,
            style: {
              ...cell.style,
              ...stylePatch,
            },
          };
        }
      }

      setSheets(updatedSheets);
    },
    [sheets, activeSheetId, selection, saveSnapshot]
  );

  // Chart Management
  const handleSaveChart = useCallback(
    (chart: ChartConfig) => {
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      const idx = currentSheet.charts.findIndex((c) => c.id === chart.id);
      if (idx !== -1) {
        currentSheet.charts[idx] = chart;
      } else {
        currentSheet.charts.push(chart);
        try {
          confetti({ particleCount: 30, spread: 60, origin: { y: 0.6 } });
        } catch {
          // ignore
        }
      }

      setSheets(updatedSheets);
      setSelectedChartId(chart.id);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  const handleDeleteChart = useCallback(
    (chartId: string) => {
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      currentSheet.charts = currentSheet.charts.filter((c) => c.id !== chartId);
      setSheets(updatedSheets);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  const handleUpdateChart = useCallback(
    (chart: ChartConfig) => {
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      const idx = currentSheet.charts.findIndex((c) => c.id === chart.id);
      if (idx !== -1) {
        currentSheet.charts[idx] = chart;
        setSheets(updatedSheets);
      }
    },
    [sheets, activeSheetId]
  );

  // Conditional formatting management
  const handleSaveConditionalRules = useCallback(
    (rules: ConditionalRule[]) => {
      saveSnapshot();
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      currentSheet.conditionalRules = rules;
      setSheets(updatedSheets);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  // Column filter management
  const handleApplyFilter = useCallback(
    (colIndex: number, filter: ColumnFilter | null) => {
      const updatedSheets = { ...sheets };
      const currentSheet = updatedSheets[activeSheetId];
      if (!currentSheet) return;

      if (filter === null) {
        delete currentSheet.filters[colIndex];
      } else {
        currentSheet.filters[colIndex] = filter;
      }
      setSheets({ ...updatedSheets });
    },
    [sheets, activeSheetId]
  );

  const handleToggleFilterRow = useCallback(() => {
    const updatedSheets = { ...sheets };
    const currentSheet = updatedSheets[activeSheetId];
    if (!currentSheet) return;

    if (Object.keys(currentSheet.filters).length > 0) {
      currentSheet.filters = {};
    } else {
      // Enable filter on all header columns
      for (let c = 0; c < 12; c++) {
        currentSheet.filters[c] = { colIndex: c };
      }
    }
    setSheets({ ...updatedSheets });
  }, [sheets, activeSheetId]);

  // Undo / Redo
  const handleUndo = useCallback(() => {
    if (undoStackRef.current.length === 0) return;
    const prev = undoStackRef.current.pop()!;
    redoStackRef.current.push(JSON.stringify(sheets));
    const parsed = JSON.parse(prev);
    setSheets(parsed);
    dagRef.current.recalculate(parsed, []);
    setCanUndo(undoStackRef.current.length > 0);
    setCanRedo(true);
  }, [sheets]);

  const handleRedo = useCallback(() => {
    if (redoStackRef.current.length === 0) return;
    const next = redoStackRef.current.pop()!;
    undoStackRef.current.push(JSON.stringify(sheets));
    const parsed = JSON.parse(next);
    setSheets(parsed);
    dagRef.current.recalculate(parsed, []);
    setCanUndo(true);
    setCanRedo(redoStackRef.current.length > 0);
  }, [sheets]);

  // Select All
  const handleSelectAll = useCallback(() => {
    setSelection({
      startRow: 0,
      startCol: 0,
      endRow: activeSheet.maxRows - 1,
      endCol: activeSheet.maxCols - 1,
    });
  }, [activeSheet]);

  // Sheet operations
  const handleAddSheet = useCallback(() => {
    saveSnapshot();
    const newId = `sheet-${Date.now()}`;
    const newName = `Feuille ${sheetOrder.length + 1}`;
    const newSheet: SheetData = {
      id: newId,
      name: newName,
      cells: {},
      columnWidths: {},
      rowHeights: {},
      charts: [],
      conditionalRules: [],
      mergedCells: [],
      frozenRows: 0,
      frozenCols: 0,
      defaultColWidth: 96,
      defaultRowHeight: 24,
      maxRows: 100,
      maxCols: 26,
      filters: {},
    };

    setSheets((prev) => ({ ...prev, [newId]: newSheet }));
    setSheetOrder((prev) => [...prev, newId]);
    setActiveSheetId(newId);
  }, [sheetOrder, saveSnapshot]);

  const handleRenameSheet = useCallback(
    (id: string, newName: string) => {
      saveSnapshot();
      setSheets((prev) => ({
        ...prev,
        [id]: { ...prev[id], name: newName },
      }));
    },
    [saveSnapshot]
  );

  const handleDeleteSheet = useCallback(
    (id: string) => {
      if (sheetOrder.length <= 1) return;
      saveSnapshot();
      const newOrder = sheetOrder.filter((sId) => sId !== id);
      const nextActiveId = activeSheetId === id ? newOrder[0] : activeSheetId;

      const newSheets = { ...sheets };
      delete newSheets[id];

      setSheets(newSheets);
      setSheetOrder(newOrder);
      setActiveSheetId(nextActiveId);
    },
    [sheetOrder, activeSheetId, sheets, saveSnapshot]
  );

  // EXPORT / IMPORT
  const handleExportCSV = useCallback(() => {
    let csv = '';
    for (let r = 0; r < activeSheet.maxRows; r++) {
      const rowVals: string[] = [];
      let hasData = false;
      for (let c = 0; c < activeSheet.maxCols; c++) {
        const cell = activeSheet.cells[cellKey(r, c)];
        const val = cell?.computed !== undefined ? cell.computed : (cell?.raw ?? '');
        const strVal = String(val);
        if (strVal) hasData = true;
        const escaped = strVal.includes(',') || strVal.includes('\n') || strVal.includes('"')
          ? `"${strVal.replace(/"/g, '""')}"`
          : strVal;
        rowVals.push(escaped);
      }
      if (hasData || r < 20) {
        csv += rowVals.join(';') + '\n';
      }
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }, [activeSheet, fileName]);

  const handleExportJSON = useCallback(() => {
    const data = {
      fileName,
      version: '1.0',
      sheetOrder,
      sheets,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.json`;
    link.click();
    URL.revokeObjectURL(url);
  }, [fileName, sheetOrder, sheets]);

  const handleExportCanvasImage = useCallback(() => {
    const canvas = document.querySelector('canvas') as HTMLCanvasElement;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.png`;
    link.click();
  }, [fileName]);

  const handleImportCSV = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (!text) return;

        saveSnapshot();
        const lines = text.split(/\r\n|\n|\r/);
        const newCells: Record<string, any> = {};

        lines.forEach((line, r) => {
          const cols = line.split(/[;,\t]/);
          cols.forEach((colStr, c) => {
            let str = colStr.trim();
            if (str.startsWith('"') && str.endsWith('"')) {
              str = str.substring(1, str.length - 1).replace(/""/g, '"');
            }
            if (str) {
              const num = Number(str);
              const raw = !isNaN(num) ? num : str;
              newCells[cellKey(r, c)] = {
                raw,
                formula: str.startsWith('=') ? str : undefined,
              };
            }
          });
        });

        const updatedSheets = { ...sheets };
        updatedSheets[activeSheetId].cells = newCells;
        dagRef.current.recalculate(updatedSheets, []);
        setSheets(updatedSheets);
      };
      reader.readAsText(file);
    },
    [sheets, activeSheetId, saveSnapshot]
  );

  const handleImportJSON = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed.sheets && parsed.sheetOrder) {
            saveSnapshot();
            setFileName(parsed.fileName || fileName);
            setSheetOrder(parsed.sheetOrder);
            setSheets(parsed.sheets);
            setActiveSheetId(parsed.sheetOrder[0]);
            dagRef.current.recalculate(parsed.sheets, []);
          }
        } catch {
          alert('Format JSON de projet invalide.');
        }
      };
      reader.readAsText(file);
    },
    [fileName, saveSnapshot]
  );

  const selectedRangeStr = selection ? formatRange(selection) : 'C4:F8';

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100 antialiased">
      {/* 1. TOP NAVIGATION BAR */}
      <TopNav
        fileName={fileName}
        onFileNameChange={setFileName}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        onOpenChartModal={() => {
          setChartToEdit(null);
          setIsChartModalOpen(true);
        }}
        onOpenCondModal={() => setIsCondModalOpen(true)}
        onOpenFormulaHelper={() => setIsFormulaHelperOpen(true)}
        onExportCSV={handleExportCSV}
        onExportJSON={handleExportJSON}
        onExportCanvasImage={handleExportCanvasImage}
        onImportCSV={handleImportCSV}
        onImportJSON={handleImportJSON}
        onSelectAll={handleSelectAll}
      />

      {/* 2. FORMATTING TOOLBAR */}
      <Toolbar
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        activeStyle={activeCellData?.style || {}}
        onApplyStyle={handleApplyStyle}
        onOpenChartModal={() => {
          setChartToEdit(null);
          setIsChartModalOpen(true);
        }}
        onOpenCondModal={() => setIsCondModalOpen(true)}
        onToggleFilter={handleToggleFilterRow}
        hasFiltersActive={Object.keys(activeSheet?.filters || {}).length > 0}
      />

      {/* 3. FORMULA BAR */}
      <FormulaBar
        activeCell={activeCell}
        value={formulaBarText}
        onChange={(val) => setFormulaBarText(val)}
        onCommit={() => handleCellChange(activeCell.row, activeCell.col, formulaBarText)}
        onCancel={() => setFormulaBarText(activeCellData?.formula || String(activeCellData?.raw ?? ''))}
        onOpenHelper={() => setIsFormulaHelperOpen(true)}
        isEditing={formulaBarText !== (activeCellData?.formula || String(activeCellData?.raw ?? ''))}
      />

      {/* 4. MAIN CANVAS SPREADSHEET GRID */}
      <main className="flex-1 relative w-full h-full overflow-hidden bg-white">
        <CanvasSpreadsheet
          sheet={activeSheet}
          activeCell={activeCell}
          selection={selection}
          selectedChartId={selectedChartId}
          onActiveCellChange={setActiveCell}
          onSelectionChange={setSelection}
          onSelectedChartChange={setSelectedChartId}
          onCellChange={handleCellChange}
          onBulkCellsChange={handleBulkCellsChange}
          onUpdateChart={handleUpdateChart}
          onDeleteChart={handleDeleteChart}
          onOpenChartEditor={(chart) => {
            setChartToEdit(chart);
            setIsChartModalOpen(true);
          }}
          onApplyFilter={handleApplyFilter}
          onUndo={handleUndo}
          onRedo={handleRedo}
          onSelectAll={handleSelectAll}
        />
      </main>

      {/* 5. BOTTOM SHEET TABS & STATUS BAR */}
      <SheetTabs
        sheets={sheets}
        sheetOrder={sheetOrder}
        activeSheetId={activeSheetId}
        onSelectSheet={setActiveSheetId}
        onAddSheet={handleAddSheet}
        onRenameSheet={handleRenameSheet}
        onDeleteSheet={handleDeleteSheet}
        selection={selection}
      />

      {/* MODAL 1: Chart Creator / Editor */}
      <ChartEditorModal
        isOpen={isChartModalOpen}
        onClose={() => setIsChartModalOpen(false)}
        onSaveChart={handleSaveChart}
        existingChart={chartToEdit}
        sheet={activeSheet}
        defaultRange={selectedRangeStr}
      />

      {/* MODAL 2: Conditional Formatting Manager */}
      <ConditionalFormatModal
        isOpen={isCondModalOpen}
        onClose={() => setIsCondModalOpen(false)}
        sheet={activeSheet}
        onSaveRules={handleSaveConditionalRules}
        defaultRange={selectedRangeStr}
      />

      {/* MODAL 3: Formula Function Assistant */}
      <FormulaAssistantModal
        isOpen={isFormulaHelperOpen}
        onClose={() => setIsFormulaHelperOpen(false)}
        onInsertFormula={(template) => {
          setFormulaBarText(template);
          handleCellChange(activeCell.row, activeCell.col, template);
        }}
      />
    </div>
  );
}

export default App;
