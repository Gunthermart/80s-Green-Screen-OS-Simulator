import React, { useRef } from 'react';
import { Check, X } from 'lucide-react';
import { CellCoord } from '../types/sheet';
import { colIndexToName } from '../engine/formula/utils';

interface FormulaBarProps {
  activeCell: CellCoord;
  value: string;
  onChange: (val: string) => void;
  onCommit: () => void;
  onCancel: () => void;
  onOpenHelper: () => void;
  isEditing: boolean;
}

export const FormulaBar: React.FC<FormulaBarProps> = ({
  activeCell,
  value,
  onChange,
  onCommit,
  onCancel,
  onOpenHelper,
  isEditing,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const cellRefStr = `${colIndexToName(activeCell.col)}${activeCell.row + 1}`;

  return (
    <div className="bg-slate-900 border-b border-slate-800 px-3 py-1 flex items-center gap-2 text-xs select-none flex-shrink-0">
      {/* Active Cell Reference badge */}
      <div className="w-16 px-2 py-1 bg-slate-800 border border-slate-700/80 rounded text-slate-200 font-mono font-semibold text-center flex-shrink-0">
        {cellRefStr}
      </div>

      {/* Action buttons (Commit / Cancel) when editing */}
      <div className="flex items-center gap-0.5">
        <button
          onClick={onCancel}
          disabled={!isEditing}
          className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 disabled:opacity-30 transition"
          title="Annuler la saisie (Échap)"
        >
          <X className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onCommit}
          disabled={!isEditing}
          className="p-1 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-800 disabled:opacity-30 transition"
          title="Valider la saisie (Entrée)"
        >
          <Check className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Function assistant button */}
      <button
        onClick={onOpenHelper}
        className="px-1.5 py-1 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded font-serif italic font-bold text-xs flex items-center gap-1 transition"
        title="Ouvrir l'assistant de fonctions (fx)"
      >
        <span className="text-emerald-400">fx</span>
      </button>

      {/* Formula Input Box */}
      <div className="flex-1 relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              onCommit();
            } else if (e.key === 'Escape') {
              onCancel();
            }
          }}
          placeholder="Saisissez une valeur ou une formule débutant par = (ex: =SUM(B2:B10))"
          className={`w-full bg-slate-950 border rounded px-2.5 py-1 text-xs text-slate-100 font-mono outline-none transition ${
            value.startsWith('=')
              ? 'border-blue-500/60 bg-blue-950/20 text-blue-200 focus:border-blue-400'
              : 'border-slate-800 focus:border-emerald-500/60'
          }`}
        />
      </div>
    </div>
  );
};
