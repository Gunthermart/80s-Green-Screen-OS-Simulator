import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  SheetData,
  CellCoord,
  CellRange,
  ChartConfig,
  DragHandleType,
  MarchingAntsSelection,
  ChartHoverInfo,
  ColumnFilter,
} from '../types/sheet';
import { VirtualGrid } from '../engine/virtualGrid';
import { ConditionalFormattingEngine } from '../engine/conditionalFormatting';
import { renderSpreadsheet } from '../engine/canvasRenderer';
import { hitTestCharts } from '../engine/charts/chartHitTest';
import { executeAutofill } from '../engine/autofill';
import { copySelectionToClipboard, parseClipboardData, applyPastedData } from '../engine/clipboard';
import { cellKey, normalizeRange } from '../engine/formula/utils';
import { FilterPopover } from './FilterPopover';

interface CanvasSpreadsheetProps {
  sheet: SheetData;
  activeCell: CellCoord;
  selection: CellRange | null;
  selectedChartId: string | null;
  onActiveCellChange: (cell: CellCoord) => void;
  onSelectionChange: (range: CellRange | null) => void;
  onSelectedChartChange: (chartId: string | null) => void;
  onCellChange: (row: number, col: number, value: string) => void;
  onBulkCellsChange: (modified: Record<string, any>) => void;
  onUpdateChart: (chart: ChartConfig) => void;
  onDeleteChart: (chartId: string) => void;
  onOpenChartEditor: (chart: ChartConfig) => void;
  onApplyFilter: (colIndex: number, filter: ColumnFilter | null) => void;
  onUndo: () => void;
  onRedo: () => void;
  onSelectAll: () => void;
}

export const CanvasSpreadsheet: React.FC<CanvasSpreadsheetProps> = ({
  sheet,
  activeCell,
  selection,
  selectedChartId,
  onActiveCellChange,
  onSelectionChange,
  onSelectedChartChange,
  onCellChange,
  onBulkCellsChange,
  onUpdateChart,
  onDeleteChart,
  onOpenChartEditor,
  onApplyFilter,
  onUndo,
  onRedo,
  onSelectAll,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const inPlaceInputRef = useRef<HTMLInputElement>(null);

  // Engines
  const gridRef = useRef<VirtualGrid>(new VirtualGrid(sheet));
  const condEngineRef = useRef<ConditionalFormattingEngine>(new ConditionalFormattingEngine());

  // Scroll state
  const [scrollX, setScrollX] = useState(0);
  const [scrollY, setScrollY] = useState(0);

  // In-place editing state
  const [isEditingInPlace, setIsEditingInPlace] = useState(false);
  const [editValue, setEditValue] = useState('');

  // Marching ants for clipboard
  const [marchingAnts, setMarchingAnts] = useState<MarchingAntsSelection | null>(null);
  const [marchingOffset, setMarchingOffset] = useState(0);

  // Filter Popover state
  const [activeFilterCol, setActiveFilterCol] = useState<{ col: number; x: number; y: number } | null>(null);

  // Drag states
  const [isSelecting, setIsSelecting] = useState(false);
  const [isAutofilling, setIsAutofilling] = useState(false);
  const [autofillRange, setAutofillRange] = useState<CellRange | null>(null);

  const [resizingCol, setResizingCol] = useState<{ col: number; startX: number; startW: number } | null>(null);
  const [resizingRow, setResizingRow] = useState<{ row: number; startY: number; startH: number } | null>(null);

  const [draggingChart, setDraggingChart] = useState<{
    chartId: string;
    handle: DragHandleType;
    startX: number;
    startY: number;
    chartStartX: number;
    chartStartY: number;
    chartStartW: number;
    chartStartH: number;
  } | null>(null);

  const [chartHoverInfo, setChartHoverInfo] = useState<ChartHoverInfo | null>(null);
  const [hoveredColHeader, setHoveredColHeader] = useState<number | null>(null);
  const [hoveredRowHeader, setHoveredRowHeader] = useState<number | null>(null);
  const [cursorStyle, setCursorStyle] = useState<string>('cell');

  // Update virtual grid when sheet changes
  useEffect(() => {
    gridRef.current.setSheet(sheet);
    condEngineRef.current.clearCache();
  }, [sheet]);

  // Animated marching ants timer loop
  useEffect(() => {
    if (!marchingAnts) return;
    const interval = setInterval(() => {
      setMarchingOffset((prev) => (prev + 1) % 12);
    }, 60);
    return () => clearInterval(interval);
  }, [marchingAnts]);

  // Main Canvas Render Loop
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;

    renderSpreadsheet({
      canvas,
      ctx,
      sheet,
      grid: gridRef.current,
      conditionalEngine: condEngineRef.current,
      scrollX,
      scrollY,
      selection,
      activeCell,
      isSelecting,
      autofillRange,
      marchingAnts,
      marchingAntsOffset: marchingOffset,
      selectedChartId,
      chartHoverInfo,
      hoveredColHeader,
      hoveredRowHeader,
      dpr,
    });
  }, [
    sheet,
    scrollX,
    scrollY,
    selection,
    activeCell,
    isSelecting,
    autofillRange,
    marchingAnts,
    marchingOffset,
    selectedChartId,
    chartHoverInfo,
    hoveredColHeader,
    hoveredRowHeader,
  ]);

  // Trigger redraw on state updates & container resize
  useEffect(() => {
    let animId: number;
    const loop = () => {
      render();
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [render]);

  // Resize canvas according to container
  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current || !canvasRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;

      canvasRef.current.width = rect.width * dpr;
      canvasRef.current.height = rect.height * dpr;
      canvasRef.current.style.width = `${rect.width}px`;
      canvasRef.current.style.height = `${rect.height}px`;
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Handle Wheel Scroll
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const maxScrollX = Math.max(0, gridRef.current.getTotalWidth() - (containerRef.current?.clientWidth || 800) + 100);
    const maxScrollY = Math.max(0, gridRef.current.getTotalHeight() - (containerRef.current?.clientHeight || 600) + 100);

    setScrollX((prev) => Math.max(0, Math.min(maxScrollX, prev + e.deltaX)));
    setScrollY((prev) => Math.max(0, Math.min(maxScrollY, prev + e.deltaY)));
  };

  // Helper: check if mouse is on selection autofill handle
  const isOverAutofillHandle = (px: number, py: number): boolean => {
    if (!selection) return false;
    const norm = normalizeRange(selection);
    const selEndX = gridRef.current.getColStart(norm.endCol) + gridRef.current.getColWidth(norm.endCol) - scrollX;
    const endV = gridRef.current.dataToViewRow[norm.endRow] !== undefined ? gridRef.current.dataToViewRow[norm.endRow] : norm.endRow;
    const selEndY = gridRef.current.getViewRowStart(endV) + gridRef.current.getRowHeight(norm.endRow) - scrollY;

    return px >= selEndX - 6 && px <= selEndX + 6 && py >= selEndY - 6 && py <= selEndY + 6;
  };

  // Mouse Down handler
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return; // only left click
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // 1. Check if clicking on a Chart or Chart Resize Handle
    const chartHit = hitTestCharts(
      sheet.charts || [],
      sheet,
      px + scrollX,
      py + scrollY,
      selectedChartId
    );

    if (chartHit) {
      onSelectedChartChange(chartHit.chart.id);
      setDraggingChart({
        chartId: chartHit.chart.id,
        handle: chartHit.handle || 'move',
        startX: px,
        startY: py,
        chartStartX: chartHit.chart.x,
        chartStartY: chartHit.chart.y,
        chartStartW: chartHit.chart.width,
        chartStartH: chartHit.chart.height,
      });
      return;
    } else if (selectedChartId) {
      onSelectedChartChange(null);
    }

    // 2. Check if clicking on Autofill Handle
    if (isOverAutofillHandle(px, py) && selection) {
      setIsAutofilling(true);
      setAutofillRange({ ...selection });
      return;
    }

    // 3. Grid Hit Testing
    const hit = gridRef.current.hitTest(px, py, scrollX, scrollY);

    if (hit.type === 'corner') {
      onSelectAll();
    } else if (hit.type === 'col_resize' && hit.resizeIndex !== undefined) {
      setResizingCol({
        col: hit.resizeIndex,
        startX: px,
        startW: gridRef.current.getColWidth(hit.resizeIndex),
      });
    } else if (hit.type === 'row_resize' && hit.resizeIndex !== undefined) {
      setResizingRow({
        row: hit.resizeIndex,
        startY: py,
        startH: gridRef.current.getRowHeight(hit.resizeIndex),
      });
    } else if (hit.type === 'col_filter_btn') {
      const colX = gridRef.current.getColStart(hit.col) - scrollX + rect.left;
      const headerY = gridRef.current.headerRowHeight + rect.top;
      setActiveFilterCol({ col: hit.col, x: colX, y: headerY });
    } else if (hit.type === 'col_header') {
      onActiveCellChange({ row: 0, col: hit.col });
      onSelectionChange({ startRow: 0, startCol: hit.col, endRow: sheet.maxRows - 1, endCol: hit.col });
    } else if (hit.type === 'row_header') {
      onActiveCellChange({ row: hit.row, col: 0 });
      onSelectionChange({ startRow: hit.row, startCol: 0, endRow: hit.row, endCol: sheet.maxCols - 1 });
    } else if (hit.type === 'cell') {
      if (isEditingInPlace) {
        commitInPlaceEdit();
      }

      const cellCoord = { row: hit.row, col: hit.col };
      onActiveCellChange(cellCoord);

      if (e.shiftKey && selection) {
        onSelectionChange({
          startRow: selection.startRow,
          startCol: selection.startCol,
          endRow: hit.row,
          endCol: hit.col,
        });
      } else {
        onSelectionChange({
          startRow: hit.row,
          startCol: hit.col,
          endRow: hit.row,
          endCol: hit.col,
        });
        setIsSelecting(true);
      }
    }
  };

  // Mouse Move handler
  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // 1. Column Resizing in progress
    if (resizingCol) {
      const deltaX = px - resizingCol.startX;
      const newWidth = Math.max(30, resizingCol.startW + deltaX);
      sheet.columnWidths[resizingCol.col] = newWidth;
      return;
    }

    // 2. Row Resizing in progress
    if (resizingRow) {
      const deltaY = py - resizingRow.startY;
      const newHeight = Math.max(18, resizingRow.startH + deltaY);
      sheet.rowHeights[resizingRow.row] = newHeight;
      return;
    }

    // 3. Chart Dragging / Resizing in progress
    if (draggingChart) {
      const deltaX = px - draggingChart.startX;
      const deltaY = py - draggingChart.startY;
      const chart = sheet.charts.find((c) => c.id === draggingChart.chartId);
      if (chart) {
        if (draggingChart.handle === 'move') {
          chart.x = Math.max(10, draggingChart.chartStartX + deltaX);
          chart.y = Math.max(10, draggingChart.chartStartY + deltaY);
        } else if (draggingChart.handle === 'se') {
          chart.width = Math.max(150, draggingChart.chartStartW + deltaX);
          chart.height = Math.max(100, draggingChart.chartStartH + deltaY);
        } else if (draggingChart.handle === 'e') {
          chart.width = Math.max(150, draggingChart.chartStartW + deltaX);
        } else if (draggingChart.handle === 's') {
          chart.height = Math.max(100, draggingChart.chartStartH + deltaY);
        } else if (draggingChart.handle === 'nw') {
          chart.x = draggingChart.chartStartX + deltaX;
          chart.y = draggingChart.chartStartY + deltaY;
          chart.width = Math.max(150, draggingChart.chartStartW - deltaX);
          chart.height = Math.max(100, draggingChart.chartStartH - deltaY);
        } else if (draggingChart.handle === 'ne') {
          chart.y = draggingChart.chartStartY + deltaY;
          chart.width = Math.max(150, draggingChart.chartStartW + deltaX);
          chart.height = Math.max(100, draggingChart.chartStartH - deltaY);
        } else if (draggingChart.handle === 'sw') {
          chart.x = draggingChart.chartStartX + deltaX;
          chart.width = Math.max(150, draggingChart.chartStartW - deltaX);
          chart.height = Math.max(100, draggingChart.chartStartH + deltaY);
        }
        onUpdateChart({ ...chart });
      }
      return;
    }

    // 4. Autofill Handle Dragging in progress
    if (isAutofilling && selection) {
      const hit = gridRef.current.hitTest(px, py, scrollX, scrollY);
      if (hit.type === 'cell') {
        const norm = normalizeRange(selection);
        let tgt: CellRange = { ...norm };

        const deltaR = hit.row - norm.endRow;
        const deltaC = hit.col - norm.endCol;

        if (Math.abs(deltaR) >= Math.abs(deltaC)) {
          // Vertical fill
          if (hit.row > norm.endRow) {
            tgt = { ...norm, endRow: hit.row };
          } else if (hit.row < norm.startRow) {
            tgt = { ...norm, startRow: hit.row };
          }
        } else {
          // Horizontal fill
          if (hit.col > norm.endCol) {
            tgt = { ...norm, endCol: hit.col };
          } else if (hit.col < norm.startCol) {
            tgt = { ...norm, startCol: hit.col };
          }
        }
        setAutofillRange(tgt);
      }
      return;
    }

    // 5. Multi-cell Selection Dragging in progress
    if (isSelecting && selection) {
      const hit = gridRef.current.hitTest(px, py, scrollX, scrollY);
      if (hit.type === 'cell') {
        onSelectionChange({
          startRow: activeCell.row,
          startCol: activeCell.col,
          endRow: hit.row,
          endCol: hit.col,
        });
      }
      return;
    }

    // 6. Hover Testing & Cursor styling
    const chartHit = hitTestCharts(sheet.charts || [], sheet, px + scrollX, py + scrollY, selectedChartId);
    if (chartHit) {
      setChartHoverInfo(chartHit.hoverInfo || null);
      if (chartHit.handle === 'move') setCursorStyle('move');
      else if (chartHit.handle === 'se' || chartHit.handle === 'nw') setCursorStyle('nwse-resize');
      else if (chartHit.handle === 'ne' || chartHit.handle === 'sw') setCursorStyle('nesw-resize');
      else if (chartHit.handle === 'e' || chartHit.handle === 'w') setCursorStyle('ew-resize');
      else if (chartHit.handle === 'n' || chartHit.handle === 's') setCursorStyle('ns-resize');
      return;
    } else {
      setChartHoverInfo(null);
    }

    if (isOverAutofillHandle(px, py)) {
      setCursorStyle('crosshair');
      return;
    }

    const hit = gridRef.current.hitTest(px, py, scrollX, scrollY);
    if (hit.type === 'col_resize') {
      setCursorStyle('col-resize');
    } else if (hit.type === 'row_resize') {
      setCursorStyle('row-resize');
    } else if (hit.type === 'col_filter_btn') {
      setCursorStyle('pointer');
    } else {
      setCursorStyle('cell');
    }

    setHoveredColHeader(hit.type === 'col_header' || hit.type === 'col_resize' ? hit.col : null);
    setHoveredRowHeader(hit.type === 'row_header' || hit.type === 'row_resize' ? hit.row : null);
  };

  // Mouse Up handler
  const handleMouseUp = () => {
    if (isAutofilling && selection && autofillRange) {
      const res = executeAutofill(sheet, selection, autofillRange);
      onBulkCellsChange(res.modifiedCells);
      onSelectionChange(autofillRange);
      setIsAutofilling(false);
      setAutofillRange(null);
    }

    setIsSelecting(false);
    setResizingCol(null);
    setResizingRow(null);
    setDraggingChart(null);
  };

  // Double Click Handler (Enter in-place editing or open Chart Editor)
  const handleDoubleClick = (e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    const chartHit = hitTestCharts(sheet.charts || [], sheet, px + scrollX, py + scrollY, selectedChartId);
    if (chartHit) {
      onOpenChartEditor(chartHit.chart);
      return;
    }

    const hit = gridRef.current.hitTest(px, py, scrollX, scrollY);
    if (hit.type === 'cell') {
      startInPlaceEdit(hit.row, hit.col);
    }
  };

  const startInPlaceEdit = (row: number, col: number, initialChar?: string) => {
    const cell = sheet.cells[cellKey(row, col)];
    const val = initialChar !== undefined ? initialChar : (cell?.formula || String(cell?.raw ?? ''));
    setEditValue(val);
    setIsEditingInPlace(true);
    setTimeout(() => {
      if (inPlaceInputRef.current) {
        inPlaceInputRef.current.focus();
        if (initialChar === undefined) {
          inPlaceInputRef.current.select();
        }
      }
    }, 10);
  };

  const commitInPlaceEdit = () => {
    if (isEditingInPlace) {
      onCellChange(activeCell.row, activeCell.col, editValue);
      setIsEditingInPlace(false);
    }
  };

  const cancelInPlaceEdit = () => {
    setIsEditingInPlace(false);
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if typing in another input (like search or title)
      const activeEl = document.activeElement;
      if (activeEl && activeEl.tagName === 'INPUT' && activeEl !== inPlaceInputRef.current) {
        return;
      }

      // If in place editing
      if (isEditingInPlace) {
        if (e.key === 'Enter') {
          e.preventDefault();
          commitInPlaceEdit();
          onActiveCellChange({ row: Math.min(sheet.maxRows - 1, activeCell.row + 1), col: activeCell.col });
          onSelectionChange({ startRow: activeCell.row + 1, startCol: activeCell.col, endRow: activeCell.row + 1, endCol: activeCell.col });
        } else if (e.key === 'Tab') {
          e.preventDefault();
          commitInPlaceEdit();
          onActiveCellChange({ row: activeCell.row, col: Math.min(sheet.maxCols - 1, activeCell.col + 1) });
          onSelectionChange({ startRow: activeCell.row, startCol: activeCell.col + 1, endRow: activeCell.row, endCol: activeCell.col + 1 });
        } else if (e.key === 'Escape') {
          cancelInPlaceEdit();
        }
        return;
      }

      // If Chart is selected, check delete
      if (selectedChartId && (e.key === 'Delete' || e.key === 'Backspace')) {
        e.preventDefault();
        onDeleteChart(selectedChartId);
        onSelectedChartChange(null);
        return;
      }

      // Ctrl+Z Undo / Ctrl+Y Redo
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) onRedo();
        else onUndo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        onRedo();
        return;
      }

      // Ctrl+A Select All
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        onSelectAll();
        return;
      }

      // Ctrl+C Copy
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c' && selection) {
        e.preventDefault();
        const { tsv, html } = copySelectionToClipboard(sheet, selection);
        navigator.clipboard.write([
          new ClipboardItem({
            'text/plain': new Blob([tsv], { type: 'text/plain' }),
            'text/html': new Blob([html], { type: 'text/html' }),
          }),
        ]).catch(() => {
          navigator.clipboard.writeText(tsv);
        });
        setMarchingAnts({ range: { ...selection }, isCut: false, sheetId: sheet.id });
        return;
      }

      // Ctrl+X Cut
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x' && selection) {
        e.preventDefault();
        const { tsv, html } = copySelectionToClipboard(sheet, selection);
        navigator.clipboard.write([
          new ClipboardItem({
            'text/plain': new Blob([tsv], { type: 'text/plain' }),
            'text/html': new Blob([html], { type: 'text/html' }),
          }),
        ]).catch(() => {
          navigator.clipboard.writeText(tsv);
        });
        setMarchingAnts({ range: { ...selection }, isCut: true, sheetId: sheet.id });
        return;
      }

      // Ctrl+V Paste
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
        e.preventDefault();
        navigator.clipboard.read().then(async (items) => {
          let tsv = '';
          let html = '';
          for (const item of items) {
            if (item.types.includes('text/html')) {
              const blob = await item.getType('text/html');
              html = await blob.text();
            }
            if (item.types.includes('text/plain')) {
              const blob = await item.getType('text/plain');
              tsv = await blob.text();
            }
          }

          const matrix = parseClipboardData(tsv, html);
          const res = applyPastedData(sheet, matrix, activeCell, marchingAnts?.range);

          // If it was a cut action, clear source cells
          if (marchingAnts?.isCut) {
            const mNorm = normalizeRange(marchingAnts.range);
            for (let r = mNorm.startRow; r <= mNorm.endRow; r++) {
              for (let c = mNorm.startCol; c <= mNorm.endCol; c++) {
                const key = cellKey(r, c);
                if (!res.modifiedCells[key]) {
                  sheet.cells[key] = { raw: '', formula: undefined };
                  res.modifiedCells[key] = sheet.cells[key];
                }
              }
            }
            setMarchingAnts(null);
          }

          onBulkCellsChange(res.modifiedCells);
        }).catch(() => {
          navigator.clipboard.readText().then((text) => {
            const matrix = parseClipboardData(text);
            const res = applyPastedData(sheet, matrix, activeCell);
            onBulkCellsChange(res.modifiedCells);
          });
        });
        return;
      }

      // Arrow navigation
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        const nextR = Math.min(sheet.maxRows - 1, activeCell.row + 1);
        onActiveCellChange({ row: nextR, col: activeCell.col });
        if (e.shiftKey && selection) {
          onSelectionChange({ ...selection, endRow: nextR });
        } else {
          onSelectionChange({ startRow: nextR, startCol: activeCell.col, endRow: nextR, endCol: activeCell.col });
        }
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        const nextR = Math.max(0, activeCell.row - 1);
        onActiveCellChange({ row: nextR, col: activeCell.col });
        if (e.shiftKey && selection) {
          onSelectionChange({ ...selection, endRow: nextR });
        } else {
          onSelectionChange({ startRow: nextR, startCol: activeCell.col, endRow: nextR, endCol: activeCell.col });
        }
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        const nextC = Math.min(sheet.maxCols - 1, activeCell.col + 1);
        onActiveCellChange({ row: activeCell.row, col: nextC });
        if (e.shiftKey && selection) {
          onSelectionChange({ ...selection, endCol: nextC });
        } else {
          onSelectionChange({ startRow: activeCell.row, startCol: nextC, endRow: activeCell.row, endCol: nextC });
        }
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        const nextC = Math.max(0, activeCell.col - 1);
        onActiveCellChange({ row: activeCell.row, col: nextC });
        if (e.shiftKey && selection) {
          onSelectionChange({ ...selection, endCol: nextC });
        } else {
          onSelectionChange({ startRow: activeCell.row, startCol: nextC, endRow: activeCell.row, endCol: nextC });
        }
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        // Clear selected cells
        if (selection) {
          e.preventDefault();
          const norm = normalizeRange(selection);
          const modified: Record<string, any> = {};
          for (let r = norm.startRow; r <= norm.endRow; r++) {
            for (let c = norm.startCol; c <= norm.endCol; c++) {
              const key = cellKey(r, c);
              sheet.cells[key] = { raw: '', formula: undefined, style: sheet.cells[key]?.style };
              modified[key] = sheet.cells[key];
            }
          }
          onBulkCellsChange(modified);
        }
      } else if (e.key === 'F2') {
        e.preventDefault();
        startInPlaceEdit(activeCell.row, activeCell.col);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        startInPlaceEdit(activeCell.row, activeCell.col);
      } else if (
        e.key.length === 1 &&
        !e.ctrlKey &&
        !e.metaKey &&
        !e.altKey &&
        !['Tab', 'Escape'].includes(e.key)
      ) {
        // Alphanumeric direct typing into cell
        startInPlaceEdit(activeCell.row, activeCell.col, e.key);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isEditingInPlace,
    editValue,
    activeCell,
    selection,
    selectedChartId,
    sheet,
    marchingAnts,
  ]);

  // Compute In-Place Input Overlay Positioning
  const activeRect = gridRef.current.getCellContentRect(activeCell.row, activeCell.col);
  const inputLeft = activeRect.x - scrollX;
  const inputTop = activeRect.y - scrollY;

  return (
    <div
      ref={containerRef}
      className="relative flex-1 w-full h-full overflow-hidden bg-slate-900 select-none"
      onWheel={handleWheel}
      style={{ cursor: cursorStyle }}
    >
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onDoubleClick={handleDoubleClick}
        className="block touch-none"
      />

      {/* In-Place Cell Editor Input */}
      {isEditingInPlace && (
        <input
          ref={inPlaceInputRef}
          type="text"
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onBlur={commitInPlaceEdit}
          className="absolute z-20 bg-white text-slate-900 border-2 border-blue-600 rounded-sm px-1 text-xs outline-none shadow-lg font-sans"
          style={{
            left: `${inputLeft}px`,
            top: `${inputTop}px`,
            width: `${Math.max(activeRect.width, 120)}px`,
            height: `${activeRect.height}px`,
          }}
        />
      )}

      {/* Column Filter Dropdown Popover */}
      {activeFilterCol && (
        <FilterPopover
          colIndex={activeFilterCol.col}
          sheet={sheet}
          position={{ x: activeFilterCol.x, y: activeFilterCol.y }}
          onClose={() => setActiveFilterCol(null)}
          onApplyFilter={onApplyFilter}
        />
      )}
    </div>
  );
};
