import React, { useState, useMemo } from 'react';
import { X, Search, Calculator, Plus, Check } from 'lucide-react';

interface FormulaAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertFormula: (template: string) => void;
}

interface FunctionDoc {
  name: string;
  category: 'Math & Stats' | 'Logique' | 'Recherche & Référence' | 'Texte' | 'Date & Heure';
  syntax: string;
  description: string;
  example: string;
}

const FUNCTIONS_CATALOG: FunctionDoc[] = [
  {
    name: 'SUM',
    category: 'Math & Stats',
    syntax: 'SUM(valeur1; [valeur2]; ...)',
    description: 'Calcule la somme de tous les nombres ou plages spécifiés.',
    example: '=SUM(B2:B10)',
  },
  {
    name: 'AVERAGE',
    category: 'Math & Stats',
    syntax: 'AVERAGE(valeur1; [valeur2]; ...)',
    description: 'Calcule la moyenne arithmétique des arguments.',
    example: '=AVERAGE(C4:F4)',
  },
  {
    name: 'MIN',
    category: 'Math & Stats',
    syntax: 'MIN(valeur1; [valeur2]; ...)',
    description: 'Renvoie la plus petite valeur d’une liste ou plage de nombres.',
    example: '=MIN(G4:G8)',
  },
  {
    name: 'MAX',
    category: 'Math & Stats',
    syntax: 'MAX(valeur1; [valeur2]; ...)',
    description: 'Renvoie la plus grande valeur d’une liste ou plage de nombres.',
    example: '=MAX(G4:G8)',
  },
  {
    name: 'COUNT',
    category: 'Math & Stats',
    syntax: 'COUNT(valeur1; [valeur2]; ...)',
    description: 'Compte le nombre de cellules contenant des nombres.',
    example: '=COUNT(A1:A50)',
  },
  {
    name: 'COUNTA',
    category: 'Math & Stats',
    syntax: 'COUNTA(valeur1; [valeur2]; ...)',
    description: 'Compte le nombre de cellules non vides dans une plage.',
    example: '=COUNTA(A1:A50)',
  },
  {
    name: 'MEDIAN',
    category: 'Math & Stats',
    syntax: 'MEDIAN(valeur1; [valeur2]; ...)',
    description: 'Renvoie la médiane (valeur du milieu) des nombres donnés.',
    example: '=MEDIAN(B2:B20)',
  },
  {
    name: 'STDEV',
    category: 'Math & Stats',
    syntax: 'STDEV(valeur1; [valeur2]; ...)',
    description: 'Évalue l’écart-type d’une population à partir d’un échantillon.',
    example: '=STDEV(G4:G8)',
  },
  {
    name: 'ROUND',
    category: 'Math & Stats',
    syntax: 'ROUND(nombre; [nb_décimales])',
    description: 'Arrondit un nombre au nombre de décimales spécifié.',
    example: '=ROUND(A1 * 1.20; 2)',
  },
  {
    name: 'IF',
    category: 'Logique',
    syntax: 'IF(test_logique; valeur_si_vrai; [valeur_si_faux])',
    description: 'Vérifie si une condition est remplie et renvoie une valeur si VRAI et une autre si FAUX.',
    example: '=IF(I4>=1; "Atteint"; "En cours")',
  },
  {
    name: 'IFS',
    category: 'Logique',
    syntax: 'IFS(condition1; valeur1; [condition2; valeur2]; ...)',
    description: 'Évalue plusieurs conditions dans l’ordre et renvoie la valeur correspondant à la première condition vraie.',
    example: '=IFS(A1>100; "A"; A1>50; "B"; TRUE; "C")',
  },
  {
    name: 'AND',
    category: 'Logique',
    syntax: 'AND(condition1; [condition2]; ...)',
    description: 'Renvoie VRAI si tous les arguments sont VRAI.',
    example: '=AND(A1>0; B1<100)',
  },
  {
    name: 'OR',
    category: 'Logique',
    syntax: 'OR(condition1; [condition2]; ...)',
    description: 'Renvoie VRAI si au moins un des arguments est VRAI.',
    example: '=OR(A1="Paris"; A1="Lyon")',
  },
  {
    name: 'IFERROR',
    category: 'Logique',
    syntax: 'IFERROR(valeur; valeur_si_erreur)',
    description: 'Renvoie une valeur de remplacement si l’expression génère une erreur (#DIV/0!, #N/A, etc.).',
    example: '=IFERROR(A1/B1; 0)',
  },
  {
    name: 'VLOOKUP',
    category: 'Recherche & Référence',
    syntax: 'VLOOKUP(valeur_cherchée; table_matrice; no_index_col; [valeur_proche])',
    description: 'Cherche une valeur dans la première colonne d’un tableau et renvoie une valeur dans la même ligne.',
    example: '=VLOOKUP("PRD-002"; A4:D7; 2; FALSE)',
  },
  {
    name: 'XLOOKUP',
    category: 'Recherche & Référence',
    syntax: 'XLOOKUP(valeur_cherchée; tableau_recherche; tableau_renvoyé; [si_non_trouvé])',
    description: 'Recherche moderne et flexible dans n’importe quelle colonne ou ligne.',
    example: '=XLOOKUP("PRD-004"; A4:A7; C4:C7)',
  },
  {
    name: 'INDEX',
    category: 'Recherche & Référence',
    syntax: 'INDEX(matrice; no_ligne; [no_colonne])',
    description: 'Renvoie la valeur d’une cellule à l’intersection d’une ligne et d’une colonne particulières.',
    example: '=INDEX(A4:D7; 1; 2)',
  },
  {
    name: 'MATCH',
    category: 'Recherche & Référence',
    syntax: 'MATCH(valeur_cherchée; tableau_recherche; [type])',
    description: 'Renvoie la position relative d’un élément dans une plage.',
    example: '=MATCH("PRD-002"; A4:A7; 0)',
  },
  {
    name: 'CONCATENATE',
    category: 'Texte',
    syntax: 'CONCATENATE(texte1; [texte2]; ...)',
    description: 'Associe plusieurs chaînes de texte en une seule.',
    example: '=CONCATENATE(A1; " - "; B1)',
  },
  {
    name: 'UPPER',
    category: 'Texte',
    syntax: 'UPPER(texte)',
    description: 'Convertit une chaîne de caractères en majuscules.',
    example: '=UPPER(A1)',
  },
  {
    name: 'LOWER',
    category: 'Texte',
    syntax: 'LOWER(texte)',
    description: 'Convertit une chaîne de caractères en minuscules.',
    example: '=LOWER(A1)',
  },
  {
    name: 'LEN',
    category: 'Texte',
    syntax: 'LEN(texte)',
    description: 'Renvoie le nombre de caractères d’une chaîne de texte.',
    example: '=LEN(A1)',
  },
  {
    name: 'TODAY',
    category: 'Date & Heure',
    syntax: 'TODAY()',
    description: 'Renvoie le numéro de série de la date actuelle.',
    example: '=TODAY()',
  },
  {
    name: 'NOW',
    category: 'Date & Heure',
    syntax: 'NOW()',
    description: 'Renvoie la date et l’heure actuelles.',
    example: '=NOW()',
  },
];

export const FormulaAssistantModal: React.FC<FormulaAssistantModalProps> = ({
  isOpen,
  onClose,
  onInsertFormula,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedName, setCopiedName] = useState<string | null>(null);

  const categories = ['all', 'Math & Stats', 'Logique', 'Recherche & Référence', 'Texte', 'Date & Heure'];

  const filtered = useMemo(() => {
    return FUNCTIONS_CATALOG.filter((fn) => {
      const matchCat = selectedCategory === 'all' || fn.category === selectedCategory;
      const matchSearch =
        !search ||
        fn.name.toLowerCase().includes(search.toLowerCase()) ||
        fn.description.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [search, selectedCategory]);

  if (!isOpen) return null;

  const handleSelect = (fn: FunctionDoc) => {
    onInsertFormula(fn.example);
    setCopiedName(fn.name);
    setTimeout(() => {
      onClose();
    }, 200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-800/40">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-white">Assistant de Formules & Fonctions (fx)</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Categories */}
        <div className="p-4 border-b border-slate-800 space-y-3 bg-slate-950/40">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher une fonction (ex: SUM, XLOOKUP, IF, STDEV...)"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-100 outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-0.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
                    : 'bg-slate-800/60 hover:bg-slate-800 text-slate-400'
                }`}
              >
                {cat === 'all' ? 'Toutes les catégories' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Function List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              Aucune fonction ne correspond à votre recherche.
            </div>
          ) : (
            filtered.map((fn) => (
              <div
                key={fn.name}
                className="p-3 rounded-lg bg-slate-800/40 hover:bg-slate-800/80 border border-slate-700/50 hover:border-slate-600 transition flex items-start justify-between gap-4 group"
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-emerald-400">{fn.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700/60 text-slate-300">
                      {fn.category}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300">{fn.description}</div>
                  <div className="flex items-center gap-2 pt-1">
                    <span className="text-[10px] text-slate-400 font-semibold">Exemple :</span>
                    <code className="px-1.5 py-0.5 rounded bg-slate-950 font-mono text-blue-300 text-[11px] border border-slate-800">
                      {fn.example}
                    </code>
                  </div>
                </div>

                <button
                  onClick={() => handleSelect(fn)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-xs font-semibold flex items-center gap-1 shadow transition active:scale-95"
                >
                  {copiedName === fn.name ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>Insérer</span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
