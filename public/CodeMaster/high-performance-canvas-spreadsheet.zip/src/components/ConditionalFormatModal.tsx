import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Plus,
  Trash2,
  Check,
  Palette,
  BarChart,
  CircleDot,
} from 'lucide-react';
import { ConditionalRule, ConditionalRuleType, SheetData } from '../types/sheet';

interface ConditionalFormatModalProps {
  isOpen: boolean;
  onClose: () => void;
  sheet: SheetData;
  onSaveRules: (rules: ConditionalRule[]) => void;
  defaultRange?: string;
}

export const ConditionalFormatModal: React.FC<ConditionalFormatModalProps> = ({
  isOpen,
  onClose,
  sheet,
  onSaveRules,
  defaultRange = 'I4:I8',
}) => {
  const [rules, setRules] = useState<ConditionalRule[]>(sheet.conditionalRules || []);
  const [activeTab, setActiveTab] = useState<'list' | 'create'>('list');

  // Form state for creating a new rule
  const [ruleType, setRuleType] = useState<ConditionalRuleType>('colorScale');
  const [targetRange, setTargetRange] = useState<string>(defaultRange);
  const [val1, setVal1] = useState<string>('1');
  const [val2] = useState<string>('100');
  const [bgColor, setBgColor] = useState<string>('#dcfce7');
  const [textColor, setTextColor] = useState<string>('#15803d');
  const [scaleMinColor, setScaleMinColor] = useState<string>('#fecaca');
  const [scaleMidColor, setScaleMidColor] = useState<string>('#fef08a');
  const [scaleMaxColor, setScaleMaxColor] = useState<string>('#bbf7d0');
  const [dataBarColor, setDataBarColor] = useState<string>('#38bdf8');
  const [iconType, setIconType] = useState<'traffic' | 'arrows' | 'stars'>('traffic');

  if (!isOpen) return null;

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    const newRule: ConditionalRule = {
      id: `rule-${Date.now()}`,
      type: ruleType,
      targetRange,
      value1: val1,
      value2: val2,
      style: {
        bgColor,
        textColor,
        bold: true,
      },
      colorScale:
        ruleType === 'colorScale'
          ? {
              minColor: scaleMinColor,
              midColor: scaleMidColor,
              maxColor: scaleMaxColor,
            }
          : undefined,
      dataBar:
        ruleType === 'dataBar'
          ? {
              positiveColor: dataBarColor,
              negativeColor: '#f87171',
              showAxis: true,
            }
          : undefined,
      iconSet:
        ruleType === 'iconSet'
          ? {
              iconType,
            }
          : undefined,
    };

    const updated = [...rules, newRule];
    setRules(updated);
    onSaveRules(updated);
    setActiveTab('list');
  };

  const handleDeleteRule = (id: string) => {
    const updated = rules.filter((r) => r.id !== id);
    setRules(updated);
    onSaveRules(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-800/40">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-bold text-white">Gestion du Formatage Conditionnel Canvas</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center px-5 pt-3 border-b border-slate-800 gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('list')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'list' ? 'border-amber-400 text-amber-300' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Règles Actives ({rules.length})
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`pb-2 border-b-2 transition ${
              activeTab === 'create' ? 'border-amber-400 text-amber-300' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            + Nouvelle Règle
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto">
          {activeTab === 'list' ? (
            <div className="space-y-2">
              {rules.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  Aucune règle de formatage active sur cette feuille.
                </div>
              ) : (
                rules.map((r) => (
                  <div
                    key={r.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-slate-800/60 border border-slate-700/60 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      {r.type === 'colorScale' && (
                        <div className="flex items-center gap-0.5">
                          <span className="w-3.5 h-3.5 rounded" style={{ backgroundColor: r.colorScale?.minColor }} />
                          <span className="w-3.5 h-3.5 rounded" style={{ backgroundColor: r.colorScale?.midColor }} />
                          <span className="w-3.5 h-3.5 rounded" style={{ backgroundColor: r.colorScale?.maxColor }} />
                        </div>
                      )}
                      {r.type === 'dataBar' && (
                        <div className="w-10 h-3 bg-slate-700 rounded overflow-hidden">
                          <div
                            className="h-full rounded"
                            style={{ width: '70%', backgroundColor: r.dataBar?.positiveColor }}
                          />
                        </div>
                      )}
                      {r.type === 'iconSet' && (
                        <div className="flex items-center gap-1 text-emerald-400">
                          <CircleDot className="w-4 h-4" />
                        </div>
                      )}

                      <div>
                        <span className="font-semibold text-slate-200">
                          {r.type === 'colorScale' && 'Échelle de couleurs (3 nuances)'}
                          {r.type === 'dataBar' && 'Barre de données intra-cellule'}
                          {r.type === 'iconSet' && `Jeu d'icônes (${r.iconSet?.iconType})`}
                          {r.type === 'greaterThan' && `Valeur > ${r.value1}`}
                          {r.type === 'lessThan' && `Valeur < ${r.value1}`}
                          {r.type === 'between' && `Valeur entre ${r.value1} et ${r.value2}`}
                          {r.type === 'equal' && `Valeur = "${r.value1}"`}
                          {r.type === 'textContains' && `Contient "${r.value1}"`}
                        </span>
                        <span className="text-[10px] text-slate-400 ml-2 font-mono">
                          Plage : {r.targetRange}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteRule(r.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-700 rounded transition"
                      title="Supprimer la règle"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}

              <button
                onClick={() => setActiveTab('create')}
                className="w-full mt-3 py-2 border border-dashed border-slate-700 hover:border-amber-500/60 rounded-lg text-xs font-semibold text-amber-300/80 hover:text-amber-300 flex items-center justify-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Ajouter une nouvelle règle</span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleAddRule} className="space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Plage cible à formater
                </label>
                <input
                  type="text"
                  value={targetRange}
                  onChange={(e) => setTargetRange(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 font-mono text-white outline-none focus:border-amber-500"
                  placeholder="Ex: I4:I8 ou C2:F20"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5">
                  Type de Règle Visuelle
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setRuleType('colorScale')}
                    className={`p-2 rounded-lg border text-left flex flex-col gap-1 transition ${
                      ruleType === 'colorScale'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-slate-800 bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <Palette className="w-4 h-4" />
                    <span className="font-semibold">Échelle de Nuances</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRuleType('dataBar')}
                    className={`p-2 rounded-lg border text-left flex flex-col gap-1 transition ${
                      ruleType === 'dataBar'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-slate-800 bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <BarChart className="w-4 h-4" />
                    <span className="font-semibold">Barre de Données</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRuleType('iconSet')}
                    className={`p-2 rounded-lg border text-left flex flex-col gap-1 transition ${
                      ruleType === 'iconSet'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-slate-800 bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <CircleDot className="w-4 h-4" />
                    <span className="font-semibold">Jeu d'Icônes</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRuleType('greaterThan')}
                    className={`p-2 rounded-lg border text-left flex flex-col gap-1 transition ${
                      ruleType === 'greaterThan'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-slate-800 bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <span className="font-bold text-amber-400">&gt; Val</span>
                    <span className="font-semibold">Supérieur à</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRuleType('equal')}
                    className={`p-2 rounded-lg border text-left flex flex-col gap-1 transition ${
                      ruleType === 'equal'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                        : 'border-slate-800 bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <span className="font-bold text-emerald-400">= Val</span>
                    <span className="font-semibold">Texte Égal</span>
                  </button>
                </div>
              </div>

              {(ruleType === 'greaterThan' || ruleType === 'equal') && (
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60 space-y-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Valeur de comparaison</label>
                    <input
                      type="text"
                      value={val1}
                      onChange={(e) => setVal1(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-200 outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Couleur fond</label>
                      <input
                        type="color"
                        value={bgColor}
                        onChange={(e) => setBgColor(e.target.value)}
                        className="w-full h-8 bg-transparent cursor-pointer rounded"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Couleur texte</label>
                      <input
                        type="color"
                        value={textColor}
                        onChange={(e) => setTextColor(e.target.value)}
                        className="w-full h-8 bg-transparent cursor-pointer rounded"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Specific rule configurations */}
              {ruleType === 'colorScale' && (
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60 space-y-3">
                  <span className="text-[11px] font-semibold text-slate-300">Couleurs du dégradé (Min / Médiane / Max)</span>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Minimum</label>
                      <input
                        type="color"
                        value={scaleMinColor}
                        onChange={(e) => setScaleMinColor(e.target.value)}
                        className="w-full h-8 bg-transparent cursor-pointer rounded"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Médiane</label>
                      <input
                        type="color"
                        value={scaleMidColor}
                        onChange={(e) => setScaleMidColor(e.target.value)}
                        className="w-full h-8 bg-transparent cursor-pointer rounded"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-400 mb-1">Maximum</label>
                      <input
                        type="color"
                        value={scaleMaxColor}
                        onChange={(e) => setScaleMaxColor(e.target.value)}
                        className="w-full h-8 bg-transparent cursor-pointer rounded"
                      />
                    </div>
                  </div>
                </div>
              )}

              {ruleType === 'dataBar' && (
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60 space-y-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Couleur de la barre positive</label>
                    <input
                      type="color"
                      value={dataBarColor}
                      onChange={(e) => setDataBarColor(e.target.value)}
                      className="w-full h-8 bg-transparent cursor-pointer rounded"
                    />
                  </div>
                </div>
              )}

              {ruleType === 'iconSet' && (
                <div className="p-3 bg-slate-800/50 rounded-lg border border-slate-700/60 space-y-3">
                  <label className="block text-[11px] font-semibold text-slate-300">Type d'icônes</label>
                  <select
                    value={iconType}
                    onChange={(e) => setIconType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 outline-none"
                  >
                    <option value="traffic">Feux tricolores (Vert / Jaune / Rouge)</option>
                    <option value="arrows">Flèches de tendance (Haut / Droite / Bas)</option>
                    <option value="stars">Étoiles de notation</option>
                  </select>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="px-3 py-1.5 rounded-md hover:bg-slate-800 text-slate-300"
                >
                  Retour
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg shadow transition"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Enregistrer la règle</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
