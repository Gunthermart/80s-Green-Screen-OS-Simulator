import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  BarChart2,
  TrendingUp,
  PieChart,
  Layers,
  Palette,
  Check,
  Sparkles,
} from 'lucide-react';
import { ChartConfig, ChartType, SheetData } from '../types/sheet';
import { renderChart } from '../engine/charts/chartRenderer';

interface ChartEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveChart: (chart: ChartConfig) => void;
  existingChart?: ChartConfig | null;
  sheet: SheetData;
  defaultRange?: string;
}

const PALETTES = [
  { name: 'Corporate Tech', colors: ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'] },
  { name: 'Emerald Finance', colors: ['#059669', '#10b981', '#34d399', '#6ee7b7', '#a7f3d0'] },
  { name: 'Sunset Warm', colors: ['#ea580c', '#f97316', '#fb923c', '#f59e0b', '#fbbf24'] },
  { name: 'Indigo Royal', colors: ['#4f46e5', '#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe'] },
  { name: 'Vibrant Neo', colors: ['#ec4899', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'] },
];

export const ChartEditorModal: React.FC<ChartEditorModalProps> = ({
  isOpen,
  onClose,
  onSaveChart,
  existingChart,
  sheet,
  defaultRange = 'C4:F8',
}) => {
  const [type, setType] = useState<ChartType>(existingChart?.type || 'column');
  const [title, setTitle] = useState(existingChart?.title || 'Graphique d’Analyse');
  const [subtitle, setSubtitle] = useState(existingChart?.subtitle || 'Données consolidées');
  const [dataRange, setDataRange] = useState(existingChart?.dataRange || defaultRange);
  const [labelRange, setLabelRange] = useState(existingChart?.labelRange || 'A4:A8');
  const [seriesNamesRange, setSeriesNamesRange] = useState(existingChart?.seriesNamesRange || 'C3:F3');
  const [seriesDirection, setSeriesDirection] = useState<'columns' | 'rows'>(existingChart?.seriesDirection || 'columns');
  const [selectedPalette, setSelectedPalette] = useState<number>(0);
  const [showLegend, setShowLegend] = useState(existingChart?.showLegend !== false);
  const [doughnutHole, setDoughnutHole] = useState<number>(existingChart?.doughnutHoleSize || 0.55);
  const [smooth, setSmooth] = useState(existingChart?.smooth !== false);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (existingChart) {
      setType(existingChart.type);
      setTitle(existingChart.title);
      setSubtitle(existingChart.subtitle || '');
      setDataRange(existingChart.dataRange);
      setLabelRange(existingChart.labelRange || '');
      setSeriesNamesRange(existingChart.seriesNamesRange || '');
      setSeriesDirection(existingChart.seriesDirection || 'columns');
      setShowLegend(existingChart.showLegend !== false);
      if (existingChart.doughnutHoleSize) setDoughnutHole(existingChart.doughnutHoleSize);
      if (existingChart.smooth !== undefined) setSmooth(existingChart.smooth);
    } else {
      setDataRange(defaultRange);
    }
  }, [existingChart, defaultRange, isOpen]);

  // Render live preview on canvas
  useEffect(() => {
    if (!isOpen || !previewCanvasRef.current) return;
    const canvas = previewCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const previewConfig: ChartConfig = {
      id: 'preview',
      type,
      title,
      subtitle,
      dataRange,
      labelRange,
      seriesNamesRange,
      seriesDirection,
      colors: PALETTES[selectedPalette].colors,
      showLegend,
      doughnutHoleSize: doughnutHole,
      smooth,
      x: 0,
      y: 0,
      width: 440,
      height: 270,
    };

    ctx.clearRect(0, 0, 440, 270);
    renderChart(ctx, previewConfig, sheet, false, null);
  }, [
    isOpen,
    type,
    title,
    subtitle,
    dataRange,
    labelRange,
    seriesNamesRange,
    seriesDirection,
    selectedPalette,
    showLegend,
    doughnutHole,
    smooth,
    sheet,
  ]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newChart: ChartConfig = {
      id: existingChart?.id || `chart-${Date.now()}`,
      type,
      title,
      subtitle,
      dataRange,
      labelRange: labelRange || undefined,
      seriesNamesRange: seriesNamesRange || undefined,
      seriesDirection,
      x: existingChart?.x || 700,
      y: existingChart?.y || 60,
      width: existingChart?.width || 440,
      height: existingChart?.height || 260,
      colors: PALETTES[selectedPalette].colors,
      showLegend,
      doughnutHoleSize: doughnutHole,
      smooth,
    };
    onSaveChart(newChart);
    onClose();
  };

  const chartTypes: { type: ChartType; label: string; icon: any }[] = [
    { type: 'column', label: 'Colonnes', icon: BarChart2 },
    { type: 'column_stacked', label: 'Empilé', icon: Layers },
    { type: 'line', label: 'Courbe', icon: TrendingUp },
    { type: 'area', label: 'Aire', icon: TrendingUp },
    { type: 'pie', label: 'Secteurs (Pie)', icon: PieChart },
    { type: 'doughnut', label: 'Anneau (Doughnut)', icon: PieChart },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-slate-800/40">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-blue-400" />
            <h2 className="text-sm font-bold text-white">
              {existingChart ? 'Modifier le Graphique Canvas' : 'Créer un Graphique Vectoriel Canvas'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left: Configuration Controls */}
          <div className="flex flex-col gap-4 text-xs">
            {/* Chart Type Selector */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1.5 uppercase tracking-wider">
                Type de Graphique
              </label>
              <div className="grid grid-cols-3 gap-2">
                {chartTypes.map((ct) => {
                  const Icon = ct.icon;
                  const isSelected = type === ct.type;
                  return (
                    <button
                      key={ct.type}
                      type="button"
                      onClick={() => setType(ct.type)}
                      className={`flex flex-col items-center gap-1.5 p-2 rounded-lg border text-xs font-medium transition ${
                        isSelected
                          ? 'border-blue-500 bg-blue-500/10 text-blue-300 shadow-sm'
                          : 'border-slate-800 bg-slate-800/60 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isSelected ? 'text-blue-400' : 'text-slate-400'}`} />
                      <span>{ct.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Titles */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">Titre principal</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="Ex: Ventes 2024"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">Sous-titre (optionnel)</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="Ex: En k€ par trimestre"
                />
              </div>
            </div>

            {/* Ranges */}
            <div className="space-y-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Plage de Données (Séries numériques)
                </label>
                <input
                  type="text"
                  value={dataRange}
                  onChange={(e) => setDataRange(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs font-mono text-white outline-none focus:border-blue-500"
                  placeholder="Ex: C4:F8"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Étiquettes Catégories (Axe X)
                  </label>
                  <input
                    type="text"
                    value={labelRange}
                    onChange={(e) => setLabelRange(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs font-mono text-white outline-none focus:border-blue-500"
                    placeholder="Ex: A4:A8"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Noms des Séries (Légende)
                  </label>
                  <input
                    type="text"
                    value={seriesNamesRange}
                    onChange={(e) => setSeriesNamesRange(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs font-mono text-white outline-none focus:border-blue-500"
                    placeholder="Ex: C3:F3"
                  />
                </div>
              </div>
            </div>

            {/* Palette selector */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" />
                <span>Palette de Couleurs</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {PALETTES.map((pal, idx) => (
                  <button
                    key={pal.name}
                    type="button"
                    onClick={() => setSelectedPalette(idx)}
                    className={`flex items-center justify-between p-2 rounded-lg border transition ${
                      selectedPalette === idx
                        ? 'border-blue-500 bg-blue-500/10'
                        : 'border-slate-800 bg-slate-800/40 hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-[11px] text-slate-300">{pal.name}</span>
                    <div className="flex gap-1">
                      {pal.colors.slice(0, 4).map((c, i) => (
                        <span key={i} className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c }} />
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Extra Options */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={showLegend}
                  onChange={(e) => setShowLegend(e.target.checked)}
                  className="rounded bg-slate-800 border-slate-700 text-blue-500"
                />
                <span>Afficher la Légende</span>
              </label>

              {(type === 'line' || type === 'area') && (
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={smooth}
                    onChange={(e) => setSmooth(e.target.checked)}
                    className="rounded bg-slate-800 border-slate-700 text-blue-500"
                  />
                  <span>Courbes lissées (Spline)</span>
                </label>
              )}

              {type === 'doughnut' && (
                <div className="flex items-center gap-2 w-full">
                  <span className="text-slate-400">Taille du trou central :</span>
                  <input
                    type="range"
                    min="0.3"
                    max="0.75"
                    step="0.05"
                    value={doughnutHole}
                    onChange={(e) => setDoughnutHole(parseFloat(e.target.value))}
                    className="flex-1 accent-blue-500"
                  />
                  <span className="font-mono text-[10px] text-slate-400">
                    {Math.round(doughnutHole * 100)}%
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Live Canvas Preview Card */}
          <div className="flex flex-col items-center justify-center bg-slate-950/80 rounded-xl p-4 border border-slate-800/80">
            <div className="text-[11px] font-semibold text-slate-400 mb-2 flex items-center gap-1.5 self-start">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>Aperçu Vectoriel Temps Réel Canvas</span>
            </div>
            <div className="relative rounded-lg overflow-hidden border border-slate-800 shadow-xl bg-white">
              <canvas
                ref={previewCanvasRef}
                width={440}
                height={270}
                className="w-full h-auto block"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-2 text-center">
              Le graphique est redimensionnable et déplaçable directement sur la grille Canvas.
            </p>
          </div>
        </form>

        {/* Footer actions */}
        <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-slate-800 bg-slate-800/30">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition"
          >
            Annuler
          </button>
          <button
            onClick={handleSubmit}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20 transition active:scale-95"
          >
            <Check className="w-3.5 h-3.5" />
            <span>{existingChart ? 'Appliquer les modifications' : 'Insérer sur la Grille'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
