import React, { useState, useRef, useEffect } from 'react';
import { Plus, X, Activity } from 'lucide-react';
import { SheetData, CellRange } from '../types/sheet';
import { normalizeRange, cellKey } from '../engine/formula/utils';

interface SheetTabsProps {
  sheets: Record<string, SheetData>;
  sheetOrder: string[];
  activeSheetId: string;
  onSelectSheet: (id: string) => void;
  onAddSheet: () => void;
  onRenameSheet: (id: string, newName: string) => void;
  onDeleteSheet: (id: string) => void;
  selection: CellRange | null;
}

export const SheetTabs: React.FC<SheetTabsProps> = ({
  sheets,
  sheetOrder,
  activeSheetId,
  onSelectSheet,
  onAddSheet,
  onRenameSheet,
  onDeleteSheet,
  selection,
}) => {
  const [editingSheetId, setEditingSheetId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingSheetId && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingSheetId]);

  const handleStartRename = (sheetId: string, currentName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSheetId(sheetId);
    setEditName(currentName);
  };

  const handleFinishRename = () => {
    if (editingSheetId && editName.trim()) {
      onRenameSheet(editingSheetId, editName.trim());
    }
    setEditingSheetId(null);
  };

  // Compute live selection statistics
  const activeSheet = sheets[activeSheetId];
  let sum = 0;
  let count = 0;
  let numericCount = 0;
  let min = Infinity;
  let max = -Infinity;

  if (activeSheet && selection) {
    const norm = normalizeRange(selection);
    for (let r = norm.startRow; r <= norm.endRow; r++) {
      for (let c = norm.startCol; c <= norm.endCol; c++) {
        const cell = activeSheet.cells[cellKey(r, c)];
        if (cell) {
          const val = cell.computed !== undefined ? cell.computed : cell.raw;
          if (val !== null && val !== undefined && val !== '') {
            count++;
            const num = Number(val);
            if (!isNaN(num) && typeof val !== 'boolean') {
              numericCount++;
              sum += num;
              if (num < min) min = num;
              if (num > max) max = num;
            }
          }
        }
      }
    }
  }

  const average = numericCount > 0 ? sum / numericCount : 0;

  return (
    <footer className="bg-slate-900 border-t border-slate-800 px-3 py-1 flex items-center justify-between text-xs select-none flex-shrink-0 text-slate-300">
      {/* Left: Sheet Tabs List */}
      <div className="flex items-center gap-1 overflow-x-auto">
        <button
          onClick={onAddSheet}
          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-emerald-400 transition"
          title="Ajouter une nouvelle feuille"
        >
          <Plus className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1">
          {sheetOrder.map((id) => {
            const sheet = sheets[id];
            if (!sheet) return null;
            const isActive = id === activeSheetId;

            return (
              <div
                key={id}
                onClick={() => onSelectSheet(id)}
                onDoubleClick={(e) => handleStartRename(id, sheet.name, e)}
                className={`group flex items-center gap-2 px-3 py-1 rounded-t-md border-t-2 font-medium cursor-pointer transition text-xs ${
                  isActive
                    ? 'bg-slate-800 border-emerald-500 text-emerald-300 shadow-sm'
                    : 'bg-slate-900/80 border-transparent text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                }`}
              >
                {editingSheetId === id ? (
                  <input
                    ref={inputRef}
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    onBlur={handleFinishRename}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleFinishRename();
                      if (e.key === 'Escape') setEditingSheetId(null);
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="bg-slate-950 border border-emerald-500 rounded px-1.5 py-0.5 text-xs text-white outline-none w-28"
                  />
                ) : (
                  <span>{sheet.name}</span>
                )}

                {/* Delete Sheet Button */}
                {sheetOrder.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm(`Voulez-vous supprimer la feuille "${sheet.name}" ?`)) {
                        onDeleteSheet(id);
                      }
                    }}
                    className="p-0.5 rounded text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition"
                    title="Supprimer la feuille"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Live Selection Statistics */}
      <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
        {numericCount > 0 && (
          <div className="flex items-center gap-3 bg-slate-950/60 px-2.5 py-0.5 rounded border border-slate-800">
            <span>
              <strong className="text-slate-300">Somme :</strong> {sum.toLocaleString('fr-FR', { maximumFractionDigits: 2 })}
            </span>
            <span>
              <strong className="text-slate-300">Moy :</strong> {average.toLocaleString('fr-FR', { maximumFractionDigits: 2 })}
            </span>
            <span>
              <strong className="text-slate-300">Min :</strong> {min.toLocaleString('fr-FR')}
            </span>
            <span>
              <strong className="text-slate-300">Max :</strong> {max.toLocaleString('fr-FR')}
            </span>
            <span>
              <strong className="text-slate-300">Nb :</strong> {count}
            </span>
          </div>
        )}

        <div className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
          <Activity className="w-3 h-3" />
          <span>Canvas HiDPI</span>
        </div>
      </div>
    </footer>
  );
};
