import React, { useState, useRef, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Upload,
  BarChart2,
  Sparkles,
  Undo2,
  Redo2,
  FileCode,
  Image,
  Printer,
  Calculator,
} from 'lucide-react';

interface TopNavProps {
  fileName: string;
  onFileNameChange: (name: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onOpenChartModal: () => void;
  onOpenCondModal: () => void;
  onOpenFormulaHelper: () => void;
  onExportCSV: () => void;
  onExportJSON: () => void;
  onExportCanvasImage: () => void;
  onImportCSV: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onImportJSON: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSelectAll: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  fileName,
  onFileNameChange,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  onOpenChartModal,
  onOpenCondModal,
  onOpenFormulaHelper,
  onExportCSV,
  onExportJSON,
  onExportCanvasImage,
  onImportCSV,
  onImportJSON,
  onSelectAll,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const titleInputRef = useRef<HTMLInputElement>(null);
  const fileInputCsvRef = useRef<HTMLInputElement>(null);
  const fileInputJsonRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.dropdown-menu-container')) {
        setActiveMenu(null);
      }
    };
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isEditingTitle && titleInputRef.current) {
      titleInputRef.current.focus();
      titleInputRef.current.select();
    }
  }, [isEditingTitle]);

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-200 select-none flex-shrink-0 z-30">
      {/* Hidden file inputs for import */}
      <input
        type="file"
        ref={fileInputCsvRef}
        accept=".csv"
        className="hidden"
        onChange={onImportCSV}
      />
      <input
        type="file"
        ref={fileInputJsonRef}
        accept=".json"
        className="hidden"
        onChange={onImportJSON}
      />

      <div className="flex items-center justify-between px-3 py-1.5 gap-3">
        {/* Left: App Logo & Document Title & Menu Bar */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-1.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-sm">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            <span className="hidden sm:inline bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent tracking-tight">
              CanvasSheet Pro
            </span>
          </div>

          <div className="flex flex-col">
            {/* Document Title */}
            <div className="flex items-center gap-1.5">
              {isEditingTitle ? (
                <input
                  ref={titleInputRef}
                  type="text"
                  value={fileName}
                  onChange={(e) => onFileNameChange(e.target.value)}
                  onBlur={() => setIsEditingTitle(false)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === 'Escape') setIsEditingTitle(false);
                  }}
                  className="bg-slate-800 border border-emerald-500/60 rounded px-1.5 py-0.5 text-xs font-semibold text-slate-100 outline-none w-48"
                />
              ) : (
                <button
                  onClick={() => setIsEditingTitle(true)}
                  className="text-xs font-semibold text-slate-100 hover:bg-slate-800/80 px-1.5 py-0.5 rounded transition flex items-center gap-1 group"
                >
                  <span>{fileName}</span>
                  <span className="text-[10px] text-slate-400 opacity-0 group-hover:opacity-100 transition">✎</span>
                </button>
              )}
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40">
                Canvas 2D 60 FPS
              </span>
            </div>

            {/* Menu Bar Dropdowns */}
            <nav className="flex items-center gap-0.5 mt-0.5 dropdown-menu-container text-xs">
              {/* FICHIER */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenu(activeMenu === 'fichier' ? null : 'fichier');
                  }}
                  className={`px-2 py-0.5 rounded text-xs transition ${
                    activeMenu === 'fichier' ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  Fichier
                </button>
                {activeMenu === 'fichier' && (
                  <div className="absolute top-full left-0 mt-1 w-52 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs backdrop-blur-md">
                    <button
                      onClick={() => {
                        fileInputCsvRef.current?.click();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Importer un fichier CSV</span>
                    </button>
                    <button
                      onClick={() => {
                        fileInputJsonRef.current?.click();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <Upload className="w-3.5 h-3.5 text-blue-400" />
                      <span>Importer un projet JSON</span>
                    </button>
                    <div className="border-t border-slate-800 my-1" />
                    <button
                      onClick={() => {
                        onExportCSV();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Exporter en CSV</span>
                    </button>
                    <button
                      onClick={() => {
                        onExportJSON();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <FileCode className="w-3.5 h-3.5 text-amber-400" />
                      <span>Exporter le projet JSON</span>
                    </button>
                    <button
                      onClick={() => {
                        onExportCanvasImage();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <Image className="w-3.5 h-3.5 text-purple-400" />
                      <span>Exporter en Image PNG</span>
                    </button>
                    <div className="border-t border-slate-800 my-1" />
                    <button
                      onClick={() => {
                        window.print();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <Printer className="w-3.5 h-3.5 text-slate-400" />
                      <span>Imprimer / Sauvegarder PDF</span>
                    </button>
                  </div>
                )}
              </div>

              {/* ÉDITION */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenu(activeMenu === 'edition' ? null : 'edition');
                  }}
                  className={`px-2 py-0.5 rounded text-xs transition ${
                    activeMenu === 'edition' ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  Édition
                </button>
                {activeMenu === 'edition' && (
                  <div className="absolute top-full left-0 mt-1 w-52 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs">
                    <button
                      disabled={!canUndo}
                      onClick={() => {
                        onUndo();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center justify-between text-slate-200 disabled:opacity-40"
                    >
                      <span className="flex items-center gap-2">
                        <Undo2 className="w-3.5 h-3.5" /> Annuler
                      </span>
                      <span className="text-[10px] text-slate-400">Ctrl+Z</span>
                    </button>
                    <button
                      disabled={!canRedo}
                      onClick={() => {
                        onRedo();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center justify-between text-slate-200 disabled:opacity-40"
                    >
                      <span className="flex items-center gap-2">
                        <Redo2 className="w-3.5 h-3.5" /> Rétablir
                      </span>
                      <span className="text-[10px] text-slate-400">Ctrl+Y</span>
                    </button>
                    <div className="border-t border-slate-800 my-1" />
                    <button
                      onClick={() => {
                        onSelectAll();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center justify-between text-slate-200"
                    >
                      <span>Tout sélectionner</span>
                      <span className="text-[10px] text-slate-400">Ctrl+A</span>
                    </button>
                  </div>
                )}
              </div>

              {/* INSÉRER */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveMenu(activeMenu === 'inserer' ? null : 'inserer');
                  }}
                  className={`px-2 py-0.5 rounded text-xs transition ${
                    activeMenu === 'inserer' ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-800/60'
                  }`}
                >
                  Insérer
                </button>
                {activeMenu === 'inserer' && (
                  <div className="absolute top-full left-0 mt-1 w-56 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs">
                    <button
                      onClick={() => {
                        onOpenChartModal();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-blue-300"
                    >
                      <BarChart2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>Graphique Vectoriel Canvas</span>
                    </button>
                    <button
                      onClick={() => {
                        onOpenCondModal();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-amber-300"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Règle de Formatage Conditionnel</span>
                    </button>
                    <button
                      onClick={() => {
                        onOpenFormulaHelper();
                        setActiveMenu(null);
                      }}
                      className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center gap-2 text-emerald-300"
                    >
                      <Calculator className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Assistant de Fonctions (fx)</span>
                    </button>
                  </div>
                )}
              </div>
            </nav>
          </div>
        </div>

        {/* Right: Quick Action Buttons & Status */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenChartModal}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-xs font-semibold shadow transition active:scale-95"
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Insérer Graphique</span>
          </button>

          <button
            onClick={onOpenCondModal}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 rounded-md text-xs font-semibold transition active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Formatage Conditionnel</span>
          </button>

          <button
            onClick={onOpenFormulaHelper}
            className="flex items-center gap-1.5 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 rounded-md text-xs font-medium transition"
            title="Assistant de Formules"
          >
            <Calculator className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden lg:inline">Fonctions (fx)</span>
          </button>

          <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block" />

          {/* Quick Export Button */}
          <button
            onClick={onExportCSV}
            className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-medium transition"
            title="Exporter CSV"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">CSV</span>
          </button>

          <button
            onClick={onExportCanvasImage}
            className="flex items-center gap-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-medium transition"
            title="Exporter Image PNG du Canvas"
          >
            <Image className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden lg:inline">PNG</span>
          </button>
        </div>
      </div>
    </header>
  );
};
