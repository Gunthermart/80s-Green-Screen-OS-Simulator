import React, { useState } from 'react';
import {
  Undo2,
  Redo2,
  Bold,
  Italic,
  Strikethrough,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Sparkles,
  BarChart2,
  Filter,
  DollarSign,
  Percent,
  Euro,
  Type,
  Grid,
  Palette,
  Plus,
  Minus,
} from 'lucide-react';
import { CellStyle, NumberFormatType } from '../types/sheet';

interface ToolbarProps {
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  activeStyle: CellStyle;
  onApplyStyle: (style: Partial<CellStyle>) => void;
  onOpenChartModal: () => void;
  onOpenCondModal: () => void;
  onToggleFilter: () => void;
  hasFiltersActive: boolean;
}

const COLOR_PALETTE = [
  '#000000', '#334155', '#64748b', '#94a3b8', '#cbd5e1', '#ffffff',
  '#dc2626', '#ea580c', '#d97706', '#16a34a', '#0284c7', '#4f46e5', '#7c3aed', '#db2777',
  '#fee2e2', '#ffedd5', '#fef3c7', '#dcfce7', '#e0f2fe', '#e0e7ff', '#ede9fe', '#fce7f3',
];

export const Toolbar: React.FC<ToolbarProps> = ({
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  activeStyle,
  onApplyStyle,
  onOpenChartModal,
  onOpenCondModal,
  onToggleFilter,
  hasFiltersActive,
}) => {
  const [showTextColorPicker, setShowTextColorPicker] = useState(false);
  const [showBgColorPicker, setShowBgColorPicker] = useState(false);
  const [showBordersMenu, setShowBordersMenu] = useState(false);

  const currentFontSize = activeStyle.fontSize || 12;

  const handleFormatChange = (fmt: NumberFormatType) => {
    onApplyStyle({ format: fmt });
  };

  const handleAdjustDecimals = (delta: number) => {
    const curPrec = activeStyle.precision !== undefined ? activeStyle.precision : 2;
    onApplyStyle({ precision: Math.max(0, Math.min(6, curPrec + delta)) });
  };

  return (
    <div className="bg-slate-800 border-b border-slate-700/80 px-3 py-1 flex items-center gap-1.5 overflow-x-auto text-slate-200 select-none flex-shrink-0 text-xs">
      {/* History buttons */}
      <div className="flex items-center gap-0.5 pr-1 border-r border-slate-700">
        <button
          disabled={!canUndo}
          onClick={onUndo}
          className="p-1 rounded hover:bg-slate-700 text-slate-300 disabled:opacity-30 transition"
          title="Annuler (Ctrl+Z)"
        >
          <Undo2 className="w-3.5 h-3.5" />
        </button>
        <button
          disabled={!canRedo}
          onClick={onRedo}
          className="p-1 rounded hover:bg-slate-700 text-slate-300 disabled:opacity-30 transition"
          title="Rétablir (Ctrl+Y)"
        >
          <Redo2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Number Formats Presets */}
      <div className="flex items-center gap-0.5 pr-1 border-r border-slate-700">
        <button
          onClick={() => handleFormatChange('currency_eur')}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.format === 'currency_eur' ? 'bg-slate-700 text-emerald-400 font-bold' : 'text-slate-300'
          }`}
          title="Format Monétaire (€)"
        >
          <Euro className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => handleFormatChange('currency_usd')}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.format === 'currency_usd' ? 'bg-slate-700 text-emerald-400 font-bold' : 'text-slate-300'
          }`}
          title="Format Monétaire ($)"
        >
          <DollarSign className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => handleFormatChange('percent')}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.format === 'percent' ? 'bg-slate-700 text-emerald-400 font-bold' : 'text-slate-300'
          }`}
          title="Format Pourcentage (%)"
        >
          <Percent className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => handleFormatChange('number')}
          className={`px-1.5 py-0.5 rounded text-[11px] font-mono hover:bg-slate-700 transition ${
            activeStyle.format === 'number' ? 'bg-slate-700 text-blue-400 font-bold' : 'text-slate-300'
          }`}
          title="Format Nombre Standard"
        >
          123
        </button>

        {/* Decimals +/- */}
        <button
          onClick={() => handleAdjustDecimals(1)}
          className="p-1 rounded hover:bg-slate-700 text-slate-300 text-[10px] font-mono flex items-center transition"
          title="Ajouter une décimale"
        >
          .0<Plus className="w-2.5 h-2.5" />
        </button>
        <button
          onClick={() => handleAdjustDecimals(-1)}
          className="p-1 rounded hover:bg-slate-700 text-slate-300 text-[10px] font-mono flex items-center transition"
          title="Diminuer les décimales"
        >
          .0<Minus className="w-2.5 h-2.5" />
        </button>
      </div>

      {/* Font Family selector */}
      <div className="flex items-center gap-1 pr-1 border-r border-slate-700">
        <select
          value={activeStyle.fontFamily || 'Inter, sans-serif'}
          onChange={(e) => onApplyStyle({ fontFamily: e.target.value })}
          className="bg-slate-900 border border-slate-700 rounded px-1.5 py-0.5 text-xs text-slate-200 outline-none cursor-pointer"
        >
          <option value="Inter, sans-serif">Inter</option>
          <option value="'JetBrains Mono', monospace">JetBrains Mono</option>
          <option value="Arial, sans-serif">Arial</option>
          <option value="Georgia, serif">Georgia</option>
        </select>

        {/* Font Size Selector */}
        <select
          value={currentFontSize}
          onChange={(e) => onApplyStyle({ fontSize: Number(e.target.value) })}
          className="bg-slate-900 border border-slate-700 rounded px-1 py-0.5 text-xs text-slate-200 outline-none cursor-pointer w-12 text-center"
        >
          {[10, 11, 12, 13, 14, 16, 18, 20, 24].map((sz) => (
            <option key={sz} value={sz}>
              {sz}
            </option>
          ))}
        </select>
      </div>

      {/* Font Styling Buttons (Bold, Italic, Strike) */}
      <div className="flex items-center gap-0.5 pr-1 border-r border-slate-700">
        <button
          onClick={() => onApplyStyle({ bold: !activeStyle.bold })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.bold ? 'bg-slate-700 text-blue-400 shadow-inner' : 'text-slate-300'
          }`}
          title="Gras (Ctrl+B)"
        >
          <Bold className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => onApplyStyle({ italic: !activeStyle.italic })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.italic ? 'bg-slate-700 text-blue-400 shadow-inner' : 'text-slate-300'
          }`}
          title="Italique (Ctrl+I)"
        >
          <Italic className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => onApplyStyle({ strike: !activeStyle.strike })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.strike ? 'bg-slate-700 text-blue-400 shadow-inner' : 'text-slate-300'
          }`}
          title="Barré"
        >
          <Strikethrough className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Text & Background Color Pickers */}
      <div className="flex items-center gap-1 pr-1 border-r border-slate-700 relative">
        {/* Text Color */}
        <div className="relative">
          <button
            onClick={() => {
              setShowTextColorPicker(!showTextColorPicker);
              setShowBgColorPicker(false);
            }}
            className="p-1 rounded hover:bg-slate-700 text-slate-300 flex items-center gap-0.5 transition"
            title="Couleur du texte"
          >
            <Type className="w-3.5 h-3.5" />
            <span
              className="w-2.5 h-2.5 rounded-full border border-slate-600"
              style={{ backgroundColor: activeStyle.textColor || '#000000' }}
            />
          </button>
          {showTextColorPicker && (
            <div className="absolute top-full left-0 mt-1 bg-slate-900 border border-slate-700 rounded-lg p-2 shadow-2xl z-50 w-44">
              <div className="text-[10px] text-slate-400 font-semibold mb-1">Couleur du texte</div>
              <div className="grid grid-cols-6 gap-1">
                {COLOR_PALETTE.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      onApplyStyle({ textColor: c });
                      setShowTextColorPicker(false);
                    }}
                    className="w-5 h-5 rounded border border-slate-600 hover:scale-110 transition"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Fill Background Color */}
        <div className="relative">
          <button
            onClick={() => {
              setShowBgColorPicker(!showBgColorPicker);
              setShowTextColorPicker(false);
            }}
            className="p-1 rounded hover:bg-slate-700 text-slate-300 flex items-center gap-0.5 transition"
            title="Couleur de remplissage"
          >
            <Palette className="w-3.5 h-3.5" />
            <span
              className="w-2.5 h-2.5 rounded-full border border-slate-600"
              style={{ backgroundColor: activeStyle.bgColor || '#ffffff' }}
            />
          </button>
          {showBgColorPicker && (
            <div className="absolute top-full left-0 mt-1 bg-slate-900 border border-slate-700 rounded-lg p-2 shadow-2xl z-50 w-44">
              <div className="text-[10px] text-slate-400 font-semibold mb-1">Remplissage de cellule</div>
              <div className="grid grid-cols-6 gap-1">
                {COLOR_PALETTE.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      onApplyStyle({ bgColor: c === '#ffffff' ? undefined : c });
                      setShowBgColorPicker(false);
                    }}
                    className="w-5 h-5 rounded border border-slate-600 hover:scale-110 transition"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Alignment Buttons */}
      <div className="flex items-center gap-0.5 pr-1 border-r border-slate-700">
        <button
          onClick={() => onApplyStyle({ align: 'left' })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.align === 'left' ? 'bg-slate-700 text-blue-400' : 'text-slate-300'
          }`}
          title="Aligner à gauche"
        >
          <AlignLeft className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => onApplyStyle({ align: 'center' })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.align === 'center' ? 'bg-slate-700 text-blue-400' : 'text-slate-300'
          }`}
          title="Centrer"
        >
          <AlignCenter className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => onApplyStyle({ align: 'right' })}
          className={`p-1 rounded hover:bg-slate-700 transition ${
            activeStyle.align === 'right' ? 'bg-slate-700 text-blue-400' : 'text-slate-300'
          }`}
          title="Aligner à droite"
        >
          <AlignRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Borders Menu */}
      <div className="relative pr-1 border-r border-slate-700">
        <button
          onClick={() => setShowBordersMenu(!showBordersMenu)}
          className="p-1 rounded hover:bg-slate-700 text-slate-300 transition"
          title="Bordures de cellules"
        >
          <Grid className="w-3.5 h-3.5" />
        </button>
        {showBordersMenu && (
          <div className="absolute top-full left-0 mt-1 bg-slate-900 border border-slate-700 rounded-lg p-1.5 shadow-2xl z-50 w-36 text-xs flex flex-col gap-1">
            <button
              onClick={() => {
                onApplyStyle({
                  border: {
                    top: { style: 'thin', color: '#000000' },
                    bottom: { style: 'thin', color: '#000000' },
                    left: { style: 'thin', color: '#000000' },
                    right: { style: 'thin', color: '#000000' },
                  },
                });
                setShowBordersMenu(false);
              }}
              className="px-2 py-1 hover:bg-slate-800 rounded text-left text-slate-200"
            >
              Toutes les bordures
            </button>
            <button
              onClick={() => {
                onApplyStyle({
                  border: {
                    bottom: { style: 'double', color: '#000000' },
                    top: { style: 'thin', color: '#000000' },
                  },
                });
                setShowBordersMenu(false);
              }}
              className="px-2 py-1 hover:bg-slate-800 rounded text-left text-slate-200"
            >
              Ligne de total (Double)
            </button>
            <button
              onClick={() => {
                onApplyStyle({ border: undefined });
                setShowBordersMenu(false);
              }}
              className="px-2 py-1 hover:bg-slate-800 rounded text-left text-rose-400"
            >
              Effacer bordures
            </button>
          </div>
        )}
      </div>

      {/* Advanced Features shortcuts */}
      <div className="flex items-center gap-1.5 pl-1">
        <button
          onClick={onOpenCondModal}
          className="flex items-center gap-1 px-2 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 rounded transition text-xs font-medium"
          title="Formatage conditionnel"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Nuances & Barres</span>
        </button>

        <button
          onClick={onOpenChartModal}
          className="flex items-center gap-1 px-2 py-1 bg-blue-500/10 border border-blue-500/30 text-blue-300 hover:bg-blue-500/20 rounded transition text-xs font-medium"
          title="Créer un graphique Canvas"
        >
          <BarChart2 className="w-3.5 h-3.5 text-blue-400" />
          <span>Graphique</span>
        </button>

        <button
          onClick={onToggleFilter}
          className={`flex items-center gap-1 px-2 py-1 rounded transition text-xs font-medium ${
            hasFiltersActive
              ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
              : 'bg-slate-700/60 hover:bg-slate-700 text-slate-300'
          }`}
          title="Activer/Désactiver les filtres automatiques"
        >
          <Filter className="w-3.5 h-3.5" />
          <span>Filtres</span>
        </button>
      </div>
    </div>
  );
};
