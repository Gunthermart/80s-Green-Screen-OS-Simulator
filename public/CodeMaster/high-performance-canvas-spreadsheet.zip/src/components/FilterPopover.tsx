import React, { useState, useMemo } from 'react';
import {
  ArrowDownAZ,
  ArrowUpZA,
  Search,
  Check,
  RotateCcw,
  X,
} from 'lucide-react';
import { ColumnFilter, SheetData } from '../types/sheet';
import { colIndexToName } from '../engine/formula/utils';

interface FilterPopoverProps {
  colIndex: number;
  sheet: SheetData;
  position: { x: number; y: number };
  onClose: () => void;
  onApplyFilter: (colIndex: number, filter: ColumnFilter | null) => void;
}

export const FilterPopover: React.FC<FilterPopoverProps> = ({
  colIndex,
  sheet,
  position,
  onClose,
  onApplyFilter,
}) => {
  const currentFilter = sheet.filters[colIndex];
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | null>(currentFilter?.sortOrder || null);

  // Extract all unique cell values from this column (skipping header row 0 if applicable)
  const uniqueValues = useMemo(() => {
    const set = new Set<string>();
    for (let r = 0; r < sheet.maxRows; r++) {
      const cell = sheet.cells[`${r}_${colIndex}`];
      if (cell) {
        const val = cell.computed !== undefined ? cell.computed : cell.raw;
        if (val !== null && val !== undefined && val !== '') {
          set.add(String(val));
        }
      }
    }
    return Array.from(set).sort();
  }, [sheet, colIndex]);

  // Selected values in the checkbox list
  const [selectedValues, setSelectedValues] = useState<Set<string>>(() => {
    if (currentFilter?.selectedValues) {
      return new Set(currentFilter.selectedValues);
    }
    return new Set(uniqueValues);
  });

  const filteredUniqueValues = useMemo(() => {
    if (!searchQuery) return uniqueValues;
    const q = searchQuery.toLowerCase();
    return uniqueValues.filter((v) => v.toLowerCase().includes(q));
  }, [uniqueValues, searchQuery]);

  const handleToggleValue = (val: string) => {
    const next = new Set(selectedValues);
    if (next.has(val)) {
      next.delete(val);
    } else {
      next.add(val);
    }
    setSelectedValues(next);
  };

  const handleSelectAll = () => {
    setSelectedValues(new Set(uniqueValues));
  };

  const handleDeselectAll = () => {
    setSelectedValues(new Set());
  };

  const handleApply = () => {
    // If all values are selected and no sort order, remove filter
    const isAllSelected = selectedValues.size === uniqueValues.length;
    if (isAllSelected && !sortOrder) {
      onApplyFilter(colIndex, null);
    } else {
      const newFilter: ColumnFilter = {
        colIndex,
        sortOrder,
        selectedValues: isAllSelected ? undefined : selectedValues,
      };
      onApplyFilter(colIndex, newFilter);
    }
    onClose();
  };

  const handleClear = () => {
    onApplyFilter(colIndex, null);
    onClose();
  };

  const colLetter = colIndexToName(colIndex);

  return (
    <div
      className="fixed z-50 bg-slate-900 border border-slate-700/90 rounded-xl shadow-2xl w-64 text-slate-100 text-xs overflow-hidden select-none animate-in fade-in zoom-in-95 duration-150"
      style={{
        top: Math.min(window.innerHeight - 340, Math.max(10, position.y)),
        left: Math.min(window.innerWidth - 270, Math.max(10, position.x)),
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-800/80 border-b border-slate-700/60 font-semibold text-slate-200">
        <span className="flex items-center gap-1.5">
          <span>Filtre & Tri : Colonne {colLetter}</span>
        </span>
        <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white transition">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="p-3 space-y-3">
        {/* Sort Actions */}
        <div className="flex flex-col gap-1">
          <button
            onClick={() => setSortOrder('asc')}
            className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center justify-between transition ${
              sortOrder === 'asc' ? 'bg-blue-600/30 text-blue-300 font-semibold' : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <span className="flex items-center gap-2">
              <ArrowDownAZ className="w-4 h-4 text-emerald-400" />
              <span>Trier croissant (A &rarr; Z)</span>
            </span>
            {sortOrder === 'asc' && <Check className="w-3.5 h-3.5 text-blue-400" />}
          </button>

          <button
            onClick={() => setSortOrder('desc')}
            className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center justify-between transition ${
              sortOrder === 'desc' ? 'bg-blue-600/30 text-blue-300 font-semibold' : 'hover:bg-slate-800 text-slate-300'
            }`}
          >
            <span className="flex items-center gap-2">
              <ArrowUpZA className="w-4 h-4 text-amber-400" />
              <span>Trier décroissant (Z &rarr; A)</span>
            </span>
            {sortOrder === 'desc' && <Check className="w-3.5 h-3.5 text-blue-400" />}
          </button>
        </div>

        <div className="border-t border-slate-800" />

        {/* Search unique values */}
        <div className="space-y-1.5">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une valeur..."
              className="w-full bg-slate-950 border border-slate-700/80 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 outline-none focus:border-blue-500"
            />
          </div>

          {/* Select all / Clear buttons */}
          <div className="flex items-center justify-between text-[10px] text-blue-400 px-1 pt-1">
            <button onClick={handleSelectAll} className="hover:underline">
              Tout sélectionner
            </button>
            <button onClick={handleDeselectAll} className="hover:underline text-slate-400">
              Effacer tout
            </button>
          </div>

          {/* Unique values list with checkboxes */}
          <div className="max-h-32 overflow-y-auto bg-slate-950/60 border border-slate-800 rounded-lg p-1.5 space-y-1">
            {filteredUniqueValues.length === 0 ? (
              <div className="text-slate-500 text-[10px] text-center py-2">Aucun résultat</div>
            ) : (
              filteredUniqueValues.map((val) => {
                const isChecked = selectedValues.has(val);
                return (
                  <label
                    key={val}
                    className="flex items-center gap-2 px-1.5 py-0.5 rounded hover:bg-slate-800/80 cursor-pointer text-slate-200 text-xs"
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleValue(val)}
                      className="rounded bg-slate-900 border-slate-700 text-blue-500 focus:ring-0"
                    />
                    <span className="truncate">{val}</span>
                  </label>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-800/50 border-t border-slate-800">
        <button
          onClick={handleClear}
          className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Réinitialiser</span>
        </button>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onClose}
            className="px-2.5 py-1 rounded text-xs text-slate-300 hover:bg-slate-800 transition"
          >
            Annuler
          </button>
          <button
            onClick={handleApply}
            className="px-3 py-1 rounded-md text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow transition active:scale-95"
          >
            Appliquer
          </button>
        </div>
      </div>
    </div>
  );
};
