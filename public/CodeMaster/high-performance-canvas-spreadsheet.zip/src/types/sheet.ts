export type CellCoord = {
  row: number; // 0-indexed
  col: number; // 0-indexed
};

export type CellRange = {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
};

export type BorderLineStyle = 'none' | 'thin' | 'medium' | 'thick' | 'dashed' | 'double';

export type CellBorderStyle = {
  top?: { style: BorderLineStyle; color: string };
  bottom?: { style: BorderLineStyle; color: string };
  left?: { style: BorderLineStyle; color: string };
  right?: { style: BorderLineStyle; color: string };
};

export type NumberFormatType = 
  | 'general' 
  | 'number' 
  | 'currency_eur' 
  | 'currency_usd' 
  | 'percent' 
  | 'date' 
  | 'scientific'
  | 'text';

export type CellStyle = {
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  strike?: boolean;
  textColor?: string;
  bgColor?: string;
  align?: 'left' | 'center' | 'right';
  verticalAlign?: 'top' | 'middle' | 'bottom';
  fontSize?: number; // default 13
  fontFamily?: string; // 'Inter', 'JetBrains Mono', 'Arial', etc.
  format?: NumberFormatType;
  precision?: number; // decimal places
  wrapText?: boolean;
  border?: CellBorderStyle;
};

export type CellData = {
  raw: string | number | boolean | null;
  formula?: string; // starts with '=' e.g. "=SUM(B2:B10)"
  computed?: any;   // evaluated value
  error?: string | null; // e.g. "#DIV/0!", "#REF!", "#CIRCULAR!"
  style?: CellStyle;
};

export type ChartType = 
  | 'column' 
  | 'bar' 
  | 'column_stacked' 
  | 'bar_stacked' 
  | 'line' 
  | 'spline' 
  | 'area' 
  | 'pie' 
  | 'doughnut';

export type ChartConfig = {
  id: string;
  type: ChartType;
  title: string;
  subtitle?: string;
  dataRange: string;      // e.g. "B2:D7"
  labelRange?: string;    // e.g. "A2:A7"
  seriesNamesRange?: string; // e.g. "B1:D1"
  seriesDirection?: 'columns' | 'rows';
  x: number;              // Canvas pixel X
  y: number;              // Canvas pixel Y
  width: number;          // Canvas pixel Width
  height: number;         // Canvas pixel Height
  colors?: string[];      // Series color palette
  showLegend?: boolean;
  legendPosition?: 'top' | 'bottom' | 'right' | 'left';
  xAxisTitle?: string;
  yAxisTitle?: string;
  doughnutHoleSize?: number; // 0.3 - 0.7 for doughnut
  smooth?: boolean;       // for spline vs straight lines
  showValues?: boolean;   // show data values on bars/points
  showGrid?: boolean;     // show background gridlines
};

export type ConditionalRuleType = 
  | 'greaterThan' 
  | 'lessThan' 
  | 'between' 
  | 'equal' 
  | 'notEqual' 
  | 'textContains' 
  | 'isEmpty' 
  | 'notEmpty'
  | 'colorScale' 
  | 'dataBar' 
  | 'iconSet';

export type ConditionalRule = {
  id: string;
  type: ConditionalRuleType;
  targetRange: string; // e.g. "C2:C20"
  // Value rule
  value1?: number | string;
  value2?: number | string;
  style?: {
    bgColor?: string;
    textColor?: string;
    bold?: boolean;
  };
  // Color scale
  colorScale?: {
    minColor: string;
    midColor?: string;
    maxColor: string;
    minType?: 'min' | 'number' | 'percent';
    maxType?: 'max' | 'number' | 'percent';
  };
  // Data bar
  dataBar?: {
    positiveColor: string;
    negativeColor: string;
    showAxis?: boolean;
    gradient?: boolean;
  };
  // Icon set
  iconSet?: {
    iconType: 'arrows' | 'traffic' | 'flags' | 'bars' | 'stars';
    reverse?: boolean;
  };
};

export type FilterCondition = {
  type: 'none' | 'contains' | 'equals' | 'greater' | 'less' | 'empty';
  value?: string | number;
};

export type ColumnFilter = {
  colIndex: number;
  condition?: FilterCondition;
  searchQuery?: string;
  selectedValues?: Set<string>; // if empty set/null, all included
  sortOrder?: 'asc' | 'desc' | null;
};

export type MergedCell = {
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
};

export type SheetData = {
  id: string;
  name: string;
  cells: Record<string, CellData>; // key format "r_c" (e.g., "0_0" for A1)
  columnWidths: Record<number, number>; // colIndex -> width in px
  rowHeights: Record<number, number>;   // rowIndex -> height in px
  charts: ChartConfig[];
  conditionalRules: ConditionalRule[];
  mergedCells: MergedCell[];
  frozenRows: number;
  frozenCols: number;
  defaultColWidth: number;
  defaultRowHeight: number;
  maxRows: number;
  maxCols: number;
  filters: Record<number, ColumnFilter>;
};

export type DragHandleType = 
  | 'nw' | 'n' | 'ne' 
  | 'e' | 'se' | 's' 
  | 'sw' | 'w' 
  | 'move';

export type ChartHoverInfo = {
  chartId: string;
  seriesIndex?: number;
  seriesName?: string;
  pointIndex?: number;
  label?: string;
  value?: number;
  percentage?: number;
  canvasX: number;
  canvasY: number;
  screenX: number;
  screenY: number;
};

export type MarchingAntsSelection = {
  range: CellRange;
  isCut: boolean;
  sheetId: string;
};
